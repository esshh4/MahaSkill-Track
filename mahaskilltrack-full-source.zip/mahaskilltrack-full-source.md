# MahaSkillTrack — Complete Source Code

## PROJECT STRUCTURE

```text
./.gitignore
./.prettierignore
./.prettierrc
./AGENTS.md
./README.md
./bun.lock
./bunfig.toml
./components.json
./eslint.config.js
./package.json
./public
./public/favicon.ico
./public/robots.txt
./src
./src/auth
./src/auth/auth-context.tsx
./src/components
./src/components/charts
./src/components/charts/dashboard-charts.tsx
./src/components/common
./src/components/common/chart-card.tsx
./src/components/common/filter-bar.tsx
./src/components/common/page-header.tsx
./src/components/common/stat-card.tsx
./src/components/common/states.tsx
./src/components/common/status-badge.tsx
./src/components/common/timeline.tsx
./src/components/forms
./src/components/forms/follow-up-dialog.tsx
./src/components/forms/outcome-dialog.tsx
./src/components/layout
./src/components/layout/app-shell.tsx
./src/components/ui
./src/components/ui/accordion.tsx
./src/components/ui/alert-dialog.tsx
./src/components/ui/alert.tsx
./src/components/ui/aspect-ratio.tsx
./src/components/ui/avatar.tsx
./src/components/ui/badge.tsx
./src/components/ui/breadcrumb.tsx
./src/components/ui/button.tsx
./src/components/ui/calendar.tsx
./src/components/ui/card.tsx
./src/components/ui/carousel.tsx
./src/components/ui/chart.tsx
./src/components/ui/checkbox.tsx
./src/components/ui/collapsible.tsx
./src/components/ui/command.tsx
./src/components/ui/context-menu.tsx
./src/components/ui/dialog.tsx
./src/components/ui/drawer.tsx
./src/components/ui/dropdown-menu.tsx
./src/components/ui/form.tsx
./src/components/ui/hover-card.tsx
./src/components/ui/input-otp.tsx
./src/components/ui/input.tsx
./src/components/ui/label.tsx
./src/components/ui/menubar.tsx
./src/components/ui/navigation-menu.tsx
./src/components/ui/pagination.tsx
./src/components/ui/popover.tsx
./src/components/ui/progress.tsx
./src/components/ui/radio-group.tsx
./src/components/ui/resizable.tsx
./src/components/ui/scroll-area.tsx
./src/components/ui/select.tsx
./src/components/ui/separator.tsx
./src/components/ui/sheet.tsx
./src/components/ui/sidebar.tsx
./src/components/ui/skeleton.tsx
./src/components/ui/slider.tsx
./src/components/ui/sonner.tsx
./src/components/ui/switch.tsx
./src/components/ui/table.tsx
./src/components/ui/tabs.tsx
./src/components/ui/textarea.tsx
./src/components/ui/toggle-group.tsx
./src/components/ui/toggle.tsx
./src/components/ui/tooltip.tsx
./src/data
./src/data/seed.ts
./src/hooks
./src/hooks/use-mobile.tsx
./src/hooks/use-scope.ts
./src/lib
./src/lib/error-capture.ts
./src/lib/error-page.ts
./src/lib/lovable-error-reporting.ts
./src/lib/utils.ts
./src/routeTree.gen.ts
./src/router.tsx
./src/routes
./src/routes/README.md
./src/routes/__root.tsx
./src/routes/app.analytics.tsx
./src/routes/app.consent.tsx
./src/routes/app.dashboard.tsx
./src/routes/app.employers.tsx
./src/routes/app.followups.tsx
./src/routes/app.index.tsx
./src/routes/app.outcomes.tsx
./src/routes/app.programs.tsx
./src/routes/app.providers.tsx
./src/routes/app.reports.tsx
./src/routes/app.settings.tsx
./src/routes/app.skill-gaps.tsx
./src/routes/app.trainees.$traineeId.tsx
./src/routes/app.trainees.index.tsx
./src/routes/app.tsx
./src/routes/index.tsx
./src/routes/login.tsx
./src/server.ts
./src/services
./src/services/analytics.ts
./src/services/store.tsx
./src/start.ts
./src/styles.css
./src/types
./src/types/index.ts
./src/utils
./src/utils/export.ts
./tsconfig.json
./vite.config.ts
```

## FILE 1: package.json

```json
{
  "name": "tanstack_start_ts",
  "private": true,
  "sideEffects": false,
  "type": "module",
  "scripts": {
    "dev": "vite dev",
    "build": "vite build",
    "build:dev": "vite build --mode development",
    "preview": "vite preview",
    "lint": "eslint .",
    "format": "prettier --write ."
  },
  "overrides": {
    "rolldown": "1.2.1"
  },
  "dependencies": {
    "@hookform/resolvers": "^5.2.2",
    "@radix-ui/react-accordion": "^1.2.12",
    "@radix-ui/react-alert-dialog": "^1.1.15",
    "@radix-ui/react-aspect-ratio": "^1.1.8",
    "@radix-ui/react-avatar": "^1.1.11",
    "@radix-ui/react-checkbox": "^1.3.3",
    "@radix-ui/react-collapsible": "^1.1.12",
    "@radix-ui/react-context-menu": "^2.2.16",
    "@radix-ui/react-dialog": "^1.1.15",
    "@radix-ui/react-dropdown-menu": "^2.1.16",
    "@radix-ui/react-hover-card": "^1.1.15",
    "@radix-ui/react-label": "^2.1.8",
    "@radix-ui/react-menubar": "^1.1.16",
    "@radix-ui/react-navigation-menu": "^1.2.14",
    "@radix-ui/react-popover": "^1.1.15",
    "@radix-ui/react-progress": "^1.1.8",
    "@radix-ui/react-radio-group": "^1.3.8",
    "@radix-ui/react-scroll-area": "^1.2.10",
    "@radix-ui/react-select": "^2.2.6",
    "@radix-ui/react-separator": "^1.1.8",
    "@radix-ui/react-slider": "^1.3.6",
    "@radix-ui/react-slot": "^1.2.4",
    "@radix-ui/react-switch": "^1.2.6",
    "@radix-ui/react-tabs": "^1.1.13",
    "@radix-ui/react-toggle": "^1.1.10",
    "@radix-ui/react-toggle-group": "^1.1.11",
    "@radix-ui/react-tooltip": "^1.2.8",
    "@tailwindcss/vite": "^4.2.1",
    "@tanstack/react-query": "^5.101.1",
    "@tanstack/react-router": "1.170.18",
    "@tanstack/react-start": "1.168.32",
    "@tanstack/router-plugin": "1.168.23",
    "class-variance-authority": "^0.7.1",
    "clsx": "^2.1.1",
    "cmdk": "^1.1.1",
    "date-fns": "^4.1.0",
    "embla-carousel-react": "^8.6.0",
    "input-otp": "^1.4.2",
    "lucide-react": "^0.575.0",
    "react": "^19.2.0",
    "react-day-picker": "^9.14.0",
    "react-dom": "^19.2.0",
    "react-hook-form": "^7.71.2",
    "react-resizable-panels": "^4.6.5",
    "recharts": "^2.15.4",
    "sonner": "^2.0.7",
    "tailwind-merge": "^3.5.0",
    "tailwindcss": "^4.2.1",
    "tw-animate-css": "^1.3.4",
    "vaul": "^1.1.2",
    "vite-tsconfig-paths": "^6.0.2",
    "zod": "^3.24.2"
  },
  "devDependencies": {
    "@eslint/js": "^9.32.0",
    "@lovable.dev/vite-tanstack-config": "^2.15.0",
    "@types/node": "^22.16.5",
    "@types/react": "^19.2.0",
    "@types/react-dom": "^19.2.0",
    "@vitejs/plugin-react": "^5.2.0",
    "eslint": "^9.32.0",
    "eslint-config-prettier": "^10.1.1",
    "eslint-plugin-prettier": "^5.2.6",
    "eslint-plugin-react-hooks": "^5.2.0",
    "eslint-plugin-react-refresh": "^0.4.20",
    "globals": "^15.15.0",
    "nitro": "3.0.260603-beta",
    "prettier": "^3.7.3",
    "typescript": "^5.8.3",
    "typescript-eslint": "^8.56.1",
    "vite": "8.1.5"
  }
}

```

## FILE 2: bunfig.toml

```toml
[install]
saveTextLockfile = true
# 24h supply-chain guard: skip package versions published less than a day ago.
minimumReleaseAge = 86400
# Each entry bypasses the 24h guard for one package — confirm with the user
# before adding any.
minimumReleaseAgeExcludes = ["@lovable.dev/vite-tanstack-config", "@lovable.dev/mcp-js", "@lovable.dev/email-js", "@lovable.dev/webhooks-js"]

```

## FILE 3: tsconfig.json

```json
{
  "include": ["src/**/*.ts", "src/**/*.tsx", "vite.config.ts", "eslint.config.js"],
  "compilerOptions": {
    "target": "ES2022",
    "jsx": "react-jsx",
    "module": "ESNext",
    "lib": ["ES2022", "DOM", "DOM.Iterable"],
    "types": ["vite/client"],

    "moduleResolution": "Bundler",
    "allowImportingTsExtensions": true,
    "verbatimModuleSyntax": false,
    "noEmit": true,

    "skipLibCheck": true,
    "strict": true,
    "noUnusedLocals": false,
    "noUnusedParameters": false,
    "noFallthroughCasesInSwitch": true,
    "noImplicitOverride": true,
    "noImplicitReturns": true,
    "noPropertyAccessFromIndexSignature": true,
    "noUncheckedIndexedAccess": true,
    "exactOptionalPropertyTypes": true,
    "noUncheckedSideEffectImports": true,
    "paths": {
      "@/*": ["./src/*"]
    }
  }
}

```

## FILE 4: vite.config.ts

```ts
// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - TanStack devtools (dev-only, first), tanstackStart, viteReact, tailwindcss, tsConfigPaths,
//     nitro (build-only using cloudflare as a default target), VITE_* env injection, @ path alias,
//     React/TanStack dedupe, error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

export default defineConfig({
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
});

```

## FILE 5: components.json

```json
{
  "$schema": "https://ui.shadcn.com/schema.json",
  "style": "new-york",
  "rsc": false,
  "tsx": true,
  "tailwind": {
    "css": "src/styles.css",
    "baseColor": "slate",
    "cssVariables": true,
    "prefix": ""
  },
  "iconLibrary": "lucide",
  "rtl": false,
  "aliases": {
    "components": "@/components",
    "utils": "@/lib/utils",
    "ui": "@/components/ui",
    "lib": "@/lib",
    "hooks": "@/hooks"
  },
  "registries": {}
}

```

## FILE 6: eslint.config.js

```js
import js from "@eslint/js";
import eslintPluginPrettier from "eslint-plugin-prettier/recommended";
import globals from "globals";
import reactHooks from "eslint-plugin-react-hooks";
import reactRefresh from "eslint-plugin-react-refresh";
import tseslint from "typescript-eslint";

export default tseslint.config(
  { ignores: ["dist", ".output", ".vinxi"] },
  {
    extends: [js.configs.recommended, ...tseslint.configs.recommended],
    files: ["**/*.{ts,tsx}"],
    languageOptions: {
      ecmaVersion: 2020,
      globals: globals.browser,
    },
    plugins: {
      "react-hooks": reactHooks,
      "react-refresh": reactRefresh,
    },
    rules: {
      ...reactHooks.configs.recommended.rules,
      "no-restricted-imports": [
        "error",
        {
          paths: [
            {
              name: "server-only",
              message:
                "TanStack Start does not use the Next.js `server-only` package. Rename the module to `*.server.ts` or mark it with `@tanstack/react-start/server-only`.",
            },
          ],
        },
      ],
      "react-refresh/only-export-components": ["warn", { allowConstantExport: true }],
      "@typescript-eslint/no-unused-vars": "off",
    },
  },
  eslintPluginPrettier,
);

```

## FILE 7: .prettierrc

```text
{
  "printWidth": 100,
  "semi": true,
  "singleQuote": false,
  "trailingComma": "all"
}

```

## FILE 8: .prettierignore

```text
node_modules
dist
.output
.vinxi
pnpm-lock.yaml
package-lock.json
bun.lock
routeTree.gen.ts

```

## FILE 9: README.md

```md
# Welcome to your Lovable project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS

```

## FILE 10: AGENTS.md

```md
<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

```

## FILE 11: public/robots.txt

```text
User-agent: Googlebot
Allow: /

User-agent: Bingbot
Allow: /

User-agent: Twitterbot
Allow: /

User-agent: facebookexternalhit
Allow: /

User-agent: *
Allow: /

```

## FILE 12: src/styles.css

```css
@import "tailwindcss" source(none);
@source "../src";
@import "tw-animate-css";

@custom-variant dark (&:is(.dark *));

/*
 * Design system definition.
 *
 * The @theme inline block maps CSS custom properties to Tailwind utility
 * classes (e.g. --color-primary -> bg-primary, text-primary).
 *
 * The :root and .dark blocks define the actual color values using oklch.
 * All colors MUST use oklch format.
 *
 * To add a new semantic color:
 * 1. Add the variable to :root (light value) and .dark (dark value)
 * 2. Register it in @theme inline as --color-<name>: var(--<name>)
 */

@theme inline {
  --radius-sm: calc(var(--radius) - 4px);
  --radius-md: calc(var(--radius) - 2px);
  --radius-lg: var(--radius);
  --radius-xl: calc(var(--radius) + 4px);
  --radius-2xl: calc(var(--radius) + 8px);
  --radius-3xl: calc(var(--radius) + 12px);
  --radius-4xl: calc(var(--radius) + 16px);
  --color-background: var(--background);
  --color-foreground: var(--foreground);
  --color-card: var(--card);
  --color-card-foreground: var(--card-foreground);
  --color-popover: var(--popover);
  --color-popover-foreground: var(--popover-foreground);
  --color-primary: var(--primary);
  --color-primary-foreground: var(--primary-foreground);
  --color-secondary: var(--secondary);
  --color-secondary-foreground: var(--secondary-foreground);
  --color-muted: var(--muted);
  --color-muted-foreground: var(--muted-foreground);
  --color-accent: var(--accent);
  --color-accent-foreground: var(--accent-foreground);
  --color-destructive: var(--destructive);
  --color-destructive-foreground: var(--destructive-foreground);
  --color-border: var(--border);
  --color-input: var(--input);
  --color-ring: var(--ring);
  --color-ring-offset-background: var(--background);
  --color-chart-1: var(--chart-1);
  --color-chart-2: var(--chart-2);
  --color-chart-3: var(--chart-3);
  --color-chart-4: var(--chart-4);
  --color-chart-5: var(--chart-5);
  --color-sidebar: var(--sidebar);
  --color-sidebar-foreground: var(--sidebar-foreground);
  --color-sidebar-primary: var(--sidebar-primary);
  --color-sidebar-primary-foreground: var(--sidebar-primary-foreground);
  --color-sidebar-accent: var(--sidebar-accent);
  --color-sidebar-accent-foreground: var(--sidebar-accent-foreground);
  --color-sidebar-border: var(--sidebar-border);
  --color-sidebar-ring: var(--sidebar-ring);
  --color-success: var(--success);
  --color-success-foreground: var(--success-foreground);
  --color-warning: var(--warning);
  --color-warning-foreground: var(--warning-foreground);
  --color-info: var(--info);
  --color-info-foreground: var(--info-foreground);
  --color-saffron: var(--saffron);
  --color-navy: var(--navy);
}

:root {
  --radius: 0.75rem;
  --background: oklch(0.98 0.005 250);
  --foreground: oklch(0.22 0.04 259);
  --card: oklch(1 0 0);
  --card-foreground: oklch(0.22 0.04 259);
  --popover: oklch(1 0 0);
  --popover-foreground: oklch(0.22 0.04 259);
  --primary: oklch(0.33 0.09 264);
  --primary-foreground: oklch(0.99 0.005 250);
  --secondary: oklch(0.955 0.012 250);
  --secondary-foreground: oklch(0.33 0.09 264);
  --muted: oklch(0.958 0.008 250);
  --muted-foreground: oklch(0.52 0.03 258);
  --accent: oklch(0.7 0.17 55);
  --accent-foreground: oklch(0.22 0.04 259);
  --destructive: oklch(0.58 0.21 25);
  --destructive-foreground: oklch(0.99 0.005 250);
  --success: oklch(0.58 0.14 155);
  --success-foreground: oklch(0.99 0.005 250);
  --warning: oklch(0.75 0.15 75);
  --warning-foreground: oklch(0.25 0.04 259);
  --info: oklch(0.6 0.12 240);
  --info-foreground: oklch(0.99 0.005 250);
  --saffron: oklch(0.7 0.17 55);
  --navy: oklch(0.33 0.09 264);
  --border: oklch(0.9 0.012 252);
  --input: oklch(0.9 0.012 252);
  --ring: oklch(0.55 0.09 264);
  --chart-1: oklch(0.4 0.1 262);
  --chart-2: oklch(0.7 0.17 55);
  --chart-3: oklch(0.58 0.14 155);
  --chart-4: oklch(0.62 0.11 235);
  --chart-5: oklch(0.6 0.19 25);
  --sidebar: oklch(0.27 0.06 264);
  --sidebar-foreground: oklch(0.95 0.01 250);
  --sidebar-primary: oklch(0.7 0.17 55);
  --sidebar-primary-foreground: oklch(0.2 0.04 259);
  --sidebar-accent: oklch(0.34 0.06 264);
  --sidebar-accent-foreground: oklch(0.98 0.005 250);
  --sidebar-border: oklch(1 0 0 / 12%);
  --sidebar-ring: oklch(0.7 0.17 55);
}

.dark {
  --background: oklch(0.129 0.042 264.695);
  --foreground: oklch(0.984 0.003 247.858);
  --card: oklch(0.208 0.042 265.755);
  --card-foreground: oklch(0.984 0.003 247.858);
  --popover: oklch(0.208 0.042 265.755);
  --popover-foreground: oklch(0.984 0.003 247.858);
  --primary: oklch(0.929 0.013 255.508);
  --primary-foreground: oklch(0.208 0.042 265.755);
  --secondary: oklch(0.279 0.041 260.031);
  --secondary-foreground: oklch(0.984 0.003 247.858);
  --muted: oklch(0.279 0.041 260.031);
  --muted-foreground: oklch(0.704 0.04 256.788);
  --accent: oklch(0.279 0.041 260.031);
  --accent-foreground: oklch(0.984 0.003 247.858);
  --destructive: oklch(0.704 0.191 22.216);
  --destructive-foreground: oklch(0.984 0.003 247.858);
  --border: oklch(1 0 0 / 10%);
  --input: oklch(1 0 0 / 15%);
  --ring: oklch(0.551 0.027 264.364);
  --chart-1: oklch(0.488 0.243 264.376);
  --chart-2: oklch(0.696 0.17 162.48);
  --chart-3: oklch(0.769 0.188 70.08);
  --chart-4: oklch(0.627 0.265 303.9);
  --chart-5: oklch(0.645 0.246 16.439);
  --sidebar: oklch(0.208 0.042 265.755);
  --sidebar-foreground: oklch(0.984 0.003 247.858);
  --sidebar-primary: oklch(0.488 0.243 264.376);
  --sidebar-primary-foreground: oklch(0.984 0.003 247.858);
  --sidebar-accent: oklch(0.279 0.041 260.031);
  --sidebar-accent-foreground: oklch(0.984 0.003 247.858);
  --sidebar-border: oklch(1 0 0 / 10%);
  --sidebar-ring: oklch(0.551 0.027 264.364);
}

@layer base {
  * {
    border-color: var(--color-border);
  }

  body {
    background-color: var(--color-background);
    color: var(--color-foreground);
  }
}

@layer base {
  html {
    -webkit-font-smoothing: antialiased;
  }
  h1, h2, h3, h4 {
    letter-spacing: -0.015em;
  }
  :focus-visible {
    outline: 2px solid var(--ring);
    outline-offset: 2px;
  }
}

@utility gov-gradient {
  background-image: linear-gradient(135deg, oklch(0.27 0.07 264) 0%, oklch(0.33 0.09 264) 55%, oklch(0.42 0.1 60) 160%);
}

```

## FILE 13: src/types/index.ts

```ts
export type Role = "admin" | "provider" | "trainee" | "employer";

export type TrainingStatus = "In Training" | "Completed" | "Dropped Out";

export type EmploymentStatus =
  | "Employed"
  | "Self-employed"
  | "Apprenticeship"
  | "Seeking Employment"
  | "Further Education"
  | "Unreachable";

export type NonPlacementReason =
  | "Lack of required skills"
  | "Lack of suitable jobs"
  | "Salary too low"
  | "Location constraints"
  | "Personal reasons"
  | "Further education"
  | "Health/family reasons"
  | "Not interested"
  | "Other";

export type ConsentStatus = "Granted" | "Partial" | "Withdrawn";

export type FollowUpMilestone = "3 months" | "6 months" | "12 months";

export type FollowUpStatus = "Completed" | "Due" | "Pending" | "Unreachable";

export interface TimelineEvent {
  id: string;
  label: string;
  date: string;
  status: "done" | "current" | "upcoming";
  detail: string;
}

export interface FollowUp {
  id: string;
  milestone: FollowUpMilestone;
  dueDate: string;
  completedDate?: string | undefined;
  status: FollowUpStatus;
  employmentStatus?: EmploymentStatus | undefined;
  salary?: number | undefined;
  skillsUsed?: string[] | undefined;
  satisfaction?: number | undefined;
  notes?: string | undefined;
}

export interface Employment {
  employerId?: string | undefined;
  employerName?: string | undefined;
  jobTitle?: string | undefined;
  joiningDate?: string | undefined;
  salary?: number | undefined;
  employmentType?: "Full-time" | "Part-time" | "Contract" | "Apprenticeship" | "Self-employed" | undefined;
  location?: string | undefined;
  verified?: boolean | undefined;
  businessType?: string | undefined;
  businessStartDate?: string | undefined;
  monthlyIncome?: number | undefined;
  businessStatus?: "Active" | "Growing" | "Struggling" | undefined;
}

export interface Trainee {
  id: string;
  name: string;
  age: number;
  gender: "Male" | "Female" | "Other";
  district: string;
  education: string;
  contactReachable: boolean;
  consent: ConsentStatus;
  consentDate: string;
  dataSharing: { analytics: boolean; employers: boolean; research: boolean };
  courseId: string;
  providerId: string;
  trainingCenter: string;
  startDate: string;
  endDate: string;
  attendance: number;
  assessmentScore: number;
  certified: boolean;
  trainingStatus: TrainingStatus;
  employmentStatus: EmploymentStatus;
  nonPlacementReason?: NonPlacementReason | undefined;
  employment: Employment;
  salaryProgression: { point: string; salary: number }[];
  followUps: FollowUp[];
  timeline: TimelineEvent[];
  trainingYear: number;
  satisfaction: number;
  email?: string | undefined;
}

export interface Course {
  id: string;
  name: string;
  sector: string;
  durationWeeks: number;
  skills: string[];
}

export interface Provider {
  id: string;
  name: string;
  district: string;
  courses: string[];
  rating: number;
  accreditation: "A+" | "A" | "B" | "C";
}

export interface Employer {
  id: string;
  name: string;
  sector: string;
  district: string;
  status: "Verified" | "Pending Verification" | "Needs Review";
  skillRequirements: string[];
  feedback: string;
  rating: number;
}

export interface DemoUser {
  email: string;
  name: string;
  role: Role;
  password: string;
  providerId?: string | undefined;
  traineeId?: string | undefined;
  employerId?: string | undefined;
}

export interface Filters {
  district: string;
  courseId: string;
  providerId: string;
  gender: string;
  ageGroup: string;
  trainingYear: string;
  employmentStatus: string;
}

```

## FILE 14: src/lib/utils.ts

```ts
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

```

## FILE 15: src/auth/auth-context.tsx

```tsx
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

import { DEMO_USERS } from "@/data/seed";
import type { DemoUser, Role } from "@/types";

const SESSION_KEY = "mahaskilltrack:session:v1";

export interface SessionUser {
  email: string;
  name: string;
  role: Role;
  providerId?: string | undefined;
  traineeId?: string | undefined;
  employerId?: string | undefined;
}

interface AuthValue {
  user: SessionUser | null;
  hydrated: boolean;
  signIn: (email: string, password: string) => { ok: boolean; error?: string; role?: Role };
  signOut: () => void;
}

const AuthContext = createContext<AuthValue | null>(null);

function toSession(u: DemoUser): SessionUser {
  return {
    email: u.email,
    name: u.name,
    role: u.role,
    providerId: u.providerId,
    traineeId: u.traineeId,
    employerId: u.employerId,
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(SESSION_KEY);
      if (raw) setUser(JSON.parse(raw) as SessionUser);
    } catch {
      /* ignore */
    }
    setHydrated(true);
  }, []);

  const signIn = useCallback((email: string, password: string) => {
    const match = DEMO_USERS.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
    if (!match) return { ok: false, error: "No demo account found for this email address." };
    if (match.password !== password) return { ok: false, error: "Incorrect password." };
    const session = toSession(match);
    setUser(session);
    try {
      window.localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    } catch {
      /* ignore */
    }
    return { ok: true, role: match.role };
  }, []);

  const signOut = useCallback(() => {
    setUser(null);
    try {
      window.localStorage.removeItem(SESSION_KEY);
    } catch {
      /* ignore */
    }
  }, []);

  const value = useMemo<AuthValue>(() => ({ user, hydrated, signIn, signOut }), [user, hydrated, signIn, signOut]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}

export const ROLE_LABEL: Record<Role, string> = {
  admin: "Government Administrator",
  provider: "Training Provider",
  trainee: "Trainee",
  employer: "Employer",
};

```

## FILE 16: src/components/charts/dashboard-charts.tsx

```tsx
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const AXIS = { fontSize: 12, fill: "var(--muted-foreground)" };

const TOOLTIP_STYLE = {
  contentStyle: {
    borderRadius: 12,
    border: "1px solid var(--border)",
    background: "var(--card)",
    fontSize: 12,
    color: "var(--foreground)",
  },
} as const;

export const OUTCOME_COLORS: Record<string, string> = {
  Employed: "var(--success)",
  "Self-employed": "var(--saffron)",
  Apprenticeship: "var(--info)",
  "Seeking Employment": "var(--warning)",
  "Further Education": "var(--chart-1)",
  Unreachable: "var(--destructive)",
};

export function OutcomeDonut({ data }: { data: { name: string; value: number }[] }) {
  const total = data.reduce((a, d) => a + d.value, 0);
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            innerRadius="55%"
            outerRadius="82%"
            paddingAngle={2}
            stroke="var(--card)"
          >
            {data.map((d) => (
              <Cell key={d.name} fill={OUTCOME_COLORS[d.name] ?? "var(--chart-1)"} />
            ))}
          </Pie>
          <Tooltip
            {...TOOLTIP_STYLE}
            formatter={(value: number, name) => [
              `${value} trainees (${total ? Math.round((value / total) * 100) : 0}%)`,
              name as string,
            ]}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} iconType="circle" />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

export function DistrictBars({
  data,
}: {
  data: { district: string; employmentRate: number; avgSalary: number }[];
}) {
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ left: -18, right: 8, top: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
          <XAxis dataKey="district" tick={AXIS} interval={0} angle={-25} textAnchor="end" height={54} />
          <YAxis tick={AXIS} unit="%" />
          <Tooltip {...TOOLTIP_STYLE} formatter={(v: number) => [`${v}%`, "Employment rate"]} />
          <Bar dataKey="employmentRate" fill="var(--chart-1)" radius={[6, 6, 0, 0]} maxBarSize={44} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function RetentionLine({ data }: { data: { milestone: string; retention: number }[] }) {
  return (
    <div className="h-[280px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ left: -18, right: 12, top: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
          <XAxis dataKey="milestone" tick={AXIS} />
          <YAxis tick={AXIS} unit="%" domain={[0, 100]} />
          <Tooltip {...TOOLTIP_STYLE} formatter={(v: number) => [`${v}%`, "Retention"]} />
          <Line
            type="monotone"
            dataKey="retention"
            stroke="var(--success)"
            strokeWidth={2.5}
            dot={{ r: 4, fill: "var(--success)" }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function SalaryLine({
  data,
  height = 280,
}: {
  data: { point: string; salary: number }[];
  height?: number;
}) {
  return (
    <div style={{ height }} className="w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ left: 4, right: 12, top: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
          <XAxis dataKey="point" tick={AXIS} />
          <YAxis tick={AXIS} tickFormatter={(v: number) => `₹${Math.round(v / 1000)}k`} />
          <Tooltip
            {...TOOLTIP_STYLE}
            formatter={(v: number) => [`₹${v.toLocaleString("en-IN")}`, "Average salary"]}
          />
          <Line
            type="monotone"
            dataKey="salary"
            stroke="var(--saffron)"
            strokeWidth={2.5}
            dot={{ r: 4, fill: "var(--saffron)" }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function SkillGapBars({
  data,
}: {
  data: { skill: string; demand: number; coverage: number }[];
}) {
  return (
    <div className="h-[360px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ left: 30, right: 16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
          <XAxis type="number" tick={AXIS} unit="%" domain={[0, 100]} />
          <YAxis type="category" dataKey="skill" tick={AXIS} width={110} />
          <Tooltip {...TOOLTIP_STYLE} formatter={(v: number, n) => [`${v}%`, n as string]} />
          <Legend wrapperStyle={{ fontSize: 12 }} iconType="circle" />
          <Bar name="Employer demand" dataKey="demand" fill="var(--chart-1)" radius={[0, 5, 5, 0]} />
          <Bar name="Training coverage" dataKey="coverage" fill="var(--saffron)" radius={[0, 5, 5, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function CourseComparisonBars({
  data,
}: {
  data: { course: string; placementRate: number; retention12: number }[];
}) {
  return (
    <div className="h-[340px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ left: -18, right: 8, top: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
          <XAxis dataKey="course" tick={AXIS} interval={0} angle={-20} textAnchor="end" height={70} />
          <YAxis tick={AXIS} unit="%" />
          <Tooltip {...TOOLTIP_STYLE} formatter={(v: number, n) => [`${v}%`, n as string]} />
          <Legend wrapperStyle={{ fontSize: 12 }} iconType="circle" />
          <Bar name="Placement rate" dataKey="placementRate" fill="var(--chart-1)" radius={[5, 5, 0, 0]} />
          <Bar name="12-month retention" dataKey="retention12" fill="var(--success)" radius={[5, 5, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function ReasonBars({ data }: { data: { reason: string; count: number }[] }) {
  return (
    <div className="h-[320px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ left: 60, right: 16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
          <XAxis type="number" tick={AXIS} allowDecimals={false} />
          <YAxis type="category" dataKey="reason" tick={{ ...AXIS, fontSize: 11 }} width={150} />
          <Tooltip {...TOOLTIP_STYLE} formatter={(v: number) => [`${v} trainees`, "Reported"]} />
          <Bar dataKey="count" fill="var(--destructive)" radius={[0, 5, 5, 0]} maxBarSize={26} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

```

## FILE 17: src/components/common/chart-card.tsx

```tsx
import type { ReactNode } from "react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export function ChartCard({
  title,
  description,
  action,
  children,
  className,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardHeader className="flex flex-row flex-wrap items-start justify-between gap-3">
        <div>
          <CardTitle className="text-base">{title}</CardTitle>
          {description ? <CardDescription>{description}</CardDescription> : null}
        </div>
        {action}
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}

```

## FILE 18: src/components/common/filter-bar.tsx

```tsx
import { RotateCcw, SlidersHorizontal } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DISTRICTS } from "@/data/seed";
import { AGE_GROUPS, EMPTY_FILTERS } from "@/services/analytics";
import { useStore } from "@/services/store";
import type { Filters } from "@/types";

const STATUSES = [
  "Employed",
  "Self-employed",
  "Apprenticeship",
  "Seeking Employment",
  "Further Education",
  "Unreachable",
];

export function FilterBar({
  filters,
  onChange,
  hideProvider = false,
}: {
  filters: Filters;
  onChange: (f: Filters) => void;
  hideProvider?: boolean;
}) {
  const { courses, providers } = useStore();
  const set = (key: keyof Filters, value: string) => onChange({ ...filters, [key]: value });
  const active = Object.entries(filters).filter(([, v]) => v !== "all").length;

  const field = (
    id: keyof Filters,
    label: string,
    options: { value: string; label: string }[],
  ) => (
    <div className="space-y-1.5">
      <Label htmlFor={`filter-${id}`} className="text-xs text-muted-foreground">
        {label}
      </Label>
      <Select value={filters[id]} onValueChange={(v) => set(id, v)}>
        <SelectTrigger id={`filter-${id}`} className="w-full">
          <SelectValue placeholder={`All ${label}`} />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All {label}</SelectItem>
          {options.map((o) => (
            <SelectItem key={o.value} value={o.value}>
              {o.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );

  return (
    <Card>
      <CardContent className="space-y-4 p-4 sm:p-5">
        <div className="flex items-center justify-between gap-3">
          <p className="flex items-center gap-2 text-sm font-semibold text-foreground">
            <SlidersHorizontal className="size-4 text-muted-foreground" aria-hidden />
            Filters
            {active > 0 ? (
              <span className="rounded-full bg-accent/20 px-2 py-0.5 text-xs font-medium text-accent-foreground">
                {active} active
              </span>
            ) : null}
          </p>
          <Button variant="outline" size="sm" onClick={() => onChange({ ...EMPTY_FILTERS })}>
            <RotateCcw className="mr-1.5 size-3.5" aria-hidden />
            Reset Filters
          </Button>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {field(
            "district",
            "Districts",
            DISTRICTS.map((d) => ({ value: d, label: d })),
          )}
          {field(
            "courseId",
            "Courses",
            courses.map((c) => ({ value: c.id, label: c.name })),
          )}
          {!hideProvider
            ? field(
                "providerId",
                "Providers",
                providers.map((p) => ({ value: p.id, label: p.name })),
              )
            : null}
          {field("gender", "Genders", [
            { value: "Male", label: "Male" },
            { value: "Female", label: "Female" },
          ])}
          {field(
            "ageGroup",
            "Age groups",
            AGE_GROUPS.map((a) => ({ value: a, label: a })),
          )}
          {field("trainingYear", "Training years", [
            { value: "2025", label: "2025" },
            { value: "2024", label: "2024" },
          ])}
          {field(
            "employmentStatus",
            "Statuses",
            STATUSES.map((s) => ({ value: s, label: s })),
          )}
        </div>
      </CardContent>
    </Card>
  );
}

```

## FILE 19: src/components/common/page-header.tsx

```tsx
import type { ReactNode } from "react";

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description: string;
  actions?: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-foreground">{title}</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{description}</p>
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}

```

## FILE 20: src/components/common/stat-card.tsx

```tsx
import { TrendingDown, TrendingUp } from "lucide-react";
import type { LucideIcon } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export interface StatCardProps {
  label: string;
  value: string;
  description: string;
  icon: LucideIcon;
  change?: number;
  accent?: "navy" | "saffron" | "success" | "info";
}

const ACCENTS = {
  navy: "bg-primary/10 text-primary",
  saffron: "bg-accent/15 text-accent-foreground",
  success: "bg-success/10 text-success",
  info: "bg-info/10 text-info",
};

export function StatCard({
  label,
  value,
  description,
  icon: Icon,
  change,
  accent = "navy",
}: StatCardProps) {
  const positive = (change ?? 0) >= 0;
  const Trend = positive ? TrendingUp : TrendingDown;
  return (
    <Card className="group relative overflow-hidden transition-shadow hover:shadow-md">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="truncate text-sm font-medium text-muted-foreground">{label}</p>
            <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">
              {value}
            </p>
          </div>
          <span className={cn("grid size-10 shrink-0 place-items-center rounded-xl", ACCENTS[accent])}>
            <Icon className="size-5" aria-hidden />
          </span>
        </div>
        <div className="mt-3 flex items-center gap-2 text-xs">
          {change !== undefined ? (
            <span
              className={cn(
                "inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 font-medium",
                positive ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive",
              )}
            >
              <Trend className="size-3" aria-hidden />
              {positive ? "+" : ""}
              {change}%
            </span>
          ) : null}
          <span className="truncate text-muted-foreground">{description}</span>
        </div>
      </CardContent>
    </Card>
  );
}

```

## FILE 21: src/components/common/states.tsx

```tsx
import { AlertTriangle, Inbox, Loader2 } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export function LoadingState({ label = "Loading data…" }: { label?: string }) {
  return (
    <div className="space-y-4" role="status" aria-live="polite">
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="size-4 animate-spin" aria-hidden />
        {label}
      </div>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-28 rounded-xl" />
        ))}
      </div>
    </div>
  );
}

export function EmptyState({
  title,
  description,
  icon: Icon = Inbox,
  action,
}: {
  title: string;
  description: string;
  icon?: LucideIcon;
  action?: ReactNode;
}) {
  return (
    <Card className="border-dashed">
      <CardContent className="flex flex-col items-center gap-3 px-6 py-12 text-center">
        <span className="grid size-12 place-items-center rounded-full bg-muted">
          <Icon className="size-6 text-muted-foreground" aria-hidden />
        </span>
        <div>
          <p className="font-semibold text-foreground">{title}</p>
          <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>
        </div>
        {action}
      </CardContent>
    </Card>
  );
}

export function ErrorState({
  title = "We couldn't load this section",
  description = "Please retry. If the problem persists, contact the MSSDM support desk.",
  onRetry,
}: {
  title?: string;
  description?: string;
  onRetry?: () => void;
}) {
  return (
    <Card className="border-destructive/40 bg-destructive/5">
      <CardContent className="flex flex-col items-center gap-3 px-6 py-12 text-center">
        <AlertTriangle className="size-8 text-destructive" aria-hidden />
        <div>
          <p className="font-semibold text-foreground">{title}</p>
          <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>
        </div>
        {onRetry ? (
          <Button variant="outline" onClick={onRetry}>
            Try again
          </Button>
        ) : null}
      </CardContent>
    </Card>
  );
}

```

## FILE 22: src/components/common/status-badge.tsx

```tsx
import {
  Award,
  BadgeCheck,
  Briefcase,
  BookOpen,
  Clock,
  GraduationCap,
  PhoneOff,
  Search,
  Store,
  XCircle,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

import { cn } from "@/lib/utils";

type Tone = "success" | "info" | "warning" | "danger" | "neutral" | "accent";

const TONES: Record<Tone, string> = {
  success: "bg-success/10 text-success border-success/30",
  info: "bg-info/10 text-info border-info/30",
  warning: "bg-warning/15 text-warning-foreground border-warning/40",
  danger: "bg-destructive/10 text-destructive border-destructive/30",
  neutral: "bg-muted text-muted-foreground border-border",
  accent: "bg-accent/15 text-accent-foreground border-accent/40",
};

const MAP: Record<string, { tone: Tone; icon: LucideIcon }> = {
  Employed: { tone: "success", icon: Briefcase },
  "Self-employed": { tone: "accent", icon: Store },
  Apprenticeship: { tone: "info", icon: Award },
  "Seeking Employment": { tone: "warning", icon: Search },
  "Further Education": { tone: "info", icon: GraduationCap },
  Unreachable: { tone: "danger", icon: PhoneOff },
  Completed: { tone: "success", icon: BadgeCheck },
  "In Training": { tone: "info", icon: BookOpen },
  "Dropped Out": { tone: "danger", icon: XCircle },
  Due: { tone: "warning", icon: Clock },
  Pending: { tone: "neutral", icon: Clock },
  Verified: { tone: "success", icon: BadgeCheck },
  "Pending Verification": { tone: "warning", icon: Clock },
  "Needs Review": { tone: "danger", icon: XCircle },
  Granted: { tone: "success", icon: BadgeCheck },
  Partial: { tone: "warning", icon: Clock },
  Withdrawn: { tone: "danger", icon: XCircle },
  High: { tone: "danger", icon: XCircle },
  Medium: { tone: "warning", icon: Clock },
  Low: { tone: "success", icon: BadgeCheck },
};

export function StatusBadge({
  status,
  className,
  showIcon = true,
}: {
  status: string;
  className?: string;
  showIcon?: boolean;
}) {
  const config = MAP[status] ?? { tone: "neutral" as Tone, icon: Clock };
  const Icon = config.icon;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium whitespace-nowrap",
        TONES[config.tone],
        className,
      )}
    >
      {showIcon ? <Icon className="size-3.5 shrink-0" aria-hidden /> : null}
      {status}
    </span>
  );
}

```

## FILE 23: src/components/common/timeline.tsx

```tsx
import { Check, Circle, Dot } from "lucide-react";

import { cn } from "@/lib/utils";
import type { TimelineEvent } from "@/types";

export function Timeline({ events }: { events: TimelineEvent[] }) {
  return (
    <ol className="relative space-y-0">
      {events.map((event, i) => {
        const last = i === events.length - 1;
        return (
          <li key={event.id} className="relative flex gap-4 pb-6 last:pb-0">
            {!last ? (
              <span
                aria-hidden
                className={cn(
                  "absolute top-8 left-[15px] h-full w-0.5",
                  event.status === "done" ? "bg-success/40" : "bg-border",
                )}
              />
            ) : null}
            <span
              className={cn(
                "relative z-10 grid size-8 shrink-0 place-items-center rounded-full border-2 bg-card",
                event.status === "done" && "border-success text-success",
                event.status === "current" && "border-accent text-accent-foreground",
                event.status === "upcoming" && "border-border text-muted-foreground",
              )}
            >
              {event.status === "done" ? (
                <Check className="size-4" aria-hidden />
              ) : event.status === "current" ? (
                <Circle className="size-3.5 fill-current" aria-hidden />
              ) : (
                <Dot className="size-4" aria-hidden />
              )}
            </span>
            <div className="min-w-0 flex-1 rounded-lg border border-border/70 bg-muted/30 px-4 py-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-medium text-foreground">{event.label}</p>
                <p className="text-xs font-medium text-muted-foreground tabular-nums">{event.date}</p>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{event.detail}</p>
              <span className="sr-only">Status: {event.status}</span>
            </div>
          </li>
        );
      })}
    </ol>
  );
}

```

## FILE 24: src/components/forms/follow-up-dialog.tsx

```tsx
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useStore } from "@/services/store";
import type { EmploymentStatus, FollowUpStatus, Trainee } from "@/types";

const STATUSES: EmploymentStatus[] = [
  "Employed",
  "Self-employed",
  "Apprenticeship",
  "Seeking Employment",
  "Further Education",
  "Unreachable",
];

const OUTCOMES: FollowUpStatus[] = ["Completed", "Unreachable", "Pending"];

export function FollowUpDialog({
  trainee,
  followUpId,
  onClose,
}: {
  trainee: Trainee;
  followUpId: string | null;
  onClose: () => void;
}) {
  const { recordFollowUp } = useStore();
  const followUp = trainee.followUps.find((f) => f.id === followUpId);

  const [status, setStatus] = useState<FollowUpStatus>("Completed");
  const [employmentStatus, setEmploymentStatus] = useState<EmploymentStatus>(
    trainee.employmentStatus,
  );
  const [salary, setSalary] = useState("");
  const [satisfaction, setSatisfaction] = useState("4");
  const [notes, setNotes] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!followUp) return;
    setStatus(followUp.status === "Completed" ? "Completed" : "Completed");
    setEmploymentStatus(followUp.employmentStatus ?? trainee.employmentStatus);
    setSalary(followUp.salary ? String(followUp.salary) : "");
    setSatisfaction(String(followUp.satisfaction ?? 4));
    setNotes(followUp.notes ?? "");
    setError(null);
  }, [followUp, trainee.employmentStatus]);

  if (!followUp) return null;

  const needsSalary =
    status === "Completed" &&
    ["Employed", "Self-employed", "Apprenticeship"].includes(employmentStatus);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (needsSalary && (!Number(salary) || Number(salary) < 1000)) {
      setError("Enter the current monthly income (min ₹1,000).");
      return;
    }
    recordFollowUp(trainee.id, followUp.id, {
      status,
      completedDate: status === "Completed" ? new Date().toISOString().slice(0, 10) : undefined,
      employmentStatus: status === "Completed" ? employmentStatus : undefined,
      salary: needsSalary ? Number(salary) : undefined,
      satisfaction: status === "Completed" ? Number(satisfaction) : undefined,
      notes: notes.trim() || undefined,
    });
    toast.success(`${followUp.milestone} follow-up recorded`, {
      description: `${trainee.name} · ${status === "Completed" ? employmentStatus : status}`,
    });
    onClose();
  };

  return (
    <Dialog open onOpenChange={(o) => (!o ? onClose() : undefined)}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Record {followUp.milestone} follow-up</DialogTitle>
          <DialogDescription>
            {trainee.name} · {trainee.id} · due {followUp.dueDate}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4" noValidate>
          <div className="space-y-1.5">
            <Label htmlFor="fu-status">Follow-up result</Label>
            <Select value={status} onValueChange={(v) => setStatus(v as FollowUpStatus)}>
              <SelectTrigger id="fu-status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {OUTCOMES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s === "Completed" ? "Contacted successfully" : s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {status === "Completed" ? (
            <>
              <div className="space-y-1.5">
                <Label htmlFor="fu-employment">Employment status at this milestone</Label>
                <Select
                  value={employmentStatus}
                  onValueChange={(v) => setEmploymentStatus(v as EmploymentStatus)}
                >
                  <SelectTrigger id="fu-employment">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUSES.map((s) => (
                      <SelectItem key={s} value={s}>
                        {s}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                {needsSalary ? (
                  <div className="space-y-1.5">
                    <Label htmlFor="fu-salary">Current monthly income (₹)</Label>
                    <Input
                      id="fu-salary"
                      type="number"
                      min={1000}
                      value={salary}
                      onChange={(e) => setSalary(e.target.value)}
                      required
                    />
                  </div>
                ) : null}
                <div className="space-y-1.5">
                  <Label htmlFor="fu-satisfaction">Satisfaction (1–5)</Label>
                  <Select value={satisfaction} onValueChange={setSatisfaction}>
                    <SelectTrigger id="fu-satisfaction">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5].map((n) => (
                        <SelectItem key={n} value={String(n)}>
                          {n}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </>
          ) : null}

          <div className="space-y-1.5">
            <Label htmlFor="fu-notes">Notes</Label>
            <Textarea
              id="fu-notes"
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Observations from the call, skills used on the job, support needed…"
            />
          </div>

          {error ? (
            <p role="alert" className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
              {error}
            </p>
          ) : null}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">Save follow-up</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

```

## FILE 25: src/components/forms/outcome-dialog.tsx

```tsx
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useStore } from "@/services/store";
import type { EmploymentStatus, NonPlacementReason, Trainee } from "@/types";

const STATUSES: EmploymentStatus[] = [
  "Employed",
  "Self-employed",
  "Apprenticeship",
  "Seeking Employment",
  "Further Education",
  "Unreachable",
];

const REASONS: NonPlacementReason[] = [
  "Lack of required skills",
  "Lack of suitable jobs",
  "Salary too low",
  "Location constraints",
  "Personal reasons",
  "Further education",
  "Health/family reasons",
  "Not interested",
  "Other",
];

export function OutcomeDialog({
  trainee,
  open,
  onOpenChange,
}: {
  trainee: Trainee;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { updateOutcome, employers } = useStore();
  const [status, setStatus] = useState<EmploymentStatus>(trainee.employmentStatus);
  const [employerId, setEmployerId] = useState(trainee.employment.employerId ?? "");
  const [jobTitle, setJobTitle] = useState(trainee.employment.jobTitle ?? "");
  const [salary, setSalary] = useState(
    String(trainee.employment.salary ?? trainee.employment.monthlyIncome ?? ""),
  );
  const [joiningDate, setJoiningDate] = useState(trainee.employment.joiningDate ?? "");
  const [location, setLocation] = useState(trainee.employment.location ?? trainee.district);
  const [reason, setReason] = useState<string>(trainee.nonPlacementReason ?? "");
  const [error, setError] = useState<string | null>(null);

  const placed = status === "Employed" || status === "Self-employed" || status === "Apprenticeship";

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (placed) {
      if (!jobTitle.trim()) return setError("Enter the job title or business type.");
      const amount = Number(salary);
      if (!amount || amount < 1000) return setError("Enter a valid monthly income (min ₹1,000).");
      if (!joiningDate) return setError("Select the start date.");
    } else if (!reason) {
      return setError("Select a reason for non-placement.");
    }

    const employer = employers.find((x) => x.id === employerId);
    updateOutcome(trainee.id, {
      employmentStatus: status,
      nonPlacementReason: placed ? undefined : (reason as NonPlacementReason),
      employment: placed
        ? {
            ...trainee.employment,
            employerId: status === "Self-employed" ? undefined : employerId || undefined,
            employerName: status === "Self-employed" ? "Self-employed" : employer?.name,
            jobTitle,
            joiningDate,
            location,
            salary: status === "Self-employed" ? undefined : Number(salary),
            monthlyIncome: status === "Self-employed" ? Number(salary) : undefined,
            employmentType:
              status === "Apprenticeship"
                ? "Apprenticeship"
                : status === "Self-employed"
                  ? "Self-employed"
                  : "Full-time",
            verified: false,
          }
        : { ...trainee.employment },
    });
    toast.success("Outcome updated", {
      description: `${trainee.name} is now recorded as ${status}.`,
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Update employment outcome</DialogTitle>
          <DialogDescription>
            {trainee.name} · {trainee.id} · {trainee.district}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4" noValidate>
          <div className="space-y-1.5">
            <Label htmlFor="outcome-status">Employment status</Label>
            <Select value={status} onValueChange={(v) => setStatus(v as EmploymentStatus)}>
              <SelectTrigger id="outcome-status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {STATUSES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {placed ? (
            <>
              {status !== "Self-employed" ? (
                <div className="space-y-1.5">
                  <Label htmlFor="outcome-employer">Employer</Label>
                  <Select value={employerId} onValueChange={setEmployerId}>
                    <SelectTrigger id="outcome-employer">
                      <SelectValue placeholder="Select employer" />
                    </SelectTrigger>
                    <SelectContent>
                      {employers.map((e) => (
                        <SelectItem key={e.id} value={e.id}>
                          {e.name} · {e.district}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ) : null}
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="outcome-title">
                    {status === "Self-employed" ? "Business type" : "Job title"}
                  </Label>
                  <Input
                    id="outcome-title"
                    value={jobTitle}
                    onChange={(e) => setJobTitle(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="outcome-salary">Monthly income (₹)</Label>
                  <Input
                    id="outcome-salary"
                    type="number"
                    min={1000}
                    value={salary}
                    onChange={(e) => setSalary(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="outcome-date">Start date</Label>
                  <Input
                    id="outcome-date"
                    type="date"
                    value={joiningDate}
                    onChange={(e) => setJoiningDate(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="outcome-location">Work location</Label>
                  <Input
                    id="outcome-location"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                  />
                </div>
              </div>
            </>
          ) : (
            <div className="space-y-1.5">
              <Label htmlFor="outcome-reason">Reason for non-placement</Label>
              <Select value={reason} onValueChange={setReason}>
                <SelectTrigger id="outcome-reason">
                  <SelectValue placeholder="Select a reason" />
                </SelectTrigger>
                <SelectContent>
                  {REASONS.map((r) => (
                    <SelectItem key={r} value={r}>
                      {r}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {error ? (
            <p role="alert" className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
              {error}
            </p>
          ) : null}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">Save outcome</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

```

## FILE 26: src/components/layout/app-shell.tsx

```tsx
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  BarChart3,
  Bell,
  Briefcase,
  Building2,
  ClipboardList,
  FileText,
  GraduationCap,
  LayoutDashboard,
  LogOut,
  Menu,
  Puzzle,
  Settings,
  ShieldCheck,
  TrendingUp,
  Users,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useState, type ReactNode } from "react";

import { ROLE_LABEL, useAuth } from "@/auth/auth-context";
import { NOTIFICATIONS } from "@/data/seed";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import type { Role } from "@/types";

interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
  roles: Role[];
}

const NAV: NavItem[] = [
  { to: "/app/dashboard", label: "Dashboard", icon: LayoutDashboard, roles: ["admin", "provider", "trainee", "employer"] },
  { to: "/app/trainees", label: "Trainees", icon: Users, roles: ["admin", "provider", "employer"] },
  { to: "/app/programs", label: "Training Programs", icon: GraduationCap, roles: ["admin", "provider"] },
  { to: "/app/providers", label: "Training Providers", icon: Building2, roles: ["admin"] },
  { to: "/app/employers", label: "Employers", icon: Briefcase, roles: ["admin", "employer"] },
  { to: "/app/outcomes", label: "Employment Outcomes", icon: TrendingUp, roles: ["admin", "provider", "employer"] },
  { to: "/app/followups", label: "Follow-ups", icon: ClipboardList, roles: ["admin", "provider", "trainee"] },
  { to: "/app/skill-gaps", label: "Skill Gaps", icon: Puzzle, roles: ["admin", "provider", "employer"] },
  { to: "/app/analytics", label: "Analytics", icon: BarChart3, roles: ["admin", "provider"] },
  { to: "/app/reports", label: "Reports", icon: FileText, roles: ["admin", "provider"] },
  { to: "/app/consent", label: "Consent & Privacy", icon: ShieldCheck, roles: ["admin", "trainee"] },
  { to: "/app/settings", label: "Settings", icon: Settings, roles: ["admin", "provider", "trainee", "employer"] },
];

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-3 rounded-lg px-1 py-1">
      <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-accent font-bold text-accent-foreground">
        M
      </span>
      {!compact ? (
        <span className="min-w-0">
          <span className="block truncate text-sm font-semibold text-sidebar-foreground">
            MahaSkillTrack
          </span>
          <span className="block truncate text-[11px] text-sidebar-foreground/60">
            Outcome Intelligence
          </span>
        </span>
      ) : null}
    </Link>
  );
}

function SidebarNav({ role, onNavigate }: { role: Role; onNavigate?: () => void }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const items = NAV.filter((n) => n.roles.includes(role));
  return (
    <nav aria-label="Main navigation" className="space-y-1 px-3 pb-6">
      {items.map((item) => {
        const active = pathname === item.to || pathname.startsWith(`${item.to}/`);
        return (
          <Link
            key={item.to}
            to={item.to}
            onClick={onNavigate}
            aria-current={active ? "page" : undefined}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
              active
                ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-sm ring-1 ring-sidebar-border"
                : "text-sidebar-foreground/75 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground",
            )}
          >
            <item.icon className={cn("size-4 shrink-0", active && "text-sidebar-primary")} aria-hidden />
            <span className="truncate">{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const role = user?.role ?? "admin";

  return (
    <div className="min-h-screen bg-background">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:rounded-md focus:bg-primary focus:px-3 focus:py-2 focus:text-primary-foreground"
      >
        Skip to content
      </a>
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-sidebar-border bg-sidebar lg:flex">
        <div className="px-4 py-5">
          <Brand />
        </div>
        <div className="flex-1 overflow-y-auto">
          <SidebarNav role={role} />
        </div>
        <div className="border-t border-sidebar-border px-4 py-4 text-[11px] leading-relaxed text-sidebar-foreground/60">
          Maharashtra State Skill Development Mission
          <br />
          Demo environment · synthetic data
        </div>
      </aside>

      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 border-b border-border bg-card/90 backdrop-blur">
          <div className="flex h-16 items-center gap-3 px-4 sm:px-6">
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Open navigation">
                  <Menu className="size-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-72 border-sidebar-border bg-sidebar p-0">
                <SheetTitle className="sr-only">Navigation</SheetTitle>
                <div className="px-4 py-5">
                  <Brand />
                </div>
                <SidebarNav role={role} onNavigate={() => setMobileOpen(false)} />
              </SheetContent>
            </Sheet>

            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-foreground sm:text-base">
                MahaSkillTrack
              </p>
              <p className="hidden truncate text-xs text-muted-foreground sm:block">
                Maharashtra Skill Development Outcome Intelligence
              </p>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative" aria-label="Notifications">
                  <Bell className="size-5" />
                  <span className="absolute top-1.5 right-1.5 size-2 rounded-full bg-destructive" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80">
                <DropdownMenuLabel>Notifications</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {NOTIFICATIONS.map((n) => (
                  <DropdownMenuItem key={n.id} className="flex-col items-start gap-1 py-2.5">
                    <span className="flex w-full items-start justify-between gap-2">
                      <span className="text-sm font-medium whitespace-normal">{n.title}</span>
                      <span className="shrink-0 text-[10px] text-muted-foreground">{n.time}</span>
                    </span>
                    <span className="text-xs whitespace-normal text-muted-foreground">{n.detail}</span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="h-11 gap-2 px-2">
                  <span className="grid size-8 shrink-0 place-items-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">
                    {(user?.name ?? "GA")
                      .split(" ")
                      .map((p) => p[0])
                      .slice(0, 2)
                      .join("")}
                  </span>
                  <span className="hidden text-left sm:block">
                    <span className="block max-w-36 truncate text-sm font-medium">{user?.name}</span>
                    <span className="block text-[11px] text-muted-foreground">
                      {ROLE_LABEL[role]}
                    </span>
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-60">
                <DropdownMenuLabel className="space-y-1">
                  <span className="block text-sm">{user?.name}</span>
                  <span className="block text-xs font-normal text-muted-foreground">{user?.email}</span>
                  <Badge variant="secondary" className="mt-1">
                    {ROLE_LABEL[role]}
                  </Badge>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link to="/app/settings">Settings</Link>
                </DropdownMenuItem>
                <DropdownMenuItem
                  onSelect={() => {
                    signOut();
                    void navigate({ to: "/login" });
                  }}
                >
                  <LogOut className="mr-2 size-4" aria-hidden />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>
        <main id="main-content" className="px-4 py-6 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-7xl space-y-6">{children}</div>
        </main>
      </div>
    </div>
  );
}

```

## FILE 27: src/components/ui/accordion.tsx

```tsx
import * as React from "react";
import * as AccordionPrimitive from "@radix-ui/react-accordion";
import { ChevronDown } from "lucide-react";

import { cn } from "@/lib/utils";

const Accordion = AccordionPrimitive.Root;

const AccordionItem = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Item>
>(({ className, ...props }, ref) => (
  <AccordionPrimitive.Item ref={ref} className={cn("border-b", className)} {...props} />
));
AccordionItem.displayName = "AccordionItem";

const AccordionTrigger = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Trigger>
>(({ className, children, ...props }, ref) => (
  <AccordionPrimitive.Header className="flex">
    <AccordionPrimitive.Trigger
      ref={ref}
      className={cn(
        "flex flex-1 items-center justify-between py-4 text-sm font-medium cursor-pointer transition-all hover:underline text-left [&[data-state=open]>svg]:rotate-180",
        className,
      )}
      {...props}
    >
      {children}
      <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200" />
    </AccordionPrimitive.Trigger>
  </AccordionPrimitive.Header>
));
AccordionTrigger.displayName = AccordionPrimitive.Trigger.displayName;

const AccordionContent = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Content>
>(({ className, children, ...props }, ref) => (
  <AccordionPrimitive.Content
    ref={ref}
    className="overflow-hidden text-sm data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down"
    {...props}
  >
    <div className={cn("pb-4 pt-0", className)}>{children}</div>
  </AccordionPrimitive.Content>
));
AccordionContent.displayName = AccordionPrimitive.Content.displayName;

export { Accordion, AccordionItem, AccordionTrigger, AccordionContent };

```

## FILE 28: src/components/ui/alert-dialog.tsx

```tsx
import * as React from "react";
import * as AlertDialogPrimitive from "@radix-ui/react-alert-dialog";

import { cn } from "@/lib/utils";
import { buttonVariants } from "@/components/ui/button";

const AlertDialog = AlertDialogPrimitive.Root;

const AlertDialogTrigger = AlertDialogPrimitive.Trigger;

const AlertDialogPortal = AlertDialogPrimitive.Portal;

const AlertDialogOverlay = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Overlay
    className={cn(
      "fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className,
    )}
    {...props}
    ref={ref}
  />
));
AlertDialogOverlay.displayName = AlertDialogPrimitive.Overlay.displayName;

const AlertDialogContent = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Content>
>(({ className, ...props }, ref) => (
  <AlertDialogPortal>
    <AlertDialogOverlay />
    <AlertDialogPrimitive.Content
      ref={ref}
      className={cn(
        "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg",
        className,
      )}
      {...props}
    />
  </AlertDialogPortal>
));
AlertDialogContent.displayName = AlertDialogPrimitive.Content.displayName;

const AlertDialogHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("flex flex-col space-y-2 text-center sm:text-left", className)} {...props} />
);
AlertDialogHeader.displayName = "AlertDialogHeader";

const AlertDialogFooter = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className)}
    {...props}
  />
);
AlertDialogFooter.displayName = "AlertDialogFooter";

const AlertDialogTitle = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Title>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Title
    ref={ref}
    className={cn("text-lg font-semibold", className)}
    {...props}
  />
));
AlertDialogTitle.displayName = AlertDialogPrimitive.Title.displayName;

const AlertDialogDescription = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Description>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Description
    ref={ref}
    className={cn("text-sm text-muted-foreground", className)}
    {...props}
  />
));
AlertDialogDescription.displayName = AlertDialogPrimitive.Description.displayName;

const AlertDialogAction = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Action>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Action>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Action ref={ref} className={cn(buttonVariants(), className)} {...props} />
));
AlertDialogAction.displayName = AlertDialogPrimitive.Action.displayName;

const AlertDialogCancel = React.forwardRef<
  React.ElementRef<typeof AlertDialogPrimitive.Cancel>,
  React.ComponentPropsWithoutRef<typeof AlertDialogPrimitive.Cancel>
>(({ className, ...props }, ref) => (
  <AlertDialogPrimitive.Cancel
    ref={ref}
    className={cn(buttonVariants({ variant: "outline" }), "mt-2 sm:mt-0", className)}
    {...props}
  />
));
AlertDialogCancel.displayName = AlertDialogPrimitive.Cancel.displayName;

export {
  AlertDialog,
  AlertDialogPortal,
  AlertDialogOverlay,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogAction,
  AlertDialogCancel,
};

```

## FILE 29: src/components/ui/alert.tsx

```tsx
import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const alertVariants = cva(
  "relative w-full rounded-lg border px-4 py-3 text-sm [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground [&>svg~*]:pl-7",
  {
    variants: {
      variant: {
        default: "bg-background text-foreground",
        destructive:
          "border-destructive/50 text-destructive dark:border-destructive [&>svg]:text-destructive",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

const Alert = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & VariantProps<typeof alertVariants>
>(({ className, variant, ...props }, ref) => (
  <div ref={ref} role="alert" className={cn(alertVariants({ variant }), className)} {...props} />
));
Alert.displayName = "Alert";

const AlertTitle = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLHeadingElement>>(
  ({ className, ...props }, ref) => (
    <h5
      ref={ref}
      className={cn("mb-1 font-medium leading-none tracking-tight", className)}
      {...props}
    />
  ),
);
AlertTitle.displayName = "AlertTitle";

const AlertDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("text-sm [&_p]:leading-relaxed", className)} {...props} />
));
AlertDescription.displayName = "AlertDescription";

export { Alert, AlertTitle, AlertDescription };

```

## FILE 30: src/components/ui/aspect-ratio.tsx

```tsx
import * as AspectRatioPrimitive from "@radix-ui/react-aspect-ratio";

const AspectRatio = AspectRatioPrimitive.Root;

export { AspectRatio };

```

## FILE 31: src/components/ui/avatar.tsx

```tsx
"use client";

import * as React from "react";
import * as AvatarPrimitive from "@radix-ui/react-avatar";

import { cn } from "@/lib/utils";

const Avatar = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Root>
>(({ className, ...props }, ref) => (
  <AvatarPrimitive.Root
    ref={ref}
    className={cn("relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full", className)}
    {...props}
  />
));
Avatar.displayName = AvatarPrimitive.Root.displayName;

const AvatarImage = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Image>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Image>
>(({ className, ...props }, ref) => (
  <AvatarPrimitive.Image
    ref={ref}
    className={cn("aspect-square h-full w-full", className)}
    {...props}
  />
));
AvatarImage.displayName = AvatarPrimitive.Image.displayName;

const AvatarFallback = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Fallback>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Fallback>
>(({ className, ...props }, ref) => (
  <AvatarPrimitive.Fallback
    ref={ref}
    className={cn(
      "flex h-full w-full items-center justify-center rounded-full bg-muted",
      className,
    )}
    {...props}
  />
));
AvatarFallback.displayName = AvatarPrimitive.Fallback.displayName;

export { Avatar, AvatarImage, AvatarFallback };

```

## FILE 32: src/components/ui/badge.tsx

```tsx
import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
        secondary:
          "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
        destructive:
          "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
        outline: "text-foreground",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };

```

## FILE 33: src/components/ui/breadcrumb.tsx

```tsx
import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { ChevronRight, MoreHorizontal } from "lucide-react";

import { cn } from "@/lib/utils";

const Breadcrumb = React.forwardRef<
  HTMLElement,
  React.ComponentPropsWithoutRef<"nav"> & {
    separator?: React.ReactNode;
  }
>(({ ...props }, ref) => <nav ref={ref} aria-label="breadcrumb" {...props} />);
Breadcrumb.displayName = "Breadcrumb";

const BreadcrumbList = React.forwardRef<HTMLOListElement, React.ComponentPropsWithoutRef<"ol">>(
  ({ className, ...props }, ref) => (
    <ol
      ref={ref}
      className={cn(
        "flex flex-wrap items-center gap-1.5 break-words text-sm text-muted-foreground sm:gap-2.5",
        className,
      )}
      {...props}
    />
  ),
);
BreadcrumbList.displayName = "BreadcrumbList";

const BreadcrumbItem = React.forwardRef<HTMLLIElement, React.ComponentPropsWithoutRef<"li">>(
  ({ className, ...props }, ref) => (
    <li ref={ref} className={cn("inline-flex items-center gap-1.5", className)} {...props} />
  ),
);
BreadcrumbItem.displayName = "BreadcrumbItem";

const BreadcrumbLink = React.forwardRef<
  HTMLAnchorElement,
  React.ComponentPropsWithoutRef<"a"> & {
    asChild?: boolean;
  }
>(({ asChild, className, ...props }, ref) => {
  const Comp = asChild ? Slot : "a";

  return (
    <Comp
      ref={ref}
      className={cn("transition-colors hover:text-foreground", className)}
      {...props}
    />
  );
});
BreadcrumbLink.displayName = "BreadcrumbLink";

const BreadcrumbPage = React.forwardRef<HTMLSpanElement, React.ComponentPropsWithoutRef<"span">>(
  ({ className, ...props }, ref) => (
    <span
      ref={ref}
      role="link"
      aria-disabled="true"
      aria-current="page"
      className={cn("font-normal text-foreground", className)}
      {...props}
    />
  ),
);
BreadcrumbPage.displayName = "BreadcrumbPage";

const BreadcrumbSeparator = ({ children, className, ...props }: React.ComponentProps<"li">) => (
  <li
    role="presentation"
    aria-hidden="true"
    className={cn("[&>svg]:w-3.5 [&>svg]:h-3.5", className)}
    {...props}
  >
    {children ?? <ChevronRight />}
  </li>
);
BreadcrumbSeparator.displayName = "BreadcrumbSeparator";

const BreadcrumbEllipsis = ({ className, ...props }: React.ComponentProps<"span">) => (
  <span
    role="presentation"
    aria-hidden="true"
    className={cn("flex h-9 w-9 items-center justify-center", className)}
    {...props}
  >
    <MoreHorizontal className="h-4 w-4" />
    <span className="sr-only">More</span>
  </span>
);
BreadcrumbEllipsis.displayName = "BreadcrumbElipssis";

export {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbPage,
  BreadcrumbSeparator,
  BreadcrumbEllipsis,
};

```

## FILE 34: src/components/ui/button.tsx

```tsx
import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
        outline:
          "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-md px-3 text-xs",
        lg: "h-10 rounded-md px-8",
        icon: "h-9 w-9",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />
    );
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };

```

## FILE 35: src/components/ui/calendar.tsx

```tsx
"use client";

import * as React from "react";
import { ChevronDownIcon, ChevronLeftIcon, ChevronRightIcon } from "lucide-react";
import { DayButton, DayPicker, getDefaultClassNames } from "react-day-picker";

import { cn } from "@/lib/utils";
import { Button, buttonVariants } from "@/components/ui/button";

function Calendar({
  className,
  classNames,
  showOutsideDays = true,
  captionLayout = "label",
  buttonVariant = "ghost",
  formatters,
  components,
  ...props
}: React.ComponentProps<typeof DayPicker> & {
  buttonVariant?: React.ComponentProps<typeof Button>["variant"];
}) {
  const defaultClassNames = getDefaultClassNames();

  return (
    <DayPicker
      showOutsideDays={showOutsideDays}
      className={cn(
        "bg-background group/calendar p-3 [--cell-size:2rem] [[data-slot=card-content]_&]:bg-transparent [[data-slot=popover-content]_&]:bg-transparent",
        String.raw`rtl:**:[.rdp-button\_next>svg]:rotate-180`,
        String.raw`rtl:**:[.rdp-button\_previous>svg]:rotate-180`,
        className,
      )}
      captionLayout={captionLayout}
      formatters={{
        formatMonthDropdown: (date) => date.toLocaleString("default", { month: "short" }),
        ...formatters,
      }}
      classNames={{
        root: cn("w-fit", defaultClassNames.root),
        months: cn("relative flex flex-col gap-4 md:flex-row", defaultClassNames.months),
        month: cn("flex w-full flex-col gap-4", defaultClassNames.month),
        nav: cn(
          "absolute inset-x-0 top-0 flex w-full items-center justify-between gap-1",
          defaultClassNames.nav,
        ),
        button_previous: cn(
          buttonVariants({ variant: buttonVariant }),
          "h-(--cell-size) w-(--cell-size) select-none p-0 aria-disabled:opacity-50",
          defaultClassNames.button_previous,
        ),
        button_next: cn(
          buttonVariants({ variant: buttonVariant }),
          "h-(--cell-size) w-(--cell-size) select-none p-0 aria-disabled:opacity-50",
          defaultClassNames.button_next,
        ),
        month_caption: cn(
          "flex h-(--cell-size) w-full items-center justify-center px-(--cell-size)",
          defaultClassNames.month_caption,
        ),
        dropdowns: cn(
          "flex h-(--cell-size) w-full items-center justify-center gap-1.5 text-sm font-medium",
          defaultClassNames.dropdowns,
        ),
        dropdown_root: cn(
          "has-focus:border-ring border-input shadow-xs has-focus:ring-ring/50 has-focus:ring-[3px] relative rounded-md border",
          defaultClassNames.dropdown_root,
        ),
        dropdown: cn("bg-popover absolute inset-0 opacity-0", defaultClassNames.dropdown),
        caption_label: cn(
          "select-none font-medium",
          captionLayout === "label"
            ? "text-sm"
            : "[&>svg]:text-muted-foreground flex h-8 items-center gap-1 rounded-md pl-2 pr-1 text-sm [&>svg]:size-3.5",
          defaultClassNames.caption_label,
        ),
        table: "w-full border-collapse",
        weekdays: cn("flex", defaultClassNames.weekdays),
        weekday: cn(
          "text-muted-foreground flex-1 select-none rounded-md text-[0.8rem] font-normal",
          defaultClassNames.weekday,
        ),
        week: cn("mt-2 flex w-full", defaultClassNames.week),
        week_number_header: cn("w-(--cell-size) select-none", defaultClassNames.week_number_header),
        week_number: cn(
          "text-muted-foreground select-none text-[0.8rem]",
          defaultClassNames.week_number,
        ),
        day: cn(
          "group/day relative aspect-square h-full w-full select-none p-0 text-center [&:first-child[data-selected=true]_button]:rounded-l-md [&:last-child[data-selected=true]_button]:rounded-r-md",
          defaultClassNames.day,
        ),
        range_start: cn("bg-accent rounded-l-md", defaultClassNames.range_start),
        range_middle: cn("rounded-none", defaultClassNames.range_middle),
        range_end: cn("bg-accent rounded-r-md", defaultClassNames.range_end),
        today: cn(
          "bg-accent text-accent-foreground rounded-md data-[selected=true]:rounded-none",
          defaultClassNames.today,
        ),
        outside: cn(
          "text-muted-foreground aria-selected:text-muted-foreground",
          defaultClassNames.outside,
        ),
        disabled: cn("text-muted-foreground opacity-50", defaultClassNames.disabled),
        hidden: cn("invisible", defaultClassNames.hidden),
        ...classNames,
      }}
      components={{
        Root: ({ className, rootRef, ...props }) => {
          return <div data-slot="calendar" ref={rootRef} className={cn(className)} {...props} />;
        },
        Chevron: ({ className, orientation, ...props }) => {
          if (orientation === "left") {
            return <ChevronLeftIcon className={cn("size-4", className)} {...props} />;
          }

          if (orientation === "right") {
            return <ChevronRightIcon className={cn("size-4", className)} {...props} />;
          }

          return <ChevronDownIcon className={cn("size-4", className)} {...props} />;
        },
        DayButton: CalendarDayButton,
        WeekNumber: ({ children, ...props }) => {
          return (
            <td {...props}>
              <div className="flex size-(--cell-size) items-center justify-center text-center">
                {children}
              </div>
            </td>
          );
        },
        ...components,
      }}
      {...props}
    />
  );
}

function CalendarDayButton({
  className,
  day,
  modifiers,
  ...props
}: React.ComponentProps<typeof DayButton>) {
  const defaultClassNames = getDefaultClassNames();

  const ref = React.useRef<HTMLButtonElement>(null);
  React.useEffect(() => {
    if (modifiers["focused"]) ref.current?.focus();
  }, [modifiers]);

  return (
    <Button
      ref={ref}
      variant="ghost"
      size="icon"
      data-day={day.date.toLocaleDateString()}
      data-selected-single={
        modifiers["selected"] &&
        !modifiers["range_start"] &&
        !modifiers["range_end"] &&
        !modifiers["range_middle"]
      }
      data-range-start={modifiers["range_start"]}
      data-range-end={modifiers["range_end"]}
      data-range-middle={modifiers["range_middle"]}
      className={cn(
        "data-[selected-single=true]:bg-primary data-[selected-single=true]:text-primary-foreground data-[range-middle=true]:bg-accent data-[range-middle=true]:text-accent-foreground data-[range-start=true]:bg-primary data-[range-start=true]:text-primary-foreground data-[range-end=true]:bg-primary data-[range-end=true]:text-primary-foreground group-data-[focused=true]/day:border-ring group-data-[focused=true]/day:ring-ring/50 flex aspect-square h-auto w-full min-w-(--cell-size) flex-col gap-1 font-normal leading-none data-[range-end=true]:rounded-md data-[range-middle=true]:rounded-none data-[range-start=true]:rounded-md group-data-[focused=true]/day:relative group-data-[focused=true]/day:z-10 group-data-[focused=true]/day:ring-[3px] [&>span]:text-xs [&>span]:opacity-70",
        defaultClassNames.day,
        className,
      )}
      {...props}
    />
  );
}

export { Calendar, CalendarDayButton };

```

## FILE 36: src/components/ui/card.tsx

```tsx
import * as React from "react";

import { cn } from "@/lib/utils";

const Card = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn("rounded-xl border bg-card text-card-foreground shadow", className)}
      {...props}
    />
  ),
);
Card.displayName = "Card";

const CardHeader = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("flex flex-col space-y-1.5 p-6", className)} {...props} />
  ),
);
CardHeader.displayName = "CardHeader";

const CardTitle = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn("font-semibold leading-none tracking-tight", className)}
      {...props}
    />
  ),
);
CardTitle.displayName = "CardTitle";

const CardDescription = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("text-sm text-muted-foreground", className)} {...props} />
  ),
);
CardDescription.displayName = "CardDescription";

const CardContent = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("p-6 pt-0", className)} {...props} />
  ),
);
CardContent.displayName = "CardContent";

const CardFooter = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("flex items-center p-6 pt-0", className)} {...props} />
  ),
);
CardFooter.displayName = "CardFooter";

export { Card, CardHeader, CardFooter, CardTitle, CardDescription, CardContent };

```

## FILE 37: src/components/ui/carousel.tsx

```tsx
import * as React from "react";
import useEmblaCarousel, { type UseEmblaCarouselType } from "embla-carousel-react";
import { ArrowLeft, ArrowRight } from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

type CarouselApi = UseEmblaCarouselType[1];
type UseCarouselParameters = Parameters<typeof useEmblaCarousel>;
type CarouselOptions = UseCarouselParameters[0];
type CarouselPlugin = UseCarouselParameters[1];

type CarouselProps = {
  opts?: CarouselOptions;
  plugins?: CarouselPlugin;
  orientation?: "horizontal" | "vertical";
  setApi?: (api: CarouselApi) => void;
};

type CarouselContextProps = {
  carouselRef: ReturnType<typeof useEmblaCarousel>[0];
  api: ReturnType<typeof useEmblaCarousel>[1];
  scrollPrev: () => void;
  scrollNext: () => void;
  canScrollPrev: boolean;
  canScrollNext: boolean;
} & CarouselProps;

const CarouselContext = React.createContext<CarouselContextProps | null>(null);

function useCarousel() {
  const context = React.useContext(CarouselContext);

  if (!context) {
    throw new Error("useCarousel must be used within a <Carousel />");
  }

  return context;
}

const Carousel = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & CarouselProps
>(({ orientation = "horizontal", opts, setApi, plugins, className, children, ...props }, ref) => {
  const [carouselRef, api] = useEmblaCarousel(
    {
      ...opts,
      axis: orientation === "horizontal" ? "x" : "y",
    },
    plugins,
  );
  const [canScrollPrev, setCanScrollPrev] = React.useState(false);
  const [canScrollNext, setCanScrollNext] = React.useState(false);

  const onSelect = React.useCallback((api: CarouselApi) => {
    if (!api) {
      return;
    }

    setCanScrollPrev(api.canScrollPrev());
    setCanScrollNext(api.canScrollNext());
  }, []);

  const scrollPrev = React.useCallback(() => {
    api?.scrollPrev();
  }, [api]);

  const scrollNext = React.useCallback(() => {
    api?.scrollNext();
  }, [api]);

  const handleKeyDown = React.useCallback(
    (event: React.KeyboardEvent<HTMLDivElement>) => {
      if (event.key === "ArrowLeft") {
        event.preventDefault();
        scrollPrev();
      } else if (event.key === "ArrowRight") {
        event.preventDefault();
        scrollNext();
      }
    },
    [scrollPrev, scrollNext],
  );

  React.useEffect(() => {
    if (!api || !setApi) {
      return;
    }

    setApi(api);
  }, [api, setApi]);

  React.useEffect(() => {
    if (!api) {
      return;
    }

    onSelect(api);
    api.on("reInit", onSelect);
    api.on("select", onSelect);

    return () => {
      api?.off("select", onSelect);
    };
  }, [api, onSelect]);

  return (
    <CarouselContext.Provider
      value={{
        carouselRef,
        api: api,
        opts,
        orientation: orientation || (opts?.axis === "y" ? "vertical" : "horizontal"),
        scrollPrev,
        scrollNext,
        canScrollPrev,
        canScrollNext,
      }}
    >
      <div
        ref={ref}
        onKeyDownCapture={handleKeyDown}
        className={cn("relative", className)}
        role="region"
        aria-roledescription="carousel"
        {...props}
      >
        {children}
      </div>
    </CarouselContext.Provider>
  );
});
Carousel.displayName = "Carousel";

const CarouselContent = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => {
    const { carouselRef, orientation } = useCarousel();

    return (
      <div ref={carouselRef} className="overflow-hidden">
        <div
          ref={ref}
          className={cn(
            "flex",
            orientation === "horizontal" ? "-ml-4" : "-mt-4 flex-col",
            className,
          )}
          {...props}
        />
      </div>
    );
  },
);
CarouselContent.displayName = "CarouselContent";

const CarouselItem = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => {
    const { orientation } = useCarousel();

    return (
      <div
        ref={ref}
        role="group"
        aria-roledescription="slide"
        className={cn(
          "min-w-0 shrink-0 grow-0 basis-full",
          orientation === "horizontal" ? "pl-4" : "pt-4",
          className,
        )}
        {...props}
      />
    );
  },
);
CarouselItem.displayName = "CarouselItem";

const CarouselPrevious = React.forwardRef<HTMLButtonElement, React.ComponentProps<typeof Button>>(
  ({ className, variant = "outline", size = "icon", ...props }, ref) => {
    const { orientation, scrollPrev, canScrollPrev } = useCarousel();

    return (
      <Button
        ref={ref}
        variant={variant}
        size={size}
        className={cn(
          "absolute  h-8 w-8 rounded-full",
          orientation === "horizontal"
            ? "-left-12 top-1/2 -translate-y-1/2"
            : "-top-12 left-1/2 -translate-x-1/2 rotate-90",
          className,
        )}
        disabled={!canScrollPrev}
        onClick={scrollPrev}
        {...props}
      >
        <ArrowLeft className="h-4 w-4" />
        <span className="sr-only">Previous slide</span>
      </Button>
    );
  },
);
CarouselPrevious.displayName = "CarouselPrevious";

const CarouselNext = React.forwardRef<HTMLButtonElement, React.ComponentProps<typeof Button>>(
  ({ className, variant = "outline", size = "icon", ...props }, ref) => {
    const { orientation, scrollNext, canScrollNext } = useCarousel();

    return (
      <Button
        ref={ref}
        variant={variant}
        size={size}
        className={cn(
          "absolute h-8 w-8 rounded-full",
          orientation === "horizontal"
            ? "-right-12 top-1/2 -translate-y-1/2"
            : "-bottom-12 left-1/2 -translate-x-1/2 rotate-90",
          className,
        )}
        disabled={!canScrollNext}
        onClick={scrollNext}
        {...props}
      >
        <ArrowRight className="h-4 w-4" />
        <span className="sr-only">Next slide</span>
      </Button>
    );
  },
);
CarouselNext.displayName = "CarouselNext";

export {
  type CarouselApi,
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselPrevious,
  CarouselNext,
};

```

## FILE 38: src/components/ui/chart.tsx

```tsx
import * as React from "react";
import * as RechartsPrimitive from "recharts";

import { cn } from "@/lib/utils";

// Format: { THEME_NAME: CSS_SELECTOR }
const THEMES = { light: "", dark: ".dark" } as const;

export type ChartConfig = {
  [k in string]: {
    label?: React.ReactNode;
    icon?: React.ComponentType;
  } & (
    | { color?: string; theme?: never }
    | { color?: never; theme: Record<keyof typeof THEMES, string> }
  );
};

type ChartContextProps = {
  config: ChartConfig;
};

const ChartContext = React.createContext<ChartContextProps | null>(null);

function useChart() {
  const context = React.useContext(ChartContext);

  if (!context) {
    throw new Error("useChart must be used within a <ChartContainer />");
  }

  return context;
}

const ChartContainer = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div"> & {
    config: ChartConfig;
    children: React.ComponentProps<typeof RechartsPrimitive.ResponsiveContainer>["children"];
  }
>(({ id, className, children, config, ...props }, ref) => {
  const uniqueId = React.useId();
  const chartId = `chart-${id || uniqueId.replace(/:/g, "")}`;

  return (
    <ChartContext.Provider value={{ config }}>
      <div
        data-chart={chartId}
        ref={ref}
        className={cn(
          "flex aspect-video justify-center text-xs [&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground [&_.recharts-cartesian-grid_line[stroke='#ccc']]:stroke-border/50 [&_.recharts-curve.recharts-tooltip-cursor]:stroke-border [&_.recharts-dot[stroke='#fff']]:stroke-transparent [&_.recharts-layer]:outline-none [&_.recharts-polar-grid_[stroke='#ccc']]:stroke-border [&_.recharts-radial-bar-background-sector]:fill-muted [&_.recharts-rectangle.recharts-tooltip-cursor]:fill-muted [&_.recharts-reference-line_[stroke='#ccc']]:stroke-border [&_.recharts-sector[stroke='#fff']]:stroke-transparent [&_.recharts-sector]:outline-none [&_.recharts-surface]:outline-none",
          className,
        )}
        {...props}
      >
        <ChartStyle id={chartId} config={config} />
        <RechartsPrimitive.ResponsiveContainer>{children}</RechartsPrimitive.ResponsiveContainer>
      </div>
    </ChartContext.Provider>
  );
});
ChartContainer.displayName = "Chart";

const ChartStyle = ({ id, config }: { id: string; config: ChartConfig }) => {
  const colorConfig = Object.entries(config).filter(([, config]) => config.theme || config.color);

  if (!colorConfig.length) {
    return null;
  }

  return (
    <style
      dangerouslySetInnerHTML={{
        __html: Object.entries(THEMES)
          .map(
            ([theme, prefix]) => `
${prefix} [data-chart=${id}] {
${colorConfig
  .map(([key, itemConfig]) => {
    const color = itemConfig.theme?.[theme as keyof typeof itemConfig.theme] || itemConfig.color;
    return color ? `  --color-${key}: ${color};` : null;
  })
  .join("\n")}
}
`,
          )
          .join("\n"),
      }}
    />
  );
};

const ChartTooltip = RechartsPrimitive.Tooltip;

const ChartTooltipContent = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<typeof RechartsPrimitive.Tooltip> &
    React.ComponentProps<"div"> & {
      hideLabel?: boolean;
      hideIndicator?: boolean;
      indicator?: "line" | "dot" | "dashed";
      nameKey?: string;
      labelKey?: string;
    }
>(
  (
    {
      active,
      payload,
      className,
      indicator = "dot",
      hideLabel = false,
      hideIndicator = false,
      label,
      labelFormatter,
      labelClassName,
      formatter,
      color,
      nameKey,
      labelKey,
    },
    ref,
  ) => {
    const { config } = useChart();

    const tooltipLabel = React.useMemo(() => {
      if (hideLabel || !payload?.length) {
        return null;
      }

      const [item] = payload;
      const key = `${labelKey || item?.dataKey || item?.name || "value"}`;
      const itemConfig = getPayloadConfigFromPayload(config, item, key);
      const value =
        !labelKey && typeof label === "string"
          ? config[label as keyof typeof config]?.label || label
          : itemConfig?.label;

      if (labelFormatter) {
        return (
          <div className={cn("font-medium", labelClassName)}>{labelFormatter(value, payload)}</div>
        );
      }

      if (!value) {
        return null;
      }

      return <div className={cn("font-medium", labelClassName)}>{value}</div>;
    }, [label, labelFormatter, payload, hideLabel, labelClassName, config, labelKey]);

    if (!active || !payload?.length) {
      return null;
    }

    const nestLabel = payload.length === 1 && indicator !== "dot";

    return (
      <div
        ref={ref}
        className={cn(
          "grid min-w-[8rem] items-start gap-1.5 rounded-lg border border-border/50 bg-background px-2.5 py-1.5 text-xs shadow-xl",
          className,
        )}
      >
        {!nestLabel ? tooltipLabel : null}
        <div className="grid gap-1.5">
          {payload
            .filter((item) => item.type !== "none")
            .map((item, index) => {
              const key = `${nameKey || item.name || item.dataKey || "value"}`;
              const itemConfig = getPayloadConfigFromPayload(config, item, key);
              const indicatorColor = color || item.payload.fill || item.color;

              return (
                <div
                  key={item.dataKey}
                  className={cn(
                    "flex w-full flex-wrap items-stretch gap-2 [&>svg]:h-2.5 [&>svg]:w-2.5 [&>svg]:text-muted-foreground",
                    indicator === "dot" && "items-center",
                  )}
                >
                  {formatter && item?.value !== undefined && item.name ? (
                    formatter(item.value, item.name, item, index, item.payload)
                  ) : (
                    <>
                      {itemConfig?.icon ? (
                        <itemConfig.icon />
                      ) : (
                        !hideIndicator && (
                          <div
                            className={cn(
                              "shrink-0 rounded-[2px] border-(--color-border) bg-(--color-bg)",
                              {
                                "h-2.5 w-2.5": indicator === "dot",
                                "w-1": indicator === "line",
                                "w-0 border-[1.5px] border-dashed bg-transparent":
                                  indicator === "dashed",
                                "my-0.5": nestLabel && indicator === "dashed",
                              },
                            )}
                            style={
                              {
                                "--color-bg": indicatorColor,
                                "--color-border": indicatorColor,
                              } as React.CSSProperties
                            }
                          />
                        )
                      )}
                      <div
                        className={cn(
                          "flex flex-1 justify-between leading-none",
                          nestLabel ? "items-end" : "items-center",
                        )}
                      >
                        <div className="grid gap-1.5">
                          {nestLabel ? tooltipLabel : null}
                          <span className="text-muted-foreground">
                            {itemConfig?.label || item.name}
                          </span>
                        </div>
                        {item.value && (
                          <span className="font-mono font-medium tabular-nums text-foreground">
                            {item.value.toLocaleString()}
                          </span>
                        )}
                      </div>
                    </>
                  )}
                </div>
              );
            })}
        </div>
      </div>
    );
  },
);
ChartTooltipContent.displayName = "ChartTooltip";

const ChartLegend = RechartsPrimitive.Legend;

const ChartLegendContent = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div"> &
    Pick<RechartsPrimitive.LegendProps, "payload" | "verticalAlign"> & {
      hideIcon?: boolean;
      nameKey?: string;
    }
>(({ className, hideIcon = false, payload, verticalAlign = "bottom", nameKey }, ref) => {
  const { config } = useChart();

  if (!payload?.length) {
    return null;
  }

  return (
    <div
      ref={ref}
      className={cn(
        "flex items-center justify-center gap-4",
        verticalAlign === "top" ? "pb-3" : "pt-3",
        className,
      )}
    >
      {payload
        .filter((item) => item.type !== "none")
        .map((item) => {
          const key = `${nameKey || item.dataKey || "value"}`;
          const itemConfig = getPayloadConfigFromPayload(config, item, key);

          return (
            <div
              key={item.value}
              className={cn(
                "flex items-center gap-1.5 [&>svg]:h-3 [&>svg]:w-3 [&>svg]:text-muted-foreground",
              )}
            >
              {itemConfig?.icon && !hideIcon ? (
                <itemConfig.icon />
              ) : (
                <div
                  className="h-2 w-2 shrink-0 rounded-[2px]"
                  style={{
                    backgroundColor: item.color,
                  }}
                />
              )}
              {itemConfig?.label}
            </div>
          );
        })}
    </div>
  );
});
ChartLegendContent.displayName = "ChartLegend";

// Helper to extract item config from a payload.
function getPayloadConfigFromPayload(config: ChartConfig, payload: unknown, key: string) {
  if (typeof payload !== "object" || payload === null) {
    return undefined;
  }

  const payloadPayload =
    "payload" in payload && typeof payload.payload === "object" && payload.payload !== null
      ? payload.payload
      : undefined;

  let configLabelKey: string = key;

  if (key in payload && typeof payload[key as keyof typeof payload] === "string") {
    configLabelKey = payload[key as keyof typeof payload] as string;
  } else if (
    payloadPayload &&
    key in payloadPayload &&
    typeof payloadPayload[key as keyof typeof payloadPayload] === "string"
  ) {
    configLabelKey = payloadPayload[key as keyof typeof payloadPayload] as string;
  }

  return configLabelKey in config ? config[configLabelKey] : config[key as keyof typeof config];
}

export {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
  ChartStyle,
};

```

## FILE 39: src/components/ui/checkbox.tsx

```tsx
import * as React from "react";
import * as CheckboxPrimitive from "@radix-ui/react-checkbox";
import { Check } from "lucide-react";

import { cn } from "@/lib/utils";

const Checkbox = React.forwardRef<
  React.ElementRef<typeof CheckboxPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof CheckboxPrimitive.Root>
>(({ className, ...props }, ref) => (
  <CheckboxPrimitive.Root
    ref={ref}
    className={cn(
      "grid place-content-center peer h-4 w-4 shrink-0 rounded-sm border border-primary shadow cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground",
      className,
    )}
    {...props}
  >
    <CheckboxPrimitive.Indicator className={cn("grid place-content-center text-current")}>
      <Check className="h-4 w-4" />
    </CheckboxPrimitive.Indicator>
  </CheckboxPrimitive.Root>
));
Checkbox.displayName = CheckboxPrimitive.Root.displayName;

export { Checkbox };

```

## FILE 40: src/components/ui/collapsible.tsx

```tsx
"use client";

import * as CollapsiblePrimitive from "@radix-ui/react-collapsible";

const Collapsible = CollapsiblePrimitive.Root;

const CollapsibleTrigger = CollapsiblePrimitive.CollapsibleTrigger;

const CollapsibleContent = CollapsiblePrimitive.CollapsibleContent;

export { Collapsible, CollapsibleTrigger, CollapsibleContent };

```

## FILE 41: src/components/ui/command.tsx

```tsx
"use client";

import * as React from "react";
import { type DialogProps } from "@radix-ui/react-dialog";
import { Command as CommandPrimitive } from "cmdk";
import { Search } from "lucide-react";

import { cn } from "@/lib/utils";
import { Dialog, DialogContent } from "@/components/ui/dialog";

const Command = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive>
>(({ className, ...props }, ref) => (
  <CommandPrimitive
    ref={ref}
    className={cn(
      "flex h-full w-full flex-col overflow-hidden rounded-md bg-popover text-popover-foreground",
      className,
    )}
    {...props}
  />
));
Command.displayName = CommandPrimitive.displayName;

const CommandDialog = ({ children, ...props }: DialogProps) => {
  return (
    <Dialog {...props}>
      <DialogContent className="overflow-hidden p-0">
        <Command className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground [&_[cmdk-group]:not([hidden])_~[cmdk-group]]:pt-0 [&_[cmdk-group]]:px-2 [&_[cmdk-input-wrapper]_svg]:h-5 [&_[cmdk-input-wrapper]_svg]:w-5 [&_[cmdk-input]]:h-12 [&_[cmdk-item]]:px-2 [&_[cmdk-item]]:py-3 [&_[cmdk-item]_svg]:h-5 [&_[cmdk-item]_svg]:w-5">
          {children}
        </Command>
      </DialogContent>
    </Dialog>
  );
};

const CommandInput = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Input>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Input>
>(({ className, ...props }, ref) => (
  <div className="flex items-center border-b px-3" cmdk-input-wrapper="">
    <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
    <CommandPrimitive.Input
      ref={ref}
      className={cn(
        "flex h-10 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50",
        className,
      )}
      {...props}
    />
  </div>
));

CommandInput.displayName = CommandPrimitive.Input.displayName;

const CommandList = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.List>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.List>
>(({ className, ...props }, ref) => (
  <CommandPrimitive.List
    ref={ref}
    className={cn("max-h-[300px] overflow-y-auto overflow-x-hidden", className)}
    {...props}
  />
));

CommandList.displayName = CommandPrimitive.List.displayName;

const CommandEmpty = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Empty>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Empty>
>((props, ref) => (
  <CommandPrimitive.Empty ref={ref} className="py-6 text-center text-sm" {...props} />
));

CommandEmpty.displayName = CommandPrimitive.Empty.displayName;

const CommandGroup = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Group>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Group>
>(({ className, ...props }, ref) => (
  <CommandPrimitive.Group
    ref={ref}
    className={cn(
      "overflow-hidden p-1 text-foreground [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground",
      className,
    )}
    {...props}
  />
));

CommandGroup.displayName = CommandPrimitive.Group.displayName;

const CommandSeparator = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Separator>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Separator>
>(({ className, ...props }, ref) => (
  <CommandPrimitive.Separator
    ref={ref}
    className={cn("-mx-1 h-px bg-border", className)}
    {...props}
  />
));
CommandSeparator.displayName = CommandPrimitive.Separator.displayName;

const CommandItem = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Item>
>(({ className, ...props }, ref) => (
  <CommandPrimitive.Item
    ref={ref}
    className={cn(
      "relative flex cursor-default gap-2 select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none data-[disabled=true]:pointer-events-none data-[selected=true]:bg-accent data-[selected=true]:text-accent-foreground data-[disabled=true]:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
      className,
    )}
    {...props}
  />
));

CommandItem.displayName = CommandPrimitive.Item.displayName;

const CommandShortcut = ({ className, ...props }: React.HTMLAttributes<HTMLSpanElement>) => {
  return (
    <span
      className={cn("ml-auto text-xs tracking-widest text-muted-foreground", className)}
      {...props}
    />
  );
};
CommandShortcut.displayName = "CommandShortcut";

export {
  Command,
  CommandDialog,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandShortcut,
  CommandSeparator,
};

```

## FILE 42: src/components/ui/context-menu.tsx

```tsx
import * as React from "react";
import * as ContextMenuPrimitive from "@radix-ui/react-context-menu";
import { Check, ChevronRight, Circle } from "lucide-react";

import { cn } from "@/lib/utils";

const ContextMenu = ContextMenuPrimitive.Root;

const ContextMenuTrigger = ContextMenuPrimitive.Trigger;

const ContextMenuGroup = ContextMenuPrimitive.Group;

const ContextMenuPortal = ContextMenuPrimitive.Portal;

const ContextMenuSub = ContextMenuPrimitive.Sub;

const ContextMenuRadioGroup = ContextMenuPrimitive.RadioGroup;

const ContextMenuSubTrigger = React.forwardRef<
  React.ElementRef<typeof ContextMenuPrimitive.SubTrigger>,
  React.ComponentPropsWithoutRef<typeof ContextMenuPrimitive.SubTrigger> & {
    inset?: boolean;
  }
>(({ className, inset, children, ...props }, ref) => (
  <ContextMenuPrimitive.SubTrigger
    ref={ref}
    className={cn(
      "flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground",
      inset && "pl-8",
      className,
    )}
    {...props}
  >
    {children}
    <ChevronRight className="ml-auto h-4 w-4" />
  </ContextMenuPrimitive.SubTrigger>
));
ContextMenuSubTrigger.displayName = ContextMenuPrimitive.SubTrigger.displayName;

const ContextMenuSubContent = React.forwardRef<
  React.ElementRef<typeof ContextMenuPrimitive.SubContent>,
  React.ComponentPropsWithoutRef<typeof ContextMenuPrimitive.SubContent>
>(({ className, ...props }, ref) => (
  <ContextMenuPrimitive.SubContent
    ref={ref}
    className={cn(
      "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-context-menu-content-transform-origin)",
      className,
    )}
    {...props}
  />
));
ContextMenuSubContent.displayName = ContextMenuPrimitive.SubContent.displayName;

const ContextMenuContent = React.forwardRef<
  React.ElementRef<typeof ContextMenuPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof ContextMenuPrimitive.Content>
>(({ className, ...props }, ref) => (
  <ContextMenuPrimitive.Portal>
    <ContextMenuPrimitive.Content
      ref={ref}
      className={cn(
        "z-50 max-h-(--radix-context-menu-content-available-height) min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-context-menu-content-transform-origin)",
        className,
      )}
      {...props}
    />
  </ContextMenuPrimitive.Portal>
));
ContextMenuContent.displayName = ContextMenuPrimitive.Content.displayName;

const ContextMenuItem = React.forwardRef<
  React.ElementRef<typeof ContextMenuPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof ContextMenuPrimitive.Item> & {
    inset?: boolean;
  }
>(({ className, inset, ...props }, ref) => (
  <ContextMenuPrimitive.Item
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      inset && "pl-8",
      className,
    )}
    {...props}
  />
));
ContextMenuItem.displayName = ContextMenuPrimitive.Item.displayName;

const ContextMenuCheckboxItem = React.forwardRef<
  React.ElementRef<typeof ContextMenuPrimitive.CheckboxItem>,
  React.ComponentPropsWithoutRef<typeof ContextMenuPrimitive.CheckboxItem>
>(({ className, children, ...props }, ref) => (
  <ContextMenuPrimitive.CheckboxItem
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className,
    )}
    {...props}
  >
    <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
      <ContextMenuPrimitive.ItemIndicator>
        <Check className="h-4 w-4" />
      </ContextMenuPrimitive.ItemIndicator>
    </span>
    {children}
  </ContextMenuPrimitive.CheckboxItem>
));
ContextMenuCheckboxItem.displayName = ContextMenuPrimitive.CheckboxItem.displayName;

const ContextMenuRadioItem = React.forwardRef<
  React.ElementRef<typeof ContextMenuPrimitive.RadioItem>,
  React.ComponentPropsWithoutRef<typeof ContextMenuPrimitive.RadioItem>
>(({ className, children, ...props }, ref) => (
  <ContextMenuPrimitive.RadioItem
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className,
    )}
    {...props}
  >
    <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
      <ContextMenuPrimitive.ItemIndicator>
        <Circle className="h-4 w-4 fill-current" />
      </ContextMenuPrimitive.ItemIndicator>
    </span>
    {children}
  </ContextMenuPrimitive.RadioItem>
));
ContextMenuRadioItem.displayName = ContextMenuPrimitive.RadioItem.displayName;

const ContextMenuLabel = React.forwardRef<
  React.ElementRef<typeof ContextMenuPrimitive.Label>,
  React.ComponentPropsWithoutRef<typeof ContextMenuPrimitive.Label> & {
    inset?: boolean;
  }
>(({ className, inset, ...props }, ref) => (
  <ContextMenuPrimitive.Label
    ref={ref}
    className={cn("px-2 py-1.5 text-sm font-semibold text-foreground", inset && "pl-8", className)}
    {...props}
  />
));
ContextMenuLabel.displayName = ContextMenuPrimitive.Label.displayName;

const ContextMenuSeparator = React.forwardRef<
  React.ElementRef<typeof ContextMenuPrimitive.Separator>,
  React.ComponentPropsWithoutRef<typeof ContextMenuPrimitive.Separator>
>(({ className, ...props }, ref) => (
  <ContextMenuPrimitive.Separator
    ref={ref}
    className={cn("-mx-1 my-1 h-px bg-border", className)}
    {...props}
  />
));
ContextMenuSeparator.displayName = ContextMenuPrimitive.Separator.displayName;

const ContextMenuShortcut = ({ className, ...props }: React.HTMLAttributes<HTMLSpanElement>) => {
  return (
    <span
      className={cn("ml-auto text-xs tracking-widest text-muted-foreground", className)}
      {...props}
    />
  );
};
ContextMenuShortcut.displayName = "ContextMenuShortcut";

export {
  ContextMenu,
  ContextMenuTrigger,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuCheckboxItem,
  ContextMenuRadioItem,
  ContextMenuLabel,
  ContextMenuSeparator,
  ContextMenuShortcut,
  ContextMenuGroup,
  ContextMenuPortal,
  ContextMenuSub,
  ContextMenuSubContent,
  ContextMenuSubTrigger,
  ContextMenuRadioGroup,
};

```

## FILE 43: src/components/ui/dialog.tsx

```tsx
"use client";

import * as React from "react";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { X } from "lucide-react";

import { cn } from "@/lib/utils";

const Dialog = DialogPrimitive.Root;

const DialogTrigger = DialogPrimitive.Trigger;

const DialogPortal = DialogPrimitive.Portal;

const DialogClose = DialogPrimitive.Close;

const DialogOverlay = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Overlay
    ref={ref}
    className={cn(
      "fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className,
    )}
    {...props}
  />
));
DialogOverlay.displayName = DialogPrimitive.Overlay.displayName;

const DialogContent = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Content>
>(({ className, children, ...props }, ref) => (
  <DialogPortal>
    <DialogOverlay />
    <DialogPrimitive.Content
      ref={ref}
      className={cn(
        "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg",
        className,
      )}
      {...props}
    >
      {children}
      <DialogPrimitive.Close className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground">
        <X className="h-4 w-4" />
        <span className="sr-only">Close</span>
      </DialogPrimitive.Close>
    </DialogPrimitive.Content>
  </DialogPortal>
));
DialogContent.displayName = DialogPrimitive.Content.displayName;

const DialogHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("flex flex-col space-y-1.5 text-center sm:text-left", className)} {...props} />
);
DialogHeader.displayName = "DialogHeader";

const DialogFooter = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className)}
    {...props}
  />
);
DialogFooter.displayName = "DialogFooter";

const DialogTitle = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Title>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Title
    ref={ref}
    className={cn("text-lg font-semibold leading-none tracking-tight", className)}
    {...props}
  />
));
DialogTitle.displayName = DialogPrimitive.Title.displayName;

const DialogDescription = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Description>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Description
    ref={ref}
    className={cn("text-sm text-muted-foreground", className)}
    {...props}
  />
));
DialogDescription.displayName = DialogPrimitive.Description.displayName;

export {
  Dialog,
  DialogPortal,
  DialogOverlay,
  DialogTrigger,
  DialogClose,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription,
};

```

## FILE 44: src/components/ui/drawer.tsx

```tsx
import * as React from "react";
import { Drawer as DrawerPrimitive } from "vaul";

import { cn } from "@/lib/utils";

const Drawer = ({
  shouldScaleBackground = true,
  ...props
}: React.ComponentProps<typeof DrawerPrimitive.Root>) => (
  <DrawerPrimitive.Root shouldScaleBackground={shouldScaleBackground} {...props} />
);
Drawer.displayName = "Drawer";

const DrawerTrigger = DrawerPrimitive.Trigger;

const DrawerPortal = DrawerPrimitive.Portal;

const DrawerClose = DrawerPrimitive.Close;

const DrawerOverlay = React.forwardRef<
  React.ElementRef<typeof DrawerPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <DrawerPrimitive.Overlay
    ref={ref}
    className={cn("fixed inset-0 z-50 bg-black/80", className)}
    {...props}
  />
));
DrawerOverlay.displayName = DrawerPrimitive.Overlay.displayName;

const DrawerContent = React.forwardRef<
  React.ElementRef<typeof DrawerPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Content>
>(({ className, children, ...props }, ref) => (
  <DrawerPortal>
    <DrawerOverlay />
    <DrawerPrimitive.Content
      ref={ref}
      className={cn(
        "fixed inset-x-0 bottom-0 z-50 mt-24 flex h-auto flex-col rounded-t-[10px] border bg-background",
        className,
      )}
      {...props}
    >
      <div className="mx-auto mt-4 h-2 w-[100px] rounded-full bg-muted" />
      {children}
    </DrawerPrimitive.Content>
  </DrawerPortal>
));
DrawerContent.displayName = "DrawerContent";

const DrawerHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("grid gap-1.5 p-4 text-center sm:text-left", className)} {...props} />
);
DrawerHeader.displayName = "DrawerHeader";

const DrawerFooter = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("mt-auto flex flex-col gap-2 p-4", className)} {...props} />
);
DrawerFooter.displayName = "DrawerFooter";

const DrawerTitle = React.forwardRef<
  React.ElementRef<typeof DrawerPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Title>
>(({ className, ...props }, ref) => (
  <DrawerPrimitive.Title
    ref={ref}
    className={cn("text-lg font-semibold leading-none tracking-tight", className)}
    {...props}
  />
));
DrawerTitle.displayName = DrawerPrimitive.Title.displayName;

const DrawerDescription = React.forwardRef<
  React.ElementRef<typeof DrawerPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Description>
>(({ className, ...props }, ref) => (
  <DrawerPrimitive.Description
    ref={ref}
    className={cn("text-sm text-muted-foreground", className)}
    {...props}
  />
));
DrawerDescription.displayName = DrawerPrimitive.Description.displayName;

export {
  Drawer,
  DrawerPortal,
  DrawerOverlay,
  DrawerTrigger,
  DrawerClose,
  DrawerContent,
  DrawerHeader,
  DrawerFooter,
  DrawerTitle,
  DrawerDescription,
};

```

## FILE 45: src/components/ui/dropdown-menu.tsx

```tsx
"use client";

import * as React from "react";
import * as DropdownMenuPrimitive from "@radix-ui/react-dropdown-menu";
import { Check, ChevronRight, Circle } from "lucide-react";

import { cn } from "@/lib/utils";

const DropdownMenu = DropdownMenuPrimitive.Root;

const DropdownMenuTrigger = DropdownMenuPrimitive.Trigger;

const DropdownMenuGroup = DropdownMenuPrimitive.Group;

const DropdownMenuPortal = DropdownMenuPrimitive.Portal;

const DropdownMenuSub = DropdownMenuPrimitive.Sub;

const DropdownMenuRadioGroup = DropdownMenuPrimitive.RadioGroup;

const DropdownMenuSubTrigger = React.forwardRef<
  React.ElementRef<typeof DropdownMenuPrimitive.SubTrigger>,
  React.ComponentPropsWithoutRef<typeof DropdownMenuPrimitive.SubTrigger> & {
    inset?: boolean;
  }
>(({ className, inset, children, ...props }, ref) => (
  <DropdownMenuPrimitive.SubTrigger
    ref={ref}
    className={cn(
      "flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
      inset && "pl-8",
      className,
    )}
    {...props}
  >
    {children}
    <ChevronRight className="ml-auto" />
  </DropdownMenuPrimitive.SubTrigger>
));
DropdownMenuSubTrigger.displayName = DropdownMenuPrimitive.SubTrigger.displayName;

const DropdownMenuSubContent = React.forwardRef<
  React.ElementRef<typeof DropdownMenuPrimitive.SubContent>,
  React.ComponentPropsWithoutRef<typeof DropdownMenuPrimitive.SubContent>
>(({ className, ...props }, ref) => (
  <DropdownMenuPrimitive.SubContent
    ref={ref}
    className={cn(
      "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)",
      className,
    )}
    {...props}
  />
));
DropdownMenuSubContent.displayName = DropdownMenuPrimitive.SubContent.displayName;

const DropdownMenuContent = React.forwardRef<
  React.ElementRef<typeof DropdownMenuPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof DropdownMenuPrimitive.Content>
>(({ className, sideOffset = 4, ...props }, ref) => (
  <DropdownMenuPrimitive.Portal>
    <DropdownMenuPrimitive.Content
      ref={ref}
      sideOffset={sideOffset}
      className={cn(
        "z-50 max-h-[var(--radix-dropdown-menu-content-available-height)] min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md",
        "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)",
        className,
      )}
      {...props}
    />
  </DropdownMenuPrimitive.Portal>
));
DropdownMenuContent.displayName = DropdownMenuPrimitive.Content.displayName;

const DropdownMenuItem = React.forwardRef<
  React.ElementRef<typeof DropdownMenuPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof DropdownMenuPrimitive.Item> & {
    inset?: boolean;
  }
>(({ className, inset, ...props }, ref) => (
  <DropdownMenuPrimitive.Item
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&>svg]:size-4 [&>svg]:shrink-0",
      inset && "pl-8",
      className,
    )}
    {...props}
  />
));
DropdownMenuItem.displayName = DropdownMenuPrimitive.Item.displayName;

const DropdownMenuCheckboxItem = React.forwardRef<
  React.ElementRef<typeof DropdownMenuPrimitive.CheckboxItem>,
  React.ComponentPropsWithoutRef<typeof DropdownMenuPrimitive.CheckboxItem>
>(({ className, children, ...props }, ref) => (
  <DropdownMenuPrimitive.CheckboxItem
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className,
    )}
    {...props}
  >
    <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
      <DropdownMenuPrimitive.ItemIndicator>
        <Check className="h-4 w-4" />
      </DropdownMenuPrimitive.ItemIndicator>
    </span>
    {children}
  </DropdownMenuPrimitive.CheckboxItem>
));
DropdownMenuCheckboxItem.displayName = DropdownMenuPrimitive.CheckboxItem.displayName;

const DropdownMenuRadioItem = React.forwardRef<
  React.ElementRef<typeof DropdownMenuPrimitive.RadioItem>,
  React.ComponentPropsWithoutRef<typeof DropdownMenuPrimitive.RadioItem>
>(({ className, children, ...props }, ref) => (
  <DropdownMenuPrimitive.RadioItem
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className,
    )}
    {...props}
  >
    <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
      <DropdownMenuPrimitive.ItemIndicator>
        <Circle className="h-2 w-2 fill-current" />
      </DropdownMenuPrimitive.ItemIndicator>
    </span>
    {children}
  </DropdownMenuPrimitive.RadioItem>
));
DropdownMenuRadioItem.displayName = DropdownMenuPrimitive.RadioItem.displayName;

const DropdownMenuLabel = React.forwardRef<
  React.ElementRef<typeof DropdownMenuPrimitive.Label>,
  React.ComponentPropsWithoutRef<typeof DropdownMenuPrimitive.Label> & {
    inset?: boolean;
  }
>(({ className, inset, ...props }, ref) => (
  <DropdownMenuPrimitive.Label
    ref={ref}
    className={cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className)}
    {...props}
  />
));
DropdownMenuLabel.displayName = DropdownMenuPrimitive.Label.displayName;

const DropdownMenuSeparator = React.forwardRef<
  React.ElementRef<typeof DropdownMenuPrimitive.Separator>,
  React.ComponentPropsWithoutRef<typeof DropdownMenuPrimitive.Separator>
>(({ className, ...props }, ref) => (
  <DropdownMenuPrimitive.Separator
    ref={ref}
    className={cn("-mx-1 my-1 h-px bg-muted", className)}
    {...props}
  />
));
DropdownMenuSeparator.displayName = DropdownMenuPrimitive.Separator.displayName;

const DropdownMenuShortcut = ({ className, ...props }: React.HTMLAttributes<HTMLSpanElement>) => {
  return (
    <span className={cn("ml-auto text-xs tracking-widest opacity-60", className)} {...props} />
  );
};
DropdownMenuShortcut.displayName = "DropdownMenuShortcut";

export {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuGroup,
  DropdownMenuPortal,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuRadioGroup,
};

```

## FILE 46: src/components/ui/form.tsx

```tsx
import * as React from "react";
import * as LabelPrimitive from "@radix-ui/react-label";
import { Slot } from "@radix-ui/react-slot";
import {
  Controller,
  FormProvider,
  useFormContext,
  type ControllerProps,
  type FieldPath,
  type FieldValues,
} from "react-hook-form";

import { cn } from "@/lib/utils";
import { Label } from "@/components/ui/label";

const Form = FormProvider;

type FormFieldContextValue<
  TFieldValues extends FieldValues = FieldValues,
  TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>,
> = {
  name: TName;
};

const FormFieldContext = React.createContext<FormFieldContextValue | null>(null);

const FormField = <
  TFieldValues extends FieldValues = FieldValues,
  TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>,
>({
  ...props
}: ControllerProps<TFieldValues, TName>) => {
  return (
    <FormFieldContext.Provider value={{ name: props.name }}>
      <Controller {...props} />
    </FormFieldContext.Provider>
  );
};

const useFormField = () => {
  const fieldContext = React.useContext(FormFieldContext);
  const itemContext = React.useContext(FormItemContext);
  const { getFieldState, formState } = useFormContext();

  if (!fieldContext) {
    throw new Error("useFormField should be used within <FormField>");
  }

  if (!itemContext) {
    throw new Error("useFormField should be used within <FormItem>");
  }

  const fieldState = getFieldState(fieldContext.name, formState);

  const { id } = itemContext;

  return {
    id,
    name: fieldContext.name,
    formItemId: `${id}-form-item`,
    formDescriptionId: `${id}-form-item-description`,
    formMessageId: `${id}-form-item-message`,
    ...fieldState,
  };
};

type FormItemContextValue = {
  id: string;
};

const FormItemContext = React.createContext<FormItemContextValue | null>(null);

const FormItem = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => {
    const id = React.useId();

    return (
      <FormItemContext.Provider value={{ id }}>
        <div ref={ref} className={cn("space-y-2", className)} {...props} />
      </FormItemContext.Provider>
    );
  },
);
FormItem.displayName = "FormItem";

const FormLabel = React.forwardRef<
  React.ElementRef<typeof LabelPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof LabelPrimitive.Root>
>(({ className, ...props }, ref) => {
  const { error, formItemId } = useFormField();

  return (
    <Label
      ref={ref}
      className={cn(error && "text-destructive", className)}
      htmlFor={formItemId}
      {...props}
    />
  );
});
FormLabel.displayName = "FormLabel";

const FormControl = React.forwardRef<
  React.ElementRef<typeof Slot>,
  React.ComponentPropsWithoutRef<typeof Slot>
>(({ ...props }, ref) => {
  const { error, formItemId, formDescriptionId, formMessageId } = useFormField();

  return (
    <Slot
      ref={ref}
      id={formItemId}
      aria-describedby={!error ? `${formDescriptionId}` : `${formDescriptionId} ${formMessageId}`}
      aria-invalid={!!error}
      {...props}
    />
  );
});
FormControl.displayName = "FormControl";

const FormDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => {
  const { formDescriptionId } = useFormField();

  return (
    <p
      ref={ref}
      id={formDescriptionId}
      className={cn("text-[0.8rem] text-muted-foreground", className)}
      {...props}
    />
  );
});
FormDescription.displayName = "FormDescription";

const FormMessage = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, children, ...props }, ref) => {
  const { error, formMessageId } = useFormField();
  const body = error ? String(error?.message ?? "") : children;

  if (!body) {
    return null;
  }

  return (
    <p
      ref={ref}
      id={formMessageId}
      className={cn("text-[0.8rem] font-medium text-destructive", className)}
      {...props}
    >
      {body}
    </p>
  );
});
FormMessage.displayName = "FormMessage";

export {
  useFormField,
  Form,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
  FormField,
};

```

## FILE 47: src/components/ui/hover-card.tsx

```tsx
import * as React from "react";
import * as HoverCardPrimitive from "@radix-ui/react-hover-card";

import { cn } from "@/lib/utils";

const HoverCard = HoverCardPrimitive.Root;

const HoverCardTrigger = HoverCardPrimitive.Trigger;

const HoverCardContent = React.forwardRef<
  React.ElementRef<typeof HoverCardPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof HoverCardPrimitive.Content>
>(({ className, align = "center", sideOffset = 4, ...props }, ref) => (
  <HoverCardPrimitive.Content
    ref={ref}
    align={align}
    sideOffset={sideOffset}
    className={cn(
      "z-50 w-64 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-hover-card-content-transform-origin)",
      className,
    )}
    {...props}
  />
));
HoverCardContent.displayName = HoverCardPrimitive.Content.displayName;

export { HoverCard, HoverCardTrigger, HoverCardContent };

```

## FILE 48: src/components/ui/input-otp.tsx

```tsx
import * as React from "react";
import { OTPInput, OTPInputContext } from "input-otp";
import { Minus } from "lucide-react";

import { cn } from "@/lib/utils";

const InputOTP = React.forwardRef<
  React.ElementRef<typeof OTPInput>,
  React.ComponentPropsWithoutRef<typeof OTPInput>
>(({ className, containerClassName, ...props }, ref) => (
  <OTPInput
    ref={ref}
    containerClassName={cn(
      "flex items-center gap-2 has-[:disabled]:opacity-50",
      containerClassName,
    )}
    className={cn("disabled:cursor-not-allowed", className)}
    {...props}
  />
));
InputOTP.displayName = "InputOTP";

const InputOTPGroup = React.forwardRef<
  React.ElementRef<"div">,
  React.ComponentPropsWithoutRef<"div">
>(({ className, ...props }, ref) => (
  <div ref={ref} className={cn("flex items-center", className)} {...props} />
));
InputOTPGroup.displayName = "InputOTPGroup";

const InputOTPSlot = React.forwardRef<
  React.ElementRef<"div">,
  React.ComponentPropsWithoutRef<"div"> & { index: number }
>(({ index, className, ...props }, ref) => {
  const inputOTPContext = React.useContext(OTPInputContext);
  const { char, hasFakeCaret, isActive } = inputOTPContext.slots[index] ?? {
    char: null,
    hasFakeCaret: false,
    isActive: false,
  };

  return (
    <div
      ref={ref}
      className={cn(
        "relative flex h-9 w-9 items-center justify-center border-y border-r border-input text-sm shadow-sm transition-all first:rounded-l-md first:border-l last:rounded-r-md",
        isActive && "z-10 ring-1 ring-ring",
        className,
      )}
      {...props}
    >
      {char}
      {hasFakeCaret && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="h-4 w-px animate-caret-blink bg-foreground duration-1000" />
        </div>
      )}
    </div>
  );
});
InputOTPSlot.displayName = "InputOTPSlot";

const InputOTPSeparator = React.forwardRef<
  React.ElementRef<"div">,
  React.ComponentPropsWithoutRef<"div">
>(({ ...props }, ref) => (
  <div ref={ref} role="separator" {...props}>
    <Minus />
  </div>
));
InputOTPSeparator.displayName = "InputOTPSeparator";

export { InputOTP, InputOTPGroup, InputOTPSlot, InputOTPSeparator };

```

## FILE 49: src/components/ui/input.tsx

```tsx
import * as React from "react";

import { cn } from "@/lib/utils";

const Input = React.forwardRef<HTMLInputElement, React.ComponentProps<"input">>(
  ({ className, type, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          "flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className,
        )}
        ref={ref}
        {...props}
      />
    );
  },
);
Input.displayName = "Input";

export { Input };

```

## FILE 50: src/components/ui/label.tsx

```tsx
"use client";

import * as React from "react";
import * as LabelPrimitive from "@radix-ui/react-label";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const labelVariants = cva(
  "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70",
);

const Label = React.forwardRef<
  React.ElementRef<typeof LabelPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof LabelPrimitive.Root> & VariantProps<typeof labelVariants>
>(({ className, ...props }, ref) => (
  <LabelPrimitive.Root ref={ref} className={cn(labelVariants(), className)} {...props} />
));
Label.displayName = LabelPrimitive.Root.displayName;

export { Label };

```

## FILE 51: src/components/ui/menubar.tsx

```tsx
import * as React from "react";
import * as MenubarPrimitive from "@radix-ui/react-menubar";
import { Check, ChevronRight, Circle } from "lucide-react";

import { cn } from "@/lib/utils";

function MenubarMenu({ ...props }: React.ComponentProps<typeof MenubarPrimitive.Menu>) {
  return <MenubarPrimitive.Menu {...props} />;
}

function MenubarGroup({ ...props }: React.ComponentProps<typeof MenubarPrimitive.Group>) {
  return <MenubarPrimitive.Group {...props} />;
}

function MenubarPortal({ ...props }: React.ComponentProps<typeof MenubarPrimitive.Portal>) {
  return <MenubarPrimitive.Portal {...props} />;
}

function MenubarRadioGroup({ ...props }: React.ComponentProps<typeof MenubarPrimitive.RadioGroup>) {
  return <MenubarPrimitive.RadioGroup {...props} />;
}

function MenubarSub({ ...props }: React.ComponentProps<typeof MenubarPrimitive.Sub>) {
  return <MenubarPrimitive.Sub data-slot="menubar-sub" {...props} />;
}

const Menubar = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.Root>
>(({ className, ...props }, ref) => (
  <MenubarPrimitive.Root
    ref={ref}
    className={cn(
      "flex h-9 items-center space-x-1 rounded-md border bg-background p-1 shadow-sm",
      className,
    )}
    {...props}
  />
));
Menubar.displayName = MenubarPrimitive.Root.displayName;

const MenubarTrigger = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.Trigger>
>(({ className, ...props }, ref) => (
  <MenubarPrimitive.Trigger
    ref={ref}
    className={cn(
      "flex cursor-default select-none items-center rounded-sm px-3 py-1 text-sm font-medium outline-none focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground",
      className,
    )}
    {...props}
  />
));
MenubarTrigger.displayName = MenubarPrimitive.Trigger.displayName;

const MenubarSubTrigger = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.SubTrigger>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.SubTrigger> & {
    inset?: boolean;
  }
>(({ className, inset, children, ...props }, ref) => (
  <MenubarPrimitive.SubTrigger
    ref={ref}
    className={cn(
      "flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground",
      inset && "pl-8",
      className,
    )}
    {...props}
  >
    {children}
    <ChevronRight className="ml-auto h-4 w-4" />
  </MenubarPrimitive.SubTrigger>
));
MenubarSubTrigger.displayName = MenubarPrimitive.SubTrigger.displayName;

const MenubarSubContent = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.SubContent>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.SubContent>
>(({ className, ...props }, ref) => (
  <MenubarPrimitive.SubContent
    ref={ref}
    className={cn(
      "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-menubar-content-transform-origin)",
      className,
    )}
    {...props}
  />
));
MenubarSubContent.displayName = MenubarPrimitive.SubContent.displayName;

const MenubarContent = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.Content>
>(({ className, align = "start", alignOffset = -4, sideOffset = 8, ...props }, ref) => (
  <MenubarPrimitive.Portal>
    <MenubarPrimitive.Content
      ref={ref}
      align={align}
      alignOffset={alignOffset}
      sideOffset={sideOffset}
      className={cn(
        "z-50 min-w-[12rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-menubar-content-transform-origin)",
        className,
      )}
      {...props}
    />
  </MenubarPrimitive.Portal>
));
MenubarContent.displayName = MenubarPrimitive.Content.displayName;

const MenubarItem = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.Item> & {
    inset?: boolean;
  }
>(({ className, inset, ...props }, ref) => (
  <MenubarPrimitive.Item
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      inset && "pl-8",
      className,
    )}
    {...props}
  />
));
MenubarItem.displayName = MenubarPrimitive.Item.displayName;

const MenubarCheckboxItem = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.CheckboxItem>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.CheckboxItem>
>(({ className, children, ...props }, ref) => (
  <MenubarPrimitive.CheckboxItem
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className,
    )}
    {...props}
  >
    <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
      <MenubarPrimitive.ItemIndicator>
        <Check className="h-4 w-4" />
      </MenubarPrimitive.ItemIndicator>
    </span>
    {children}
  </MenubarPrimitive.CheckboxItem>
));
MenubarCheckboxItem.displayName = MenubarPrimitive.CheckboxItem.displayName;

const MenubarRadioItem = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.RadioItem>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.RadioItem>
>(({ className, children, ...props }, ref) => (
  <MenubarPrimitive.RadioItem
    ref={ref}
    className={cn(
      "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className,
    )}
    {...props}
  >
    <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
      <MenubarPrimitive.ItemIndicator>
        <Circle className="h-4 w-4 fill-current" />
      </MenubarPrimitive.ItemIndicator>
    </span>
    {children}
  </MenubarPrimitive.RadioItem>
));
MenubarRadioItem.displayName = MenubarPrimitive.RadioItem.displayName;

const MenubarLabel = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.Label>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.Label> & {
    inset?: boolean;
  }
>(({ className, inset, ...props }, ref) => (
  <MenubarPrimitive.Label
    ref={ref}
    className={cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className)}
    {...props}
  />
));
MenubarLabel.displayName = MenubarPrimitive.Label.displayName;

const MenubarSeparator = React.forwardRef<
  React.ElementRef<typeof MenubarPrimitive.Separator>,
  React.ComponentPropsWithoutRef<typeof MenubarPrimitive.Separator>
>(({ className, ...props }, ref) => (
  <MenubarPrimitive.Separator
    ref={ref}
    className={cn("-mx-1 my-1 h-px bg-muted", className)}
    {...props}
  />
));
MenubarSeparator.displayName = MenubarPrimitive.Separator.displayName;

const MenubarShortcut = ({ className, ...props }: React.HTMLAttributes<HTMLSpanElement>) => {
  return (
    <span
      className={cn("ml-auto text-xs tracking-widest text-muted-foreground", className)}
      {...props}
    />
  );
};
MenubarShortcut.displayname = "MenubarShortcut";

export {
  Menubar,
  MenubarMenu,
  MenubarTrigger,
  MenubarContent,
  MenubarItem,
  MenubarSeparator,
  MenubarLabel,
  MenubarCheckboxItem,
  MenubarRadioGroup,
  MenubarRadioItem,
  MenubarPortal,
  MenubarSubContent,
  MenubarSubTrigger,
  MenubarGroup,
  MenubarSub,
  MenubarShortcut,
};

```

## FILE 52: src/components/ui/navigation-menu.tsx

```tsx
import * as React from "react";
import * as NavigationMenuPrimitive from "@radix-ui/react-navigation-menu";
import { cva } from "class-variance-authority";
import { ChevronDown } from "lucide-react";

import { cn } from "@/lib/utils";

const NavigationMenu = React.forwardRef<
  React.ElementRef<typeof NavigationMenuPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.Root>
>(({ className, children, ...props }, ref) => (
  <NavigationMenuPrimitive.Root
    ref={ref}
    className={cn("relative z-10 flex max-w-max flex-1 items-center justify-center", className)}
    {...props}
  >
    {children}
    <NavigationMenuViewport />
  </NavigationMenuPrimitive.Root>
));
NavigationMenu.displayName = NavigationMenuPrimitive.Root.displayName;

const NavigationMenuList = React.forwardRef<
  React.ElementRef<typeof NavigationMenuPrimitive.List>,
  React.ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.List>
>(({ className, ...props }, ref) => (
  <NavigationMenuPrimitive.List
    ref={ref}
    className={cn("group flex flex-1 list-none items-center justify-center space-x-1", className)}
    {...props}
  />
));
NavigationMenuList.displayName = NavigationMenuPrimitive.List.displayName;

const NavigationMenuItem = NavigationMenuPrimitive.Item;

const navigationMenuTriggerStyle = cva(
  "group inline-flex h-9 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium cursor-pointer transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=open]:text-accent-foreground data-[state=open]:bg-accent/50 data-[state=open]:hover:bg-accent data-[state=open]:focus:bg-accent",
);

const NavigationMenuTrigger = React.forwardRef<
  React.ElementRef<typeof NavigationMenuPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.Trigger>
>(({ className, children, ...props }, ref) => (
  <NavigationMenuPrimitive.Trigger
    ref={ref}
    className={cn(navigationMenuTriggerStyle(), "group", className)}
    {...props}
  >
    {children}{" "}
    <ChevronDown
      className="relative top-[1px] ml-1 h-3 w-3 transition duration-300 group-data-[state=open]:rotate-180"
      aria-hidden="true"
    />
  </NavigationMenuPrimitive.Trigger>
));
NavigationMenuTrigger.displayName = NavigationMenuPrimitive.Trigger.displayName;

const NavigationMenuContent = React.forwardRef<
  React.ElementRef<typeof NavigationMenuPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.Content>
>(({ className, ...props }, ref) => (
  <NavigationMenuPrimitive.Content
    ref={ref}
    className={cn(
      "left-0 top-0 w-full data-[motion^=from-]:animate-in data-[motion^=to-]:animate-out data-[motion^=from-]:fade-in data-[motion^=to-]:fade-out data-[motion=from-end]:slide-in-from-right-52 data-[motion=from-start]:slide-in-from-left-52 data-[motion=to-end]:slide-out-to-right-52 data-[motion=to-start]:slide-out-to-left-52 md:absolute md:w-auto ",
      className,
    )}
    {...props}
  />
));
NavigationMenuContent.displayName = NavigationMenuPrimitive.Content.displayName;

const NavigationMenuLink = NavigationMenuPrimitive.Link;

const NavigationMenuViewport = React.forwardRef<
  React.ElementRef<typeof NavigationMenuPrimitive.Viewport>,
  React.ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.Viewport>
>(({ className, ...props }, ref) => (
  <div className={cn("absolute left-0 top-full flex justify-center")}>
    <NavigationMenuPrimitive.Viewport
      className={cn(
        "origin-top-center relative mt-1.5 h-[var(--radix-navigation-menu-viewport-height)] w-full overflow-hidden rounded-md border bg-popover text-popover-foreground shadow data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-90 md:w-[var(--radix-navigation-menu-viewport-width)]",
        className,
      )}
      ref={ref}
      {...props}
    />
  </div>
));
NavigationMenuViewport.displayName = NavigationMenuPrimitive.Viewport.displayName;

const NavigationMenuIndicator = React.forwardRef<
  React.ElementRef<typeof NavigationMenuPrimitive.Indicator>,
  React.ComponentPropsWithoutRef<typeof NavigationMenuPrimitive.Indicator>
>(({ className, ...props }, ref) => (
  <NavigationMenuPrimitive.Indicator
    ref={ref}
    className={cn(
      "top-full z-[1] flex h-1.5 items-end justify-center overflow-hidden data-[state=visible]:animate-in data-[state=hidden]:animate-out data-[state=hidden]:fade-out data-[state=visible]:fade-in",
      className,
    )}
    {...props}
  >
    <div className="relative top-[60%] h-2 w-2 rotate-45 rounded-tl-sm bg-border shadow-md" />
  </NavigationMenuPrimitive.Indicator>
));
NavigationMenuIndicator.displayName = NavigationMenuPrimitive.Indicator.displayName;

export {
  navigationMenuTriggerStyle,
  NavigationMenu,
  NavigationMenuList,
  NavigationMenuItem,
  NavigationMenuContent,
  NavigationMenuTrigger,
  NavigationMenuLink,
  NavigationMenuIndicator,
  NavigationMenuViewport,
};

```

## FILE 53: src/components/ui/pagination.tsx

```tsx
import * as React from "react";
import { ChevronLeft, ChevronRight, MoreHorizontal } from "lucide-react";

import { cn } from "@/lib/utils";
import { ButtonProps, buttonVariants } from "@/components/ui/button";

const Pagination = ({ className, ...props }: React.ComponentProps<"nav">) => (
  <nav
    role="navigation"
    aria-label="pagination"
    className={cn("mx-auto flex w-full justify-center", className)}
    {...props}
  />
);
Pagination.displayName = "Pagination";

const PaginationContent = React.forwardRef<HTMLUListElement, React.ComponentProps<"ul">>(
  ({ className, ...props }, ref) => (
    <ul ref={ref} className={cn("flex flex-row items-center gap-1", className)} {...props} />
  ),
);
PaginationContent.displayName = "PaginationContent";

const PaginationItem = React.forwardRef<HTMLLIElement, React.ComponentProps<"li">>(
  ({ className, ...props }, ref) => <li ref={ref} className={cn("", className)} {...props} />,
);
PaginationItem.displayName = "PaginationItem";

type PaginationLinkProps = {
  isActive?: boolean;
} & Pick<ButtonProps, "size"> &
  React.ComponentProps<"a">;

const PaginationLink = ({ className, isActive, size = "icon", ...props }: PaginationLinkProps) => (
  <a
    aria-current={isActive ? "page" : undefined}
    className={cn(
      buttonVariants({
        variant: isActive ? "outline" : "ghost",
        size,
      }),
      className,
    )}
    {...props}
  />
);
PaginationLink.displayName = "PaginationLink";

const PaginationPrevious = ({
  className,
  ...props
}: React.ComponentProps<typeof PaginationLink>) => (
  <PaginationLink
    aria-label="Go to previous page"
    size="default"
    className={cn("gap-1 pl-2.5", className)}
    {...props}
  >
    <ChevronLeft className="h-4 w-4" />
    <span>Previous</span>
  </PaginationLink>
);
PaginationPrevious.displayName = "PaginationPrevious";

const PaginationNext = ({ className, ...props }: React.ComponentProps<typeof PaginationLink>) => (
  <PaginationLink
    aria-label="Go to next page"
    size="default"
    className={cn("gap-1 pr-2.5", className)}
    {...props}
  >
    <span>Next</span>
    <ChevronRight className="h-4 w-4" />
  </PaginationLink>
);
PaginationNext.displayName = "PaginationNext";

const PaginationEllipsis = ({ className, ...props }: React.ComponentProps<"span">) => (
  <span
    aria-hidden
    className={cn("flex h-9 w-9 items-center justify-center", className)}
    {...props}
  >
    <MoreHorizontal className="h-4 w-4" />
    <span className="sr-only">More pages</span>
  </span>
);
PaginationEllipsis.displayName = "PaginationEllipsis";

export {
  Pagination,
  PaginationContent,
  PaginationLink,
  PaginationItem,
  PaginationPrevious,
  PaginationNext,
  PaginationEllipsis,
};

```

## FILE 54: src/components/ui/popover.tsx

```tsx
import * as React from "react";
import * as PopoverPrimitive from "@radix-ui/react-popover";

import { cn } from "@/lib/utils";

const Popover = PopoverPrimitive.Root;

const PopoverTrigger = PopoverPrimitive.Trigger;

const PopoverAnchor = PopoverPrimitive.Anchor;

const PopoverContent = React.forwardRef<
  React.ElementRef<typeof PopoverPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof PopoverPrimitive.Content>
>(({ className, align = "center", sideOffset = 4, ...props }, ref) => (
  <PopoverPrimitive.Portal>
    <PopoverPrimitive.Content
      ref={ref}
      align={align}
      sideOffset={sideOffset}
      className={cn(
        "z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-popover-content-transform-origin)",
        className,
      )}
      {...props}
    />
  </PopoverPrimitive.Portal>
));
PopoverContent.displayName = PopoverPrimitive.Content.displayName;

export { Popover, PopoverTrigger, PopoverContent, PopoverAnchor };

```

## FILE 55: src/components/ui/progress.tsx

```tsx
"use client";

import * as React from "react";
import * as ProgressPrimitive from "@radix-ui/react-progress";

import { cn } from "@/lib/utils";

const Progress = React.forwardRef<
  React.ElementRef<typeof ProgressPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ProgressPrimitive.Root>
>(({ className, value, ...props }, ref) => (
  <ProgressPrimitive.Root
    ref={ref}
    className={cn("relative h-2 w-full overflow-hidden rounded-full bg-primary/20", className)}
    {...props}
  >
    <ProgressPrimitive.Indicator
      className="h-full w-full flex-1 bg-primary transition-all"
      style={{ transform: `translateX(-${100 - (value || 0)}%)` }}
    />
  </ProgressPrimitive.Root>
));
Progress.displayName = ProgressPrimitive.Root.displayName;

export { Progress };

```

## FILE 56: src/components/ui/radio-group.tsx

```tsx
import * as React from "react";
import * as RadioGroupPrimitive from "@radix-ui/react-radio-group";
import { Circle } from "lucide-react";

import { cn } from "@/lib/utils";

const RadioGroup = React.forwardRef<
  React.ElementRef<typeof RadioGroupPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof RadioGroupPrimitive.Root>
>(({ className, ...props }, ref) => {
  return <RadioGroupPrimitive.Root className={cn("grid gap-2", className)} {...props} ref={ref} />;
});
RadioGroup.displayName = RadioGroupPrimitive.Root.displayName;

const RadioGroupItem = React.forwardRef<
  React.ElementRef<typeof RadioGroupPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof RadioGroupPrimitive.Item>
>(({ className, ...props }, ref) => {
  return (
    <RadioGroupPrimitive.Item
      ref={ref}
      className={cn(
        "aspect-square h-4 w-4 rounded-full border border-primary text-primary shadow cursor-pointer focus:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
        className,
      )}
      {...props}
    >
      <RadioGroupPrimitive.Indicator className="flex items-center justify-center">
        <Circle className="h-3.5 w-3.5 fill-primary" />
      </RadioGroupPrimitive.Indicator>
    </RadioGroupPrimitive.Item>
  );
});
RadioGroupItem.displayName = RadioGroupPrimitive.Item.displayName;

export { RadioGroup, RadioGroupItem };

```

## FILE 57: src/components/ui/resizable.tsx

```tsx
import { GripVertical } from "lucide-react";
import { Group, Panel, Separator } from "react-resizable-panels";

import { cn } from "@/lib/utils";

const ResizablePanelGroup = ({ className, ...props }: React.ComponentProps<typeof Group>) => (
  <Group
    className={cn("flex h-full w-full data-[panel-group-direction=vertical]:flex-col", className)}
    {...props}
  />
);

const ResizablePanel = Panel;

const ResizableHandle = ({
  withHandle,
  className,
  ...props
}: React.ComponentProps<typeof Separator> & {
  withHandle?: boolean;
}) => (
  <Separator
    className={cn(
      "relative flex w-px items-center justify-center bg-border after:absolute after:inset-y-0 after:left-1/2 after:w-1 after:-translate-x-1/2 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring focus-visible:ring-offset-1 data-[panel-group-direction=vertical]:h-px data-[panel-group-direction=vertical]:w-full data-[panel-group-direction=vertical]:after:left-0 data-[panel-group-direction=vertical]:after:h-1 data-[panel-group-direction=vertical]:after:w-full data-[panel-group-direction=vertical]:after:-translate-y-1/2 data-[panel-group-direction=vertical]:after:translate-x-0 [&[data-panel-group-direction=vertical]>div]:rotate-90",
      className,
    )}
    {...props}
  >
    {withHandle && (
      <div className="z-10 flex h-4 w-3 items-center justify-center rounded-sm border bg-border">
        <GripVertical className="h-2.5 w-2.5" />
      </div>
    )}
  </Separator>
);

export { ResizablePanelGroup, ResizablePanel, ResizableHandle };

```

## FILE 58: src/components/ui/scroll-area.tsx

```tsx
import * as React from "react";
import * as ScrollAreaPrimitive from "@radix-ui/react-scroll-area";

import { cn } from "@/lib/utils";

const ScrollArea = React.forwardRef<
  React.ElementRef<typeof ScrollAreaPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ScrollAreaPrimitive.Root>
>(({ className, children, ...props }, ref) => (
  <ScrollAreaPrimitive.Root
    ref={ref}
    className={cn("relative overflow-hidden", className)}
    {...props}
  >
    <ScrollAreaPrimitive.Viewport className="h-full w-full rounded-[inherit]">
      {children}
    </ScrollAreaPrimitive.Viewport>
    <ScrollBar />
    <ScrollAreaPrimitive.Corner />
  </ScrollAreaPrimitive.Root>
));
ScrollArea.displayName = ScrollAreaPrimitive.Root.displayName;

const ScrollBar = React.forwardRef<
  React.ElementRef<typeof ScrollAreaPrimitive.ScrollAreaScrollbar>,
  React.ComponentPropsWithoutRef<typeof ScrollAreaPrimitive.ScrollAreaScrollbar>
>(({ className, orientation = "vertical", ...props }, ref) => (
  <ScrollAreaPrimitive.ScrollAreaScrollbar
    ref={ref}
    orientation={orientation}
    className={cn(
      "flex touch-none select-none transition-colors",
      orientation === "vertical" && "h-full w-2.5 border-l border-l-transparent p-[1px]",
      orientation === "horizontal" && "h-2.5 flex-col border-t border-t-transparent p-[1px]",
      className,
    )}
    {...props}
  >
    <ScrollAreaPrimitive.ScrollAreaThumb className="relative flex-1 rounded-full bg-border" />
  </ScrollAreaPrimitive.ScrollAreaScrollbar>
));
ScrollBar.displayName = ScrollAreaPrimitive.ScrollAreaScrollbar.displayName;

export { ScrollArea, ScrollBar };

```

## FILE 59: src/components/ui/select.tsx

```tsx
"use client";

import * as React from "react";
import * as SelectPrimitive from "@radix-ui/react-select";
import { Check, ChevronDown, ChevronUp } from "lucide-react";

import { cn } from "@/lib/utils";

const Select = SelectPrimitive.Root;

const SelectGroup = SelectPrimitive.Group;

const SelectValue = SelectPrimitive.Value;

const SelectTrigger = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Trigger>
>(({ className, children, ...props }, ref) => (
  <SelectPrimitive.Trigger
    ref={ref}
    className={cn(
      "flex h-9 w-full items-center justify-between whitespace-nowrap rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm ring-offset-background cursor-pointer data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1",
      className,
    )}
    {...props}
  >
    {children}
    <SelectPrimitive.Icon asChild>
      <ChevronDown className="h-4 w-4 opacity-50" />
    </SelectPrimitive.Icon>
  </SelectPrimitive.Trigger>
));
SelectTrigger.displayName = SelectPrimitive.Trigger.displayName;

const SelectScrollUpButton = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.ScrollUpButton>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.ScrollUpButton>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.ScrollUpButton
    ref={ref}
    className={cn("flex cursor-default items-center justify-center py-1", className)}
    {...props}
  >
    <ChevronUp className="h-4 w-4" />
  </SelectPrimitive.ScrollUpButton>
));
SelectScrollUpButton.displayName = SelectPrimitive.ScrollUpButton.displayName;

const SelectScrollDownButton = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.ScrollDownButton>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.ScrollDownButton>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.ScrollDownButton
    ref={ref}
    className={cn("flex cursor-default items-center justify-center py-1", className)}
    {...props}
  >
    <ChevronDown className="h-4 w-4" />
  </SelectPrimitive.ScrollDownButton>
));
SelectScrollDownButton.displayName = SelectPrimitive.ScrollDownButton.displayName;

const SelectContent = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Content>
>(({ className, children, position = "popper", ...props }, ref) => (
  <SelectPrimitive.Portal>
    <SelectPrimitive.Content
      ref={ref}
      className={cn(
        "relative z-50 max-h-(--radix-select-content-available-height) min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-select-content-transform-origin)",
        position === "popper" &&
          "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1",
        className,
      )}
      position={position}
      {...props}
    >
      <SelectScrollUpButton />
      <SelectPrimitive.Viewport
        className={cn(
          "p-1",
          position === "popper" &&
            "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]",
        )}
      >
        {children}
      </SelectPrimitive.Viewport>
      <SelectScrollDownButton />
    </SelectPrimitive.Content>
  </SelectPrimitive.Portal>
));
SelectContent.displayName = SelectPrimitive.Content.displayName;

const SelectLabel = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Label>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Label>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.Label
    ref={ref}
    className={cn("px-2 py-1.5 text-sm font-semibold", className)}
    {...props}
  />
));
SelectLabel.displayName = SelectPrimitive.Label.displayName;

const SelectItem = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Item>
>(({ className, children, ...props }, ref) => (
  <SelectPrimitive.Item
    ref={ref}
    className={cn(
      "relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-2 pr-8 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className,
    )}
    {...props}
  >
    <span className="absolute right-2 flex h-3.5 w-3.5 items-center justify-center">
      <SelectPrimitive.ItemIndicator>
        <Check className="h-4 w-4" />
      </SelectPrimitive.ItemIndicator>
    </span>
    <SelectPrimitive.ItemText>{children}</SelectPrimitive.ItemText>
  </SelectPrimitive.Item>
));
SelectItem.displayName = SelectPrimitive.Item.displayName;

const SelectSeparator = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Separator>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Separator>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.Separator
    ref={ref}
    className={cn("-mx-1 my-1 h-px bg-muted", className)}
    {...props}
  />
));
SelectSeparator.displayName = SelectPrimitive.Separator.displayName;

export {
  Select,
  SelectGroup,
  SelectValue,
  SelectTrigger,
  SelectContent,
  SelectLabel,
  SelectItem,
  SelectSeparator,
  SelectScrollUpButton,
  SelectScrollDownButton,
};

```

## FILE 60: src/components/ui/separator.tsx

```tsx
import * as React from "react";
import * as SeparatorPrimitive from "@radix-ui/react-separator";

import { cn } from "@/lib/utils";

const Separator = React.forwardRef<
  React.ElementRef<typeof SeparatorPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof SeparatorPrimitive.Root>
>(({ className, orientation = "horizontal", decorative = true, ...props }, ref) => (
  <SeparatorPrimitive.Root
    ref={ref}
    decorative={decorative}
    orientation={orientation}
    className={cn(
      "shrink-0 bg-border",
      orientation === "horizontal" ? "h-[1px] w-full" : "h-full w-[1px]",
      className,
    )}
    {...props}
  />
));
Separator.displayName = SeparatorPrimitive.Root.displayName;

export { Separator };

```

## FILE 61: src/components/ui/sheet.tsx

```tsx
"use client";

import * as React from "react";
import * as SheetPrimitive from "@radix-ui/react-dialog";
import { cva, type VariantProps } from "class-variance-authority";
import { X } from "lucide-react";

import { cn } from "@/lib/utils";

const Sheet = SheetPrimitive.Root;

const SheetTrigger = SheetPrimitive.Trigger;

const SheetClose = SheetPrimitive.Close;

const SheetPortal = SheetPrimitive.Portal;

const SheetOverlay = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof SheetPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <SheetPrimitive.Overlay
    className={cn(
      "fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className,
    )}
    {...props}
    ref={ref}
  />
));
SheetOverlay.displayName = SheetPrimitive.Overlay.displayName;

const sheetVariants = cva(
  "fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out",
  {
    variants: {
      side: {
        top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
        bottom:
          "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
        left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
        right:
          "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm",
      },
    },
    defaultVariants: {
      side: "right",
    },
  },
);

interface SheetContentProps
  extends
    React.ComponentPropsWithoutRef<typeof SheetPrimitive.Content>,
    VariantProps<typeof sheetVariants> {}

const SheetContent = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Content>,
  SheetContentProps
>(({ side = "right", className, children, ...props }, ref) => (
  <SheetPortal>
    <SheetOverlay />
    <SheetPrimitive.Content ref={ref} className={cn(sheetVariants({ side }), className)} {...props}>
      <SheetPrimitive.Close className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary">
        <X className="h-4 w-4" />
        <span className="sr-only">Close</span>
      </SheetPrimitive.Close>
      {children}
    </SheetPrimitive.Content>
  </SheetPortal>
));
SheetContent.displayName = SheetPrimitive.Content.displayName;

const SheetHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("flex flex-col space-y-2 text-center sm:text-left", className)} {...props} />
);
SheetHeader.displayName = "SheetHeader";

const SheetFooter = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className)}
    {...props}
  />
);
SheetFooter.displayName = "SheetFooter";

const SheetTitle = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof SheetPrimitive.Title>
>(({ className, ...props }, ref) => (
  <SheetPrimitive.Title
    ref={ref}
    className={cn("text-lg font-semibold text-foreground", className)}
    {...props}
  />
));
SheetTitle.displayName = SheetPrimitive.Title.displayName;

const SheetDescription = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof SheetPrimitive.Description>
>(({ className, ...props }, ref) => (
  <SheetPrimitive.Description
    ref={ref}
    className={cn("text-sm text-muted-foreground", className)}
    {...props}
  />
));
SheetDescription.displayName = SheetPrimitive.Description.displayName;

export {
  Sheet,
  SheetPortal,
  SheetOverlay,
  SheetTrigger,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetFooter,
  SheetTitle,
  SheetDescription,
};

```

## FILE 62: src/components/ui/sidebar.tsx

```tsx
import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { PanelLeft } from "lucide-react";

import { useIsMobile } from "@/hooks/use-mobile";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Skeleton } from "@/components/ui/skeleton";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

const SIDEBAR_COOKIE_NAME = "sidebar_state";
const SIDEBAR_COOKIE_MAX_AGE = 60 * 60 * 24 * 7;
const SIDEBAR_WIDTH = "16rem";
const SIDEBAR_WIDTH_MOBILE = "18rem";
const SIDEBAR_WIDTH_ICON = "3rem";
const SIDEBAR_KEYBOARD_SHORTCUT = "b";

type SidebarContextProps = {
  state: "expanded" | "collapsed";
  open: boolean;
  setOpen: (open: boolean) => void;
  openMobile: boolean;
  setOpenMobile: (open: boolean) => void;
  isMobile: boolean;
  toggleSidebar: () => void;
};

const SidebarContext = React.createContext<SidebarContextProps | null>(null);

function useSidebar() {
  const context = React.useContext(SidebarContext);
  if (!context) {
    throw new Error("useSidebar must be used within a SidebarProvider.");
  }

  return context;
}

const SidebarProvider = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div"> & {
    defaultOpen?: boolean;
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
  }
>(
  (
    {
      defaultOpen = true,
      open: openProp,
      onOpenChange: setOpenProp,
      className,
      style,
      children,
      ...props
    },
    ref,
  ) => {
    const isMobile = useIsMobile();
    const [openMobile, setOpenMobile] = React.useState(false);

    // This is the internal state of the sidebar.
    // We use openProp and setOpenProp for control from outside the component.
    const [_open, _setOpen] = React.useState(defaultOpen);
    const open = openProp ?? _open;
    const setOpen = React.useCallback(
      (value: boolean | ((value: boolean) => boolean)) => {
        const openState = typeof value === "function" ? value(open) : value;
        if (setOpenProp) {
          setOpenProp(openState);
        } else {
          _setOpen(openState);
        }

        // This sets the cookie to keep the sidebar state.
        document.cookie = `${SIDEBAR_COOKIE_NAME}=${openState}; path=/; max-age=${SIDEBAR_COOKIE_MAX_AGE}`;
      },
      [setOpenProp, open],
    );

    // Helper to toggle the sidebar.
    const toggleSidebar = React.useCallback(() => {
      return isMobile ? setOpenMobile((open) => !open) : setOpen((open) => !open);
    }, [isMobile, setOpen, setOpenMobile]);

    // Adds a keyboard shortcut to toggle the sidebar.
    React.useEffect(() => {
      const handleKeyDown = (event: KeyboardEvent) => {
        if (event.key === SIDEBAR_KEYBOARD_SHORTCUT && (event.metaKey || event.ctrlKey)) {
          event.preventDefault();
          toggleSidebar();
        }
      };

      window.addEventListener("keydown", handleKeyDown);
      return () => window.removeEventListener("keydown", handleKeyDown);
    }, [toggleSidebar]);

    // We add a state so that we can do data-state="expanded" or "collapsed".
    // This makes it easier to style the sidebar with Tailwind classes.
    const state = open ? "expanded" : "collapsed";

    const contextValue = React.useMemo<SidebarContextProps>(
      () => ({
        state,
        open,
        setOpen,
        isMobile,
        openMobile,
        setOpenMobile,
        toggleSidebar,
      }),
      [state, open, setOpen, isMobile, openMobile, setOpenMobile, toggleSidebar],
    );

    return (
      <SidebarContext.Provider value={contextValue}>
        <TooltipProvider delayDuration={0}>
          <div
            style={
              {
                "--sidebar-width": SIDEBAR_WIDTH,
                "--sidebar-width-icon": SIDEBAR_WIDTH_ICON,
                ...style,
              } as React.CSSProperties
            }
            className={cn(
              "group/sidebar-wrapper flex min-h-svh w-full has-[[data-variant=inset]]:bg-sidebar",
              className,
            )}
            ref={ref}
            {...props}
          >
            {children}
          </div>
        </TooltipProvider>
      </SidebarContext.Provider>
    );
  },
);
SidebarProvider.displayName = "SidebarProvider";

const Sidebar = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div"> & {
    side?: "left" | "right";
    variant?: "sidebar" | "floating" | "inset";
    collapsible?: "offcanvas" | "icon" | "none";
  }
>(
  (
    {
      side = "left",
      variant = "sidebar",
      collapsible = "offcanvas",
      className,
      children,
      ...props
    },
    ref,
  ) => {
    const { isMobile, state, openMobile, setOpenMobile } = useSidebar();

    if (collapsible === "none") {
      return (
        <div
          className={cn(
            "flex h-full w-(--sidebar-width) flex-col bg-sidebar text-sidebar-foreground",
            className,
          )}
          ref={ref}
          {...props}
        >
          {children}
        </div>
      );
    }

    if (isMobile) {
      return (
        <Sheet open={openMobile} onOpenChange={setOpenMobile} {...props}>
          <SheetContent
            data-sidebar="sidebar"
            data-mobile="true"
            className="w-(--sidebar-width) bg-sidebar p-0 text-sidebar-foreground [&>button]:hidden"
            style={
              {
                "--sidebar-width": SIDEBAR_WIDTH_MOBILE,
              } as React.CSSProperties
            }
            side={side}
          >
            <SheetHeader className="sr-only">
              <SheetTitle>Sidebar</SheetTitle>
              <SheetDescription>Displays the mobile sidebar.</SheetDescription>
            </SheetHeader>
            <div className="flex h-full w-full flex-col">{children}</div>
          </SheetContent>
        </Sheet>
      );
    }

    return (
      <div
        ref={ref}
        className="group peer hidden text-sidebar-foreground md:block"
        data-state={state}
        data-collapsible={state === "collapsed" ? collapsible : ""}
        data-variant={variant}
        data-side={side}
      >
        {/* This is what handles the sidebar gap on desktop */}
        <div
          className={cn(
            "relative w-(--sidebar-width) bg-transparent transition-[width] duration-200 ease-linear",
            "group-data-[collapsible=offcanvas]:w-0",
            "group-data-[side=right]:rotate-180",
            variant === "floating" || variant === "inset"
              ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)_+_theme(spacing.4))]"
              : "group-data-[collapsible=icon]:w-(--sidebar-width-icon)",
          )}
        />
        <div
          className={cn(
            "fixed inset-y-0 z-10 hidden h-svh w-(--sidebar-width) transition-[left,right,width] duration-200 ease-linear md:flex",
            side === "left"
              ? "left-0 group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)]"
              : "right-0 group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)]",
            // Adjust the padding for floating and inset variants.
            variant === "floating" || variant === "inset"
              ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)_+_theme(spacing.4)_+2px)]"
              : "group-data-[collapsible=icon]:w-(--sidebar-width-icon) group-data-[side=left]:border-r group-data-[side=right]:border-l",
            className,
          )}
          {...props}
        >
          <div
            data-sidebar="sidebar"
            className="flex h-full w-full flex-col bg-sidebar group-data-[variant=floating]:rounded-lg group-data-[variant=floating]:border group-data-[variant=floating]:border-sidebar-border group-data-[variant=floating]:shadow"
          >
            {children}
          </div>
        </div>
      </div>
    );
  },
);
Sidebar.displayName = "Sidebar";

const SidebarTrigger = React.forwardRef<
  React.ElementRef<typeof Button>,
  React.ComponentProps<typeof Button>
>(({ className, onClick, ...props }, ref) => {
  const { toggleSidebar } = useSidebar();

  return (
    <Button
      ref={ref}
      data-sidebar="trigger"
      variant="ghost"
      size="icon"
      className={cn("h-7 w-7", className)}
      onClick={(event) => {
        onClick?.(event);
        toggleSidebar();
      }}
      {...props}
    >
      <PanelLeft />
      <span className="sr-only">Toggle Sidebar</span>
    </Button>
  );
});
SidebarTrigger.displayName = "SidebarTrigger";

const SidebarRail = React.forwardRef<HTMLButtonElement, React.ComponentProps<"button">>(
  ({ className, ...props }, ref) => {
    const { toggleSidebar } = useSidebar();

    return (
      <button
        ref={ref}
        data-sidebar="rail"
        aria-label="Toggle Sidebar"
        tabIndex={-1}
        onClick={toggleSidebar}
        title="Toggle Sidebar"
        className={cn(
          "absolute inset-y-0 z-20 hidden w-4 -translate-x-1/2 transition-all ease-linear after:absolute after:inset-y-0 after:left-1/2 after:w-[2px] hover:after:bg-sidebar-border group-data-[side=left]:-right-4 group-data-[side=right]:left-0 sm:flex",
          "[[data-side=left]_&]:cursor-w-resize [[data-side=right]_&]:cursor-e-resize",
          "[[data-side=left][data-state=collapsed]_&]:cursor-e-resize [[data-side=right][data-state=collapsed]_&]:cursor-w-resize",
          "group-data-[collapsible=offcanvas]:translate-x-0 group-data-[collapsible=offcanvas]:after:left-full group-data-[collapsible=offcanvas]:hover:bg-sidebar",
          "[[data-side=left][data-collapsible=offcanvas]_&]:-right-2",
          "[[data-side=right][data-collapsible=offcanvas]_&]:-left-2",
          className,
        )}
        {...props}
      />
    );
  },
);
SidebarRail.displayName = "SidebarRail";

const SidebarInset = React.forwardRef<HTMLDivElement, React.ComponentProps<"main">>(
  ({ className, ...props }, ref) => {
    return (
      <main
        ref={ref}
        className={cn(
          "relative flex w-full flex-1 flex-col bg-background",
          "md:peer-data-[variant=inset]:m-2 md:peer-data-[state=collapsed]:peer-data-[variant=inset]:ml-2 md:peer-data-[variant=inset]:ml-0 md:peer-data-[variant=inset]:rounded-xl md:peer-data-[variant=inset]:shadow",
          className,
        )}
        {...props}
      />
    );
  },
);
SidebarInset.displayName = "SidebarInset";

const SidebarInput = React.forwardRef<
  React.ElementRef<typeof Input>,
  React.ComponentProps<typeof Input>
>(({ className, ...props }, ref) => {
  return (
    <Input
      ref={ref}
      data-sidebar="input"
      className={cn(
        "h-8 w-full bg-background shadow-none focus-visible:ring-2 focus-visible:ring-sidebar-ring",
        className,
      )}
      {...props}
    />
  );
});
SidebarInput.displayName = "SidebarInput";

const SidebarHeader = React.forwardRef<HTMLDivElement, React.ComponentProps<"div">>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        data-sidebar="header"
        className={cn("flex flex-col gap-2 p-2", className)}
        {...props}
      />
    );
  },
);
SidebarHeader.displayName = "SidebarHeader";

const SidebarFooter = React.forwardRef<HTMLDivElement, React.ComponentProps<"div">>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        data-sidebar="footer"
        className={cn("flex flex-col gap-2 p-2", className)}
        {...props}
      />
    );
  },
);
SidebarFooter.displayName = "SidebarFooter";

const SidebarSeparator = React.forwardRef<
  React.ElementRef<typeof Separator>,
  React.ComponentProps<typeof Separator>
>(({ className, ...props }, ref) => {
  return (
    <Separator
      ref={ref}
      data-sidebar="separator"
      className={cn("mx-2 w-auto bg-sidebar-border", className)}
      {...props}
    />
  );
});
SidebarSeparator.displayName = "SidebarSeparator";

const SidebarContent = React.forwardRef<HTMLDivElement, React.ComponentProps<"div">>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        data-sidebar="content"
        className={cn(
          "flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[collapsible=icon]:overflow-hidden",
          className,
        )}
        {...props}
      />
    );
  },
);
SidebarContent.displayName = "SidebarContent";

const SidebarGroup = React.forwardRef<HTMLDivElement, React.ComponentProps<"div">>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        data-sidebar="group"
        className={cn("relative flex w-full min-w-0 flex-col p-2", className)}
        {...props}
      />
    );
  },
);
SidebarGroup.displayName = "SidebarGroup";

const SidebarGroupLabel = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div"> & { asChild?: boolean }
>(({ className, asChild = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "div";

  return (
    <Comp
      ref={ref}
      data-sidebar="group-label"
      className={cn(
        "flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70 outline-none ring-sidebar-ring transition-[margin,opacity] duration-200 ease-linear focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0",
        "group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0",
        className,
      )}
      {...props}
    />
  );
});
SidebarGroupLabel.displayName = "SidebarGroupLabel";

const SidebarGroupAction = React.forwardRef<
  HTMLButtonElement,
  React.ComponentProps<"button"> & { asChild?: boolean }
>(({ className, asChild = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "button";

  return (
    <Comp
      ref={ref}
      data-sidebar="group-action"
      className={cn(
        "absolute right-3 top-3.5 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground outline-none ring-sidebar-ring cursor-pointer transition-transform hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0",
        // Increases the hit area of the button on mobile.
        "after:absolute after:-inset-2 after:md:hidden",
        "group-data-[collapsible=icon]:hidden",
        className,
      )}
      {...props}
    />
  );
});
SidebarGroupAction.displayName = "SidebarGroupAction";

const SidebarGroupContent = React.forwardRef<HTMLDivElement, React.ComponentProps<"div">>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      data-sidebar="group-content"
      className={cn("w-full text-sm", className)}
      {...props}
    />
  ),
);
SidebarGroupContent.displayName = "SidebarGroupContent";

const SidebarMenu = React.forwardRef<HTMLUListElement, React.ComponentProps<"ul">>(
  ({ className, ...props }, ref) => (
    <ul
      ref={ref}
      data-sidebar="menu"
      className={cn("flex w-full min-w-0 flex-col gap-1", className)}
      {...props}
    />
  ),
);
SidebarMenu.displayName = "SidebarMenu";

const SidebarMenuItem = React.forwardRef<HTMLLIElement, React.ComponentProps<"li">>(
  ({ className, ...props }, ref) => (
    <li
      ref={ref}
      data-sidebar="menu-item"
      className={cn("group/menu-item relative", className)}
      {...props}
    />
  ),
);
SidebarMenuItem.displayName = "SidebarMenuItem";

const sidebarMenuButtonVariants = cva(
  "peer/menu-button flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm outline-none ring-sidebar-ring cursor-pointer transition-[width,height,padding] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed group-has-[[data-sidebar=menu-action]]/menu-item:pr-8 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium data-[active=true]:text-sidebar-accent-foreground data-[state=open]:hover:bg-sidebar-accent data-[state=open]:hover:text-sidebar-accent-foreground group-data-[collapsible=icon]:!size-8 group-data-[collapsible=icon]:!p-2 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
        outline:
          "bg-background shadow-[0_0_0_1px_var(--sidebar-border)] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_var(--sidebar-accent)]",
      },
      size: {
        default: "h-8 text-sm",
        sm: "h-7 text-xs",
        lg: "h-12 text-sm group-data-[collapsible=icon]:!p-0",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

const SidebarMenuButton = React.forwardRef<
  HTMLButtonElement,
  React.ComponentProps<"button"> & {
    asChild?: boolean;
    isActive?: boolean;
    tooltip?: string | React.ComponentProps<typeof TooltipContent>;
  } & VariantProps<typeof sidebarMenuButtonVariants>
>(
  (
    {
      asChild = false,
      isActive = false,
      variant = "default",
      size = "default",
      tooltip,
      className,
      ...props
    },
    ref,
  ) => {
    const Comp = asChild ? Slot : "button";
    const { isMobile, state } = useSidebar();

    const button = (
      <Comp
        ref={ref}
        data-sidebar="menu-button"
        data-size={size}
        data-active={isActive}
        className={cn(sidebarMenuButtonVariants({ variant, size }), className)}
        {...props}
      />
    );

    if (!tooltip) {
      return button;
    }

    if (typeof tooltip === "string") {
      tooltip = {
        children: tooltip,
      };
    }

    return (
      <Tooltip>
        <TooltipTrigger asChild>{button}</TooltipTrigger>
        <TooltipContent
          side="right"
          align="center"
          hidden={state !== "collapsed" || isMobile}
          {...tooltip}
        />
      </Tooltip>
    );
  },
);
SidebarMenuButton.displayName = "SidebarMenuButton";

const SidebarMenuAction = React.forwardRef<
  HTMLButtonElement,
  React.ComponentProps<"button"> & {
    asChild?: boolean;
    showOnHover?: boolean;
  }
>(({ className, asChild = false, showOnHover = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "button";

  return (
    <Comp
      ref={ref}
      data-sidebar="menu-action"
      className={cn(
        "absolute right-1 top-1.5 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground outline-none ring-sidebar-ring cursor-pointer transition-transform hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 peer-hover/menu-button:text-sidebar-accent-foreground [&>svg]:size-4 [&>svg]:shrink-0",
        // Increases the hit area of the button on mobile.
        "after:absolute after:-inset-2 after:md:hidden",
        "peer-data-[size=sm]/menu-button:top-1",
        "peer-data-[size=default]/menu-button:top-1.5",
        "peer-data-[size=lg]/menu-button:top-2.5",
        "group-data-[collapsible=icon]:hidden",
        showOnHover &&
          "group-focus-within/menu-item:opacity-100 group-hover/menu-item:opacity-100 data-[state=open]:opacity-100 peer-data-[active=true]/menu-button:text-sidebar-accent-foreground md:opacity-0",
        className,
      )}
      {...props}
    />
  );
});
SidebarMenuAction.displayName = "SidebarMenuAction";

const SidebarMenuBadge = React.forwardRef<HTMLDivElement, React.ComponentProps<"div">>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      data-sidebar="menu-badge"
      className={cn(
        "pointer-events-none absolute right-1 flex h-5 min-w-5 select-none items-center justify-center rounded-md px-1 text-xs font-medium tabular-nums text-sidebar-foreground",
        "peer-hover/menu-button:text-sidebar-accent-foreground peer-data-[active=true]/menu-button:text-sidebar-accent-foreground",
        "peer-data-[size=sm]/menu-button:top-1",
        "peer-data-[size=default]/menu-button:top-1.5",
        "peer-data-[size=lg]/menu-button:top-2.5",
        "group-data-[collapsible=icon]:hidden",
        className,
      )}
      {...props}
    />
  ),
);
SidebarMenuBadge.displayName = "SidebarMenuBadge";

const SidebarMenuSkeleton = React.forwardRef<
  HTMLDivElement,
  React.ComponentProps<"div"> & {
    showIcon?: boolean;
  }
>(({ className, showIcon = false, ...props }, ref) => {
  // Random width between 50 to 90%.
  const width = React.useMemo(() => {
    return `${Math.floor(Math.random() * 40) + 50}%`;
  }, []);

  return (
    <div
      ref={ref}
      data-sidebar="menu-skeleton"
      className={cn("flex h-8 items-center gap-2 rounded-md px-2", className)}
      {...props}
    >
      {showIcon && <Skeleton className="size-4 rounded-md" data-sidebar="menu-skeleton-icon" />}
      <Skeleton
        className="h-4 max-w-(--skeleton-width) flex-1"
        data-sidebar="menu-skeleton-text"
        style={
          {
            "--skeleton-width": width,
          } as React.CSSProperties
        }
      />
    </div>
  );
});
SidebarMenuSkeleton.displayName = "SidebarMenuSkeleton";

const SidebarMenuSub = React.forwardRef<HTMLUListElement, React.ComponentProps<"ul">>(
  ({ className, ...props }, ref) => (
    <ul
      ref={ref}
      data-sidebar="menu-sub"
      className={cn(
        "mx-3.5 flex min-w-0 translate-x-px flex-col gap-1 border-l border-sidebar-border px-2.5 py-0.5",
        "group-data-[collapsible=icon]:hidden",
        className,
      )}
      {...props}
    />
  ),
);
SidebarMenuSub.displayName = "SidebarMenuSub";

const SidebarMenuSubItem = React.forwardRef<HTMLLIElement, React.ComponentProps<"li">>(
  ({ ...props }, ref) => <li ref={ref} {...props} />,
);
SidebarMenuSubItem.displayName = "SidebarMenuSubItem";

const SidebarMenuSubButton = React.forwardRef<
  HTMLAnchorElement,
  React.ComponentProps<"a"> & {
    asChild?: boolean;
    size?: "sm" | "md";
    isActive?: boolean;
  }
>(({ asChild = false, size = "md", isActive, className, ...props }, ref) => {
  const Comp = asChild ? Slot : "a";

  return (
    <Comp
      ref={ref}
      data-sidebar="menu-sub-button"
      data-size={size}
      data-active={isActive}
      className={cn(
        "flex h-7 min-w-0 -translate-x-px items-center gap-2 overflow-hidden rounded-md px-2 text-sidebar-foreground outline-none ring-sidebar-ring cursor-pointer hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed aria-disabled:pointer-events-none aria-disabled:opacity-50 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0 [&>svg]:text-sidebar-accent-foreground",
        "data-[active=true]:bg-sidebar-accent data-[active=true]:text-sidebar-accent-foreground",
        size === "sm" && "text-xs",
        size === "md" && "text-sm",
        "group-data-[collapsible=icon]:hidden",
        className,
      )}
      {...props}
    />
  );
});
SidebarMenuSubButton.displayName = "SidebarMenuSubButton";

export {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupAction,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInput,
  SidebarInset,
  SidebarMenu,
  SidebarMenuAction,
  SidebarMenuBadge,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSkeleton,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarProvider,
  SidebarRail,
  SidebarSeparator,
  SidebarTrigger,
  useSidebar,
};

```

## FILE 63: src/components/ui/skeleton.tsx

```tsx
import { cn } from "@/lib/utils";

function Skeleton({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("animate-pulse rounded-md bg-primary/10", className)} {...props} />;
}

export { Skeleton };

```

## FILE 64: src/components/ui/slider.tsx

```tsx
import * as React from "react";
import * as SliderPrimitive from "@radix-ui/react-slider";

import { cn } from "@/lib/utils";

const Slider = React.forwardRef<
  React.ElementRef<typeof SliderPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof SliderPrimitive.Root>
>(({ className, ...props }, ref) => (
  <SliderPrimitive.Root
    ref={ref}
    className={cn("relative flex w-full touch-none select-none items-center", className)}
    {...props}
  >
    <SliderPrimitive.Track className="relative h-1.5 w-full grow overflow-hidden rounded-full bg-primary/20">
      <SliderPrimitive.Range className="absolute h-full bg-primary" />
    </SliderPrimitive.Track>
    <SliderPrimitive.Thumb className="block h-4 w-4 rounded-full border border-primary/50 bg-background shadow transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50" />
  </SliderPrimitive.Root>
));
Slider.displayName = SliderPrimitive.Root.displayName;

export { Slider };

```

## FILE 65: src/components/ui/sonner.tsx

```tsx
import { Toaster as Sonner } from "sonner";

type ToasterProps = React.ComponentProps<typeof Sonner>;

const Toaster = ({ ...props }: ToasterProps) => {
  return (
    <Sonner
      className="toaster group"
      toastOptions={{
        classNames: {
          toast:
            "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
          description: "group-[.toast]:text-muted-foreground",
          actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground",
        },
      }}
      {...props}
    />
  );
};

export { Toaster };

```

## FILE 66: src/components/ui/switch.tsx

```tsx
import * as React from "react";
import * as SwitchPrimitives from "@radix-ui/react-switch";

import { cn } from "@/lib/utils";

const Switch = React.forwardRef<
  React.ElementRef<typeof SwitchPrimitives.Root>,
  React.ComponentPropsWithoutRef<typeof SwitchPrimitives.Root>
>(({ className, ...props }, ref) => (
  <SwitchPrimitives.Root
    className={cn(
      "peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input",
      className,
    )}
    {...props}
    ref={ref}
  >
    <SwitchPrimitives.Thumb
      className={cn(
        "pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0",
      )}
    />
  </SwitchPrimitives.Root>
));
Switch.displayName = SwitchPrimitives.Root.displayName;

export { Switch };

```

## FILE 67: src/components/ui/table.tsx

```tsx
import * as React from "react";

import { cn } from "@/lib/utils";

const Table = React.forwardRef<HTMLTableElement, React.HTMLAttributes<HTMLTableElement>>(
  ({ className, ...props }, ref) => (
    <div className="relative w-full overflow-auto">
      <table ref={ref} className={cn("w-full caption-bottom text-sm", className)} {...props} />
    </div>
  ),
);
Table.displayName = "Table";

const TableHeader = React.forwardRef<
  HTMLTableSectionElement,
  React.HTMLAttributes<HTMLTableSectionElement>
>(({ className, ...props }, ref) => (
  <thead ref={ref} className={cn("[&_tr]:border-b", className)} {...props} />
));
TableHeader.displayName = "TableHeader";

const TableBody = React.forwardRef<
  HTMLTableSectionElement,
  React.HTMLAttributes<HTMLTableSectionElement>
>(({ className, ...props }, ref) => (
  <tbody ref={ref} className={cn("[&_tr:last-child]:border-0", className)} {...props} />
));
TableBody.displayName = "TableBody";

const TableFooter = React.forwardRef<
  HTMLTableSectionElement,
  React.HTMLAttributes<HTMLTableSectionElement>
>(({ className, ...props }, ref) => (
  <tfoot
    ref={ref}
    className={cn("border-t bg-muted/50 font-medium [&>tr]:last:border-b-0", className)}
    {...props}
  />
));
TableFooter.displayName = "TableFooter";

const TableRow = React.forwardRef<HTMLTableRowElement, React.HTMLAttributes<HTMLTableRowElement>>(
  ({ className, ...props }, ref) => (
    <tr
      ref={ref}
      className={cn(
        "border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted",
        className,
      )}
      {...props}
    />
  ),
);
TableRow.displayName = "TableRow";

const TableHead = React.forwardRef<
  HTMLTableCellElement,
  React.ThHTMLAttributes<HTMLTableCellElement>
>(({ className, ...props }, ref) => (
  <th
    ref={ref}
    className={cn(
      "h-10 px-2 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]",
      className,
    )}
    {...props}
  />
));
TableHead.displayName = "TableHead";

const TableCell = React.forwardRef<
  HTMLTableCellElement,
  React.TdHTMLAttributes<HTMLTableCellElement>
>(({ className, ...props }, ref) => (
  <td
    ref={ref}
    className={cn(
      "p-2 align-middle [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]",
      className,
    )}
    {...props}
  />
));
TableCell.displayName = "TableCell";

const TableCaption = React.forwardRef<
  HTMLTableCaptionElement,
  React.HTMLAttributes<HTMLTableCaptionElement>
>(({ className, ...props }, ref) => (
  <caption ref={ref} className={cn("mt-4 text-sm text-muted-foreground", className)} {...props} />
));
TableCaption.displayName = "TableCaption";

export { Table, TableHeader, TableBody, TableFooter, TableHead, TableRow, TableCell, TableCaption };

```

## FILE 68: src/components/ui/tabs.tsx

```tsx
import * as React from "react";
import * as TabsPrimitive from "@radix-ui/react-tabs";

import { cn } from "@/lib/utils";

const Tabs = TabsPrimitive.Root;

const TabsList = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.List>,
  React.ComponentPropsWithoutRef<typeof TabsPrimitive.List>
>(({ className, ...props }, ref) => (
  <TabsPrimitive.List
    ref={ref}
    className={cn(
      "inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground",
      className,
    )}
    {...props}
  />
));
TabsList.displayName = TabsPrimitive.List.displayName;

const TabsTrigger = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof TabsPrimitive.Trigger>
>(({ className, ...props }, ref) => (
  <TabsPrimitive.Trigger
    ref={ref}
    className={cn(
      "inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow",
      className,
    )}
    {...props}
  />
));
TabsTrigger.displayName = TabsPrimitive.Trigger.displayName;

const TabsContent = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof TabsPrimitive.Content>
>(({ className, ...props }, ref) => (
  <TabsPrimitive.Content
    ref={ref}
    className={cn(
      "mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
      className,
    )}
    {...props}
  />
));
TabsContent.displayName = TabsPrimitive.Content.displayName;

export { Tabs, TabsList, TabsTrigger, TabsContent };

```

## FILE 69: src/components/ui/textarea.tsx

```tsx
import * as React from "react";

import { cn } from "@/lib/utils";

const Textarea = React.forwardRef<HTMLTextAreaElement, React.ComponentProps<"textarea">>(
  ({ className, ...props }, ref) => {
    return (
      <textarea
        className={cn(
          "flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className,
        )}
        ref={ref}
        {...props}
      />
    );
  },
);
Textarea.displayName = "Textarea";

export { Textarea };

```

## FILE 70: src/components/ui/toggle-group.tsx

```tsx
"use client";

import * as React from "react";
import * as ToggleGroupPrimitive from "@radix-ui/react-toggle-group";
import { type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";
import { toggleVariants } from "@/components/ui/toggle";

const ToggleGroupContext = React.createContext<VariantProps<typeof toggleVariants>>({
  size: "default",
  variant: "default",
});

const ToggleGroup = React.forwardRef<
  React.ElementRef<typeof ToggleGroupPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ToggleGroupPrimitive.Root> &
    VariantProps<typeof toggleVariants>
>(({ className, variant, size, children, ...props }, ref) => (
  <ToggleGroupPrimitive.Root
    ref={ref}
    className={cn("flex items-center justify-center gap-1", className)}
    {...props}
  >
    <ToggleGroupContext.Provider value={{ variant, size }}>{children}</ToggleGroupContext.Provider>
  </ToggleGroupPrimitive.Root>
));

ToggleGroup.displayName = ToggleGroupPrimitive.Root.displayName;

const ToggleGroupItem = React.forwardRef<
  React.ElementRef<typeof ToggleGroupPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof ToggleGroupPrimitive.Item> &
    VariantProps<typeof toggleVariants>
>(({ className, children, variant, size, ...props }, ref) => {
  const context = React.useContext(ToggleGroupContext);

  return (
    <ToggleGroupPrimitive.Item
      ref={ref}
      className={cn(
        toggleVariants({
          variant: context.variant || variant,
          size: context.size || size,
        }),
        className,
      )}
      {...props}
    >
      {children}
    </ToggleGroupPrimitive.Item>
  );
});

ToggleGroupItem.displayName = ToggleGroupPrimitive.Item.displayName;

export { ToggleGroup, ToggleGroupItem };

```

## FILE 71: src/components/ui/toggle.tsx

```tsx
import * as React from "react";
import * as TogglePrimitive from "@radix-ui/react-toggle";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const toggleVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-md text-sm font-medium cursor-pointer transition-colors hover:bg-muted hover:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=on]:bg-accent data-[state=on]:text-accent-foreground [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-transparent",
        outline:
          "border border-input bg-transparent shadow-sm hover:bg-accent hover:text-accent-foreground",
      },
      size: {
        default: "h-9 px-2 min-w-9",
        sm: "h-8 px-1.5 min-w-8",
        lg: "h-10 px-2.5 min-w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

const Toggle = React.forwardRef<
  React.ElementRef<typeof TogglePrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof TogglePrimitive.Root> & VariantProps<typeof toggleVariants>
>(({ className, variant, size, ...props }, ref) => (
  <TogglePrimitive.Root
    ref={ref}
    className={cn(toggleVariants({ variant, size, className }))}
    {...props}
  />
));

Toggle.displayName = TogglePrimitive.Root.displayName;

export { Toggle, toggleVariants };

```

## FILE 72: src/components/ui/tooltip.tsx

```tsx
"use client";

import * as React from "react";
import * as TooltipPrimitive from "@radix-ui/react-tooltip";

import { cn } from "@/lib/utils";

const TooltipProvider = TooltipPrimitive.Provider;

const Tooltip = TooltipPrimitive.Root;

const TooltipTrigger = TooltipPrimitive.Trigger;

const TooltipContent = React.forwardRef<
  React.ElementRef<typeof TooltipPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof TooltipPrimitive.Content>
>(({ className, sideOffset = 4, ...props }, ref) => (
  <TooltipPrimitive.Portal>
    <TooltipPrimitive.Content
      ref={ref}
      sideOffset={sideOffset}
      className={cn(
        "z-50 overflow-hidden rounded-md bg-primary px-3 py-1.5 text-xs text-primary-foreground animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-tooltip-content-transform-origin)",
        className,
      )}
      {...props}
    />
  </TooltipPrimitive.Portal>
));
TooltipContent.displayName = TooltipPrimitive.Content.displayName;

export { Tooltip, TooltipTrigger, TooltipContent, TooltipProvider };

```

## FILE 73: src/data/seed.ts

```ts
import type {
  Course,
  DemoUser,
  Employer,
  EmploymentStatus,
  FollowUp,
  FollowUpMilestone,
  NonPlacementReason,
  Provider,
  TimelineEvent,
  Trainee,
} from "@/types";

export const DISTRICTS = [
  "Pune",
  "Mumbai",
  "Nagpur",
  "Nashik",
  "Aurangabad",
  "Kolhapur",
  "Thane",
  "Satara",
] as const;

export const COURSES: Course[] = [
  {
    id: "C-WEB",
    name: "Web Development",
    sector: "IT & ITeS",
    durationWeeks: 24,
    skills: ["JavaScript", "HTML", "CSS", "React", "SQL", "Communication"],
  },
  {
    id: "C-ELE",
    name: "Electrician",
    sector: "Electrical",
    durationWeeks: 16,
    skills: ["Wiring", "Safety Standards", "Motor Repair", "Blueprint Reading"],
  },
  {
    id: "C-HCA",
    name: "Healthcare Assistant",
    sector: "Healthcare",
    durationWeeks: 20,
    skills: ["Patient Care", "First Aid", "Record Keeping", "Communication"],
  },
  {
    id: "C-DEO",
    name: "Data Entry Operator",
    sector: "IT & ITeS",
    durationWeeks: 12,
    skills: ["Excel", "Typing Speed", "Data Accuracy", "SQL"],
  },
  {
    id: "C-TAI",
    name: "Tailoring & Garment Making",
    sector: "Apparel",
    durationWeeks: 14,
    skills: ["Pattern Making", "Machine Stitching", "Quality Check"],
  },
  {
    id: "C-AUT",
    name: "Automotive Technician",
    sector: "Automotive",
    durationWeeks: 22,
    skills: ["Engine Diagnostics", "Safety Standards", "Electrical Systems"],
  },
];

export const PROVIDERS: Provider[] = [
  {
    id: "P-01",
    name: "Sahyadri Skill Academy",
    district: "Pune",
    courses: ["C-WEB", "C-DEO", "C-ELE"],
    rating: 4.6,
    accreditation: "A+",
  },
  {
    id: "P-02",
    name: "Konkan Vocational Institute",
    district: "Mumbai",
    courses: ["C-WEB", "C-HCA"],
    rating: 4.3,
    accreditation: "A",
  },
  {
    id: "P-03",
    name: "Vidarbha Technical Centre",
    district: "Nagpur",
    courses: ["C-ELE", "C-AUT"],
    rating: 3.9,
    accreditation: "B",
  },
  {
    id: "P-04",
    name: "Godavari Livelihood Mission",
    district: "Nashik",
    courses: ["C-TAI", "C-HCA", "C-DEO"],
    rating: 4.1,
    accreditation: "A",
  },
  {
    id: "P-05",
    name: "Marathwada Kaushalya Kendra",
    district: "Aurangabad",
    courses: ["C-AUT", "C-TAI"],
    rating: 3.6,
    accreditation: "C",
  },
  {
    id: "P-06",
    name: "Panchganga Industrial Training",
    district: "Kolhapur",
    courses: ["C-ELE", "C-DEO"],
    rating: 4.0,
    accreditation: "B",
  },
];

export const EMPLOYERS: Employer[] = [
  {
    id: "E-01",
    name: "Trimurti Softworks Pvt Ltd",
    sector: "IT & ITeS",
    district: "Pune",
    status: "Verified",
    skillRequirements: ["JavaScript", "React", "SQL", "Communication"],
    feedback: "Trainees are strong on frontend basics but need deeper database knowledge.",
    rating: 4.2,
  },
  {
    id: "E-02",
    name: "Sagar Health Services",
    sector: "Healthcare",
    district: "Mumbai",
    status: "Verified",
    skillRequirements: ["Patient Care", "First Aid", "Record Keeping"],
    feedback: "Well prepared for ward duties; documentation skills improving.",
    rating: 4.5,
  },
  {
    id: "E-03",
    name: "Deccan Motors Works",
    sector: "Automotive",
    district: "Nagpur",
    status: "Pending Verification",
    skillRequirements: ["Engine Diagnostics", "Electrical Systems", "Safety Standards"],
    feedback: "Need more hands-on diagnostics practice before deployment.",
    rating: 3.8,
  },
  {
    id: "E-04",
    name: "Ajanta Apparels",
    sector: "Apparel",
    district: "Aurangabad",
    status: "Verified",
    skillRequirements: ["Machine Stitching", "Quality Check", "Pattern Making"],
    feedback: "Good productivity; quality inspection training could improve.",
    rating: 4.0,
  },
  {
    id: "E-05",
    name: "Panchganga Electricals",
    sector: "Electrical",
    district: "Kolhapur",
    status: "Needs Review",
    skillRequirements: ["Wiring", "Safety Standards", "Motor Repair"],
    feedback: "Safety compliance awareness is excellent.",
    rating: 3.9,
  },
  {
    id: "E-06",
    name: "Nashik BPO Solutions",
    sector: "IT & ITeS",
    district: "Nashik",
    status: "Verified",
    skillRequirements: ["Excel", "Data Accuracy", "SQL", "Communication"],
    feedback: "Excel proficiency is good, SQL exposure is limited.",
    rating: 4.1,
  },
];

export const DEMO_USERS: DemoUser[] = [
  { email: "admin@mahaskill.demo", name: "Anjali Deshmukh", role: "admin", password: "demo1234" },
  {
    email: "provider@mahaskill.demo",
    name: "Sahyadri Skill Academy",
    role: "provider",
    password: "demo1234",
    providerId: "P-01",
  },
  {
    email: "trainee@mahaskill.demo",
    name: "Rahul Pawar",
    role: "trainee",
    password: "demo1234",
    traineeId: "MST-1001",
  },
  {
    email: "employer@mahaskill.demo",
    name: "Trimurti Softworks Pvt Ltd",
    role: "employer",
    password: "demo1234",
    employerId: "E-01",
  },
];

const FIRST_NAMES = [
  "Rahul","Priya","Amit","Sneha","Vikram","Kavita","Nilesh","Pooja","Sagar","Meera",
  "Rohit","Aarti","Ganesh","Shraddha","Prashant","Manisha","Akash","Rupali","Sandeep","Vaishali",
  "Kiran","Deepak","Swapnil","Ashwini","Tushar","Mansi","Yogesh","Rutuja","Nikhil","Sushma",
  "Omkar","Pallavi","Harshad","Trupti","Balaji","Shital","Chetan","Namrata","Dattatray","Jyoti",
  "Suraj","Anita","Mahesh","Komal","Vishal","Snehal","Abhijit","Bhagyashree",
];
const LAST_NAMES = [
  "Pawar","Jadhav","Kulkarni","Shinde","Patil","Deshmukh","More","Gaikwad","Chavan","Kadam",
  "Sawant","Bhosale","Salunkhe","Waghmare","Thorat","Mane","Rane","Kamble",
];
const EDUCATION = ["10th Pass", "12th Pass", "ITI Diploma", "Graduate", "Undergraduate"];

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const NON_PLACEMENT: NonPlacementReason[] = [
  "Lack of required skills",
  "Lack of suitable jobs",
  "Salary too low",
  "Location constraints",
  "Personal reasons",
  "Further education",
  "Health/family reasons",
  "Not interested",
];

function fmt(date: Date) {
  return date.toISOString().slice(0, 10);
}
function addMonths(date: Date, months: number) {
  const d = new Date(date);
  d.setMonth(d.getMonth() + months);
  return d;
}

const REFERENCE_DATE = new Date("2026-09-01T00:00:00Z");

function buildTimeline(t: {
  startDate: string;
  endDate: string;
  certified: boolean;
  employmentStatus: EmploymentStatus;
  employmentDate?: string;
  followUps: FollowUp[];
}): TimelineEvent[] {
  const events: TimelineEvent[] = [
    {
      id: "enroll",
      label: "Enrollment",
      date: fmt(addMonths(new Date(t.startDate), -1)),
      status: "done",
      detail: "Registered under Maharashtra State Skill Development Mission.",
    },
    {
      id: "start",
      label: "Training Started",
      date: t.startDate,
      status: "done",
      detail: "Batch commenced at the assigned training centre.",
    },
    {
      id: "complete",
      label: "Training Completed",
      date: t.endDate,
      status: "done",
      detail: "Course curriculum completed and assessed.",
    },
  ];
  events.push({
    id: "cert",
    label: "Certification",
    date: t.certified ? fmt(addMonths(new Date(t.endDate), 1)) : "—",
    status: t.certified ? "done" : "upcoming",
    detail: t.certified ? "NSQF-aligned certificate issued." : "Certification pending re-assessment.",
  });
  events.push({
    id: "search",
    label: "Job Search",
    date: fmt(addMonths(new Date(t.endDate), 1)),
    status: "done",
    detail: "Placement counselling and employer connect drive.",
  });
  const placed = ["Employed", "Self-employed", "Apprenticeship"].includes(t.employmentStatus);
  events.push({
    id: "employment",
    label: placed ? t.employmentStatus : "Awaiting Placement",
    date: placed && t.employmentDate ? t.employmentDate : "—",
    status: placed ? "done" : "current",
    detail: placed
      ? "Outcome recorded and verified in the outcome registry."
      : `Current status: ${t.employmentStatus}.`,
  });
  for (const f of t.followUps) {
    events.push({
      id: `fu-${f.milestone}`,
      label: `${f.milestone} Follow-up`,
      date: f.completedDate ?? f.dueDate,
      status: f.status === "Completed" ? "done" : f.status === "Due" ? "current" : "upcoming",
      detail:
        f.status === "Completed"
          ? `${f.employmentStatus}${f.salary ? ` · ₹${f.salary.toLocaleString("en-IN")}/month` : ""}`
          : `${f.status} — due ${f.dueDate}`,
    });
  }
  return events;
}

export function generateTrainees(): Trainee[] {
  const rand = mulberry32(20260830);
  const pick = <T,>(arr: readonly T[]) => arr[Math.floor(rand() * arr.length)]!;
  const trainees: Trainee[] = [];

  const outcomeWeights: EmploymentStatus[] = [
    ...Array(14).fill("Employed"),
    ...Array(3).fill("Self-employed"),
    ...Array(2).fill("Apprenticeship"),
    ...Array(3).fill("Seeking Employment"),
    "Further Education",
    "Unreachable",
  ];

  for (let i = 0; i < 46; i++) {
    const id = `MST-${1001 + i}`;
    const first = i === 0 ? "Rahul" : FIRST_NAMES[i % FIRST_NAMES.length]!;
    const last = i === 0 ? "Pawar" : LAST_NAMES[(i * 3) % LAST_NAMES.length]!;
    const name = `${first} ${last}`;
    const provider = PROVIDERS[i % PROVIDERS.length]!;
    const courseId = provider.courses[Math.floor(rand() * provider.courses.length)]!;
    const course = COURSES.find((c) => c.id === courseId)!;
    const district = rand() < 0.7 ? provider.district : pick(DISTRICTS);
    const trainingYear = rand() < 0.65 ? 2025 : 2024;
    const startMonth = Math.floor(rand() * 6) + 1;
    const startDate = new Date(Date.UTC(trainingYear, startMonth, 5));
    const endDate = addMonths(startDate, Math.round(course.durationWeeks / 4));
    const inTraining = i % 11 === 5;
    const trainingStatus = inTraining ? "In Training" : i % 17 === 3 ? "Dropped Out" : "Completed";
    let employmentStatus: EmploymentStatus =
      trainingStatus === "Completed" ? pick(outcomeWeights) : "Seeking Employment";
    if (i === 0) employmentStatus = "Employed";

    const certified = trainingStatus === "Completed" && rand() < 0.92;
    const attendance = Math.round(70 + rand() * 29);
    const assessmentScore = Math.round(52 + rand() * 46);
    const employmentDate = fmt(addMonths(endDate, 1 + Math.floor(rand() * 2)));
    const baseSalary =
      course.sector === "IT & ITeS"
        ? 18000 + Math.round(rand() * 9000)
        : course.sector === "Healthcare"
          ? 15000 + Math.round(rand() * 7000)
          : 13000 + Math.round(rand() * 8000);

    const monthsSinceJoin = Math.max(
      0,
      Math.round(
        (REFERENCE_DATE.getTime() - new Date(employmentDate).getTime()) / (1000 * 60 * 60 * 24 * 30),
      ),
    );

    const milestones: FollowUpMilestone[] = ["3 months", "6 months", "12 months"];
    const followUps: FollowUp[] = [];
    const isPlaced = ["Employed", "Self-employed", "Apprenticeship"].includes(employmentStatus);
    const salaryProgression: { point: string; salary: number }[] = isPlaced
      ? [{ point: "Joining", salary: baseSalary }]
      : [];

    milestones.forEach((m, mi) => {
      const monthOffset = [3, 6, 12][mi]!;
      const dueDate = fmt(addMonths(new Date(employmentDate), monthOffset));
      const isDue = monthsSinceJoin >= monthOffset;
      const growth = 1 + monthOffset * (0.012 + rand() * 0.012);
      const salary = Math.round((baseSalary * growth) / 500) * 500;
      if (isDue && employmentStatus !== "Unreachable" && rand() < 0.85) {
        followUps.push({
          id: `${id}-F${monthOffset}`,
          milestone: m,
          dueDate,
          completedDate: fmt(addMonths(new Date(dueDate), 0)),
          status: "Completed",
          employmentStatus,
          salary: isPlaced ? salary : undefined,
          skillsUsed: course.skills.slice(0, 3),
          satisfaction: Math.round(3 + rand() * 2),
          notes: isPlaced
            ? "Trainee confirmed continued employment during telephonic follow-up."
            : "Trainee still exploring opportunities; counselling offered.",
        });
        if (isPlaced) salaryProgression.push({ point: m, salary });
      } else if (isDue) {
        followUps.push({
          id: `${id}-F${monthOffset}`,
          milestone: m,
          dueDate,
          status: employmentStatus === "Unreachable" ? "Unreachable" : rand() < 0.5 ? "Due" : "Pending",
        });
      }
    });

    const employer = EMPLOYERS.find((e) => e.sector === course.sector) ?? EMPLOYERS[0]!;
    const trainee: Trainee = {
      id,
      name,
      age: 19 + Math.floor(rand() * 14),
      gender: rand() < 0.46 ? "Female" : "Male",
      district,
      education: pick(EDUCATION),
      contactReachable: employmentStatus !== "Unreachable",
      consent: rand() < 0.8 ? "Granted" : rand() < 0.6 ? "Partial" : "Withdrawn",
      consentDate: fmt(startDate),
      dataSharing: { analytics: true, employers: rand() < 0.75, research: rand() < 0.55 },
      courseId,
      providerId: provider.id,
      trainingCenter: `${provider.name} — ${district} Centre`,
      startDate: fmt(startDate),
      endDate: fmt(endDate),
      attendance,
      assessmentScore,
      certified,
      trainingStatus,
      employmentStatus,
      nonPlacementReason: isPlaced ? undefined : pick(NON_PLACEMENT),
      employment:
        employmentStatus === "Employed" || employmentStatus === "Apprenticeship"
          ? {
              employerId: employer.id,
              employerName: employer.name,
              jobTitle:
                course.id === "C-WEB"
                  ? "Junior Web Developer"
                  : course.id === "C-HCA"
                    ? "Healthcare Assistant"
                    : course.id === "C-DEO"
                      ? "Data Entry Executive"
                      : course.id === "C-ELE"
                        ? "Electrician (Grade II)"
                        : course.id === "C-AUT"
                          ? "Service Technician"
                          : "Machine Operator",
              joiningDate: employmentDate,
              salary: baseSalary,
              employmentType:
                employmentStatus === "Apprenticeship" ? "Apprenticeship" : "Full-time",
              location: `${employer.district}, Maharashtra`,
              verified: rand() < 0.75,
            }
          : employmentStatus === "Self-employed"
            ? {
                businessType:
                  course.id === "C-TAI"
                    ? "Tailoring unit"
                    : course.id === "C-ELE"
                      ? "Electrical repair shop"
                      : "Freelance services",
                businessStartDate: employmentDate,
                monthlyIncome: baseSalary,
                businessStatus: rand() < 0.6 ? "Active" : "Growing",
                verified: rand() < 0.5,
              }
            : {},
      salaryProgression,
      followUps,
      timeline: [],
      trainingYear,
      satisfaction: Math.round(3 + rand() * 2),
      email: i === 0 ? "trainee@mahaskill.demo" : undefined,
    };
    trainee.timeline = buildTimeline({
      startDate: trainee.startDate,
      endDate: trainee.endDate,
      certified: trainee.certified,
      employmentStatus: trainee.employmentStatus,
      employmentDate,
      followUps: trainee.followUps,
    });
    trainees.push(trainee);
  }

  // Ensure the demo trainee has the showcase journey from the brief.
  const demo = trainees[0]!;
  demo.employment = {
    employerId: "E-01",
    employerName: "Trimurti Softworks Pvt Ltd",
    jobTitle: "Junior Web Developer",
    joiningDate: "2025-09-15",
    salary: 20000,
    employmentType: "Full-time",
    location: "Pune, Maharashtra",
    verified: true,
  };
  demo.courseId = "C-WEB";
  demo.providerId = "P-01";
  demo.district = "Pune";
  demo.trainingStatus = "Completed";
  demo.certified = true;
  demo.attendance = 94;
  demo.assessmentScore = 88;
  demo.consent = "Granted";
  demo.salaryProgression = [
    { point: "Joining", salary: 20000 },
    { point: "3 months", salary: 22000 },
    { point: "6 months", salary: 25000 },
    { point: "12 months", salary: 30000 },
  ];
  demo.followUps = [
    {
      id: "MST-1001-F3",
      milestone: "3 months",
      dueDate: "2025-12-15",
      completedDate: "2025-12-18",
      status: "Completed",
      employmentStatus: "Employed",
      salary: 22000,
      skillsUsed: ["JavaScript", "HTML", "CSS"],
      satisfaction: 4,
      notes: "Confirmed employment; using core frontend skills daily.",
    },
    {
      id: "MST-1001-F6",
      milestone: "6 months",
      dueDate: "2026-03-15",
      completedDate: "2026-03-16",
      status: "Completed",
      employmentStatus: "Employed",
      salary: 25000,
      skillsUsed: ["JavaScript", "React", "SQL"],
      satisfaction: 4,
      notes: "Promoted to a project team; requested advanced SQL support.",
    },
    {
      id: "MST-1001-F12",
      milestone: "12 months",
      dueDate: "2026-09-15",
      status: "Due",
    },
  ];
  demo.timeline = buildTimeline({
    startDate: demo.startDate,
    endDate: demo.endDate,
    certified: true,
    employmentStatus: "Employed",
    employmentDate: "2025-09-15",
    followUps: demo.followUps,
  });

  return trainees;
}

export const SKILL_DEMAND: { skill: string; demand: number; coverage: number }[] = [
  { skill: "JavaScript", demand: 82, coverage: 61 },
  { skill: "SQL", demand: 74, coverage: 45 },
  { skill: "Communication", demand: 68, coverage: 52 },
  { skill: "Excel", demand: 61, coverage: 70 },
  { skill: "Engine Diagnostics", demand: 57, coverage: 49 },
  { skill: "Patient Care", demand: 64, coverage: 66 },
  { skill: "Safety Standards", demand: 59, coverage: 72 },
  { skill: "Quality Check", demand: 48, coverage: 38 },
];

export const NOTIFICATIONS = [
  {
    id: "n1",
    title: "128 trainees require 6-month follow-up",
    detail: "Follow-up window closes in 7 days across 6 districts.",
    tone: "warning" as const,
    time: "2h ago",
  },
  {
    id: "n2",
    title: "Godavari Livelihood Mission submitted new outcome data",
    detail: "42 outcome records awaiting validation.",
    tone: "info" as const,
    time: "5h ago",
  },
  {
    id: "n3",
    title: "15 employer records require verification",
    detail: "Employer verification backlog is above threshold.",
    tone: "warning" as const,
    time: "Yesterday",
  },
  {
    id: "n4",
    title: "Automotive Technician placement rate declining",
    detail: "Down 6.4 pts against the previous cohort.",
    tone: "danger" as const,
    time: "2 days ago",
  },
];

```

## FILE 74: src/hooks/use-mobile.tsx

```tsx
import * as React from "react";

const MOBILE_BREAKPOINT = 768;

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean | undefined>(undefined);

  React.useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`);
    const onChange = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    };
    mql.addEventListener("change", onChange);
    setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    return () => mql.removeEventListener("change", onChange);
  }, []);

  return !!isMobile;
}

```

## FILE 75: src/hooks/use-scope.ts

```ts
import { useMemo } from "react";

import { useAuth } from "@/auth/auth-context";
import { useStore } from "@/services/store";
import type { Trainee } from "@/types";

/**
 * Role-based data scoping. Administrators see everything; providers see their own
 * cohorts; employers see trainees they employ; trainees see only their own record.
 */
export function useScope() {
  const { user } = useAuth();
  const { trainees } = useStore();

  return useMemo(() => {
    const role = user?.role ?? "admin";
    let scoped: Trainee[] = trainees;
    if (role === "provider" && user?.providerId) {
      scoped = trainees.filter((t) => t.providerId === user.providerId);
    } else if (role === "employer" && user?.employerId) {
      scoped = trainees.filter((t) => t.employment.employerId === user.employerId);
    } else if (role === "trainee" && user?.traineeId) {
      scoped = trainees.filter((t) => t.id === user.traineeId);
    }
    const self = user?.traineeId ? trainees.find((t) => t.id === user.traineeId) : undefined;
    return {
      role,
      trainees: scoped,
      self,
      isAdmin: role === "admin",
      canEdit: role === "admin" || role === "provider",
      scopeLabel:
        role === "admin"
          ? "State-wide data"
          : role === "provider"
            ? "Your training centre cohorts"
            : role === "employer"
              ? "Trainees employed by your organisation"
              : "Your personal record",
    };
  }, [trainees, user]);
}

```

## FILE 76: src/lib/error-capture.ts

```ts
// Captures the original Error out-of-band so server.ts can recover the stack
// when h3 has already swallowed the throw into a generic 500 Response.

let lastCapturedError: { error: unknown; at: number } | undefined;
const TTL_MS = 5_000;

function record(error: unknown) {
  lastCapturedError = { error, at: Date.now() };
}

// h3's HTTPError serializes to {"status":500,"unhandled":true,"message":"HTTPError"} —
// no stack, no cause — so a plain console.error(error) reaches the log pipeline with
// the failure detail stripped. Expand Error-like args into a string that keeps the
// message, stack, and the full cause chain.
const CAUSE_DEPTH_LIMIT = 5;
const DESCRIPTION_LENGTH_LIMIT = 8_000;

export function describeError(error: unknown): string {
  const parts: string[] = [];
  let current: unknown = error;
  for (let depth = 0; depth < CAUSE_DEPTH_LIMIT && current != null; depth++) {
    if (!(current instanceof Error)) {
      parts.push(typeof current === "string" ? current : safeStringify(current));
      break;
    }
    const label = depth === 0 ? "" : "caused by: ";
    const status = describeStatus(current);
    parts.push(`${label}${current.stack ?? `${current.name}: ${current.message}`}${status}`);
    current = current.cause;
  }
  return parts.join("\n").slice(0, DESCRIPTION_LENGTH_LIMIT);
}

function describeStatus(error: Error): string {
  const { status, statusCode } = error as { status?: unknown; statusCode?: unknown };
  const value = status ?? statusCode;
  return typeof value === "number" ? ` (status ${value})` : "";
}

function safeStringify(value: unknown): string {
  try {
    return JSON.stringify(value) ?? String(value);
  } catch {
    return String(value);
  }
}

function isErrorLike(value: unknown): value is Error {
  return value instanceof Error;
}

// Wrap console.error so errors logged by any layer — including h3's internal
// unhandled-error logging, which this file cannot hook directly — are both
// recorded for consumeLastCapturedError and expanded before serialization.
const originalConsoleError = console.error.bind(console);
console.error = (...args: unknown[]) => {
  const expanded = args.map((arg) => {
    if (!isErrorLike(arg)) return arg;
    record(arg);
    return describeError(arg);
  });
  originalConsoleError(...expanded);
};

if (typeof globalThis.addEventListener === "function") {
  globalThis.addEventListener("error", (event) => record((event as ErrorEvent).error ?? event));
  globalThis.addEventListener("unhandledrejection", (event) =>
    record((event as PromiseRejectionEvent).reason),
  );
}

export function consumeLastCapturedError(): unknown {
  if (!lastCapturedError) return undefined;
  if (Date.now() - lastCapturedError.at > TTL_MS) {
    lastCapturedError = undefined;
    return undefined;
  }
  const { error } = lastCapturedError;
  lastCapturedError = undefined;
  return error;
}

```

## FILE 77: src/lib/error-page.ts

```ts
export function renderErrorPage(): string {
  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>This page didn't load</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
      body { font: 15px/1.5 system-ui, -apple-system, sans-serif; background: #fafafa; color: #111; display: grid; place-items: center; min-height: 100vh; margin: 0; padding: 1.5rem; }
      .card { max-width: 28rem; width: 100%; text-align: center; padding: 2rem; }
      h1 { font-size: 1.25rem; margin: 0 0 0.5rem; }
      p { color: #4b5563; margin: 0 0 1.5rem; }
      .actions { display: flex; gap: 0.5rem; justify-content: center; flex-wrap: wrap; }
      a, button { padding: 0.5rem 1rem; border-radius: 0.375rem; font: inherit; cursor: pointer; text-decoration: none; border: 1px solid transparent; }
      .primary { background: #111; color: #fff; }
      .secondary { background: #fff; color: #111; border-color: #d1d5db; }
    </style>
  </head>
  <body>
    <div class="card">
      <h1>This page didn't load</h1>
      <p>Something went wrong on our end. You can try refreshing or head back home.</p>
      <div class="actions">
        <button class="primary" onclick="location.reload()">Try again</button>
        <a class="secondary" href="/">Go home</a>
      </div>
    </div>
  </body>
</html>`;
}

```

## FILE 78: src/lib/lovable-error-reporting.ts

```ts
type LovableErrorOptions = {
  mechanism?: "manual" | "onerror" | "unhandledrejection" | "react_error_boundary";
  handled?: boolean;
  severity?: "error" | "warning" | "info";
};

type LovableEvents = {
  captureException?: (
    error: unknown,
    context?: Record<string, unknown>,
    options?: LovableErrorOptions,
  ) => void;
};

declare global {
  interface Window {
    __lovableEvents?: LovableEvents;
    __lovableReportRuntimeError?: (payload: {
      message: string;
      stack?: string;
      filename?: string;
    }) => void;
  }
}

export function reportLovableError(error: unknown, context: Record<string, unknown> = {}) {
  if (typeof window === "undefined") return;
  window.__lovableEvents?.captureException?.(
    error,
    {
      source: "react_error_boundary",
      route: window.location.pathname,
      ...context,
    },
    {
      mechanism: "react_error_boundary",
      handled: false,
      severity: "error",
    },
  );
  // Prod React does not rethrow boundary-caught errors to window.onerror, so the
  // editor's telemetry never sees them. Forward to lovable.js's reporting hook,
  // which is present only inside the editor preview.
  // Loaders and server fns commonly throw a raw Response; String(it) is the
  // opaque "[object Response]", so pull out the status and URL instead.
  const message =
    error instanceof Response
      ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}`
      : error instanceof Error
        ? error.message
        : String(error);
  const stack = error instanceof Error ? error.stack : undefined;
  window.__lovableReportRuntimeError?.({
    message,
    ...(stack !== undefined && { stack }),
    filename: window.location.pathname,
  });
}

```

## FILE 79: src/routeTree.gen.ts

```ts
/* eslint-disable */

// @ts-nocheck

// noinspection JSUnusedGlobalSymbols

// This file was automatically generated by TanStack Router.
// You should NOT make any changes in this file as it will be overwritten.
// Additionally, you should also exclude this file from your linter and/or formatter to prevent it from being checked or modified.

import { Route as rootRouteImport } from './routes/__root'
import { Route as IndexRouteImport } from './routes/index'
import { Route as AppRouteImport } from './routes/app'
import { Route as LoginRouteImport } from './routes/login'
import { Route as AppIndexRouteImport } from './routes/app.index'
import { Route as AppAnalyticsRouteImport } from './routes/app.analytics'
import { Route as AppConsentRouteImport } from './routes/app.consent'
import { Route as AppDashboardRouteImport } from './routes/app.dashboard'
import { Route as AppEmployersRouteImport } from './routes/app.employers'
import { Route as AppFollowupsRouteImport } from './routes/app.followups'
import { Route as AppOutcomesRouteImport } from './routes/app.outcomes'
import { Route as AppProgramsRouteImport } from './routes/app.programs'
import { Route as AppProvidersRouteImport } from './routes/app.providers'
import { Route as AppReportsRouteImport } from './routes/app.reports'
import { Route as AppSettingsRouteImport } from './routes/app.settings'
import { Route as AppSkillGapsRouteImport } from './routes/app.skill-gaps'
import { Route as AppTraineesIndexRouteImport } from './routes/app.trainees.index'
import { Route as AppTraineesTraineeIdRouteImport } from './routes/app.trainees.$traineeId'

const IndexRoute = IndexRouteImport.update({
  id: '/',
  path: '/',
  getParentRoute: () => rootRouteImport,
} as any)
const AppRoute = AppRouteImport.update({
  id: '/app',
  path: '/app',
  getParentRoute: () => rootRouteImport,
} as any)
const LoginRoute = LoginRouteImport.update({
  id: '/login',
  path: '/login',
  getParentRoute: () => rootRouteImport,
} as any)
const AppIndexRoute = AppIndexRouteImport.update({
  id: '/',
  path: '/',
  getParentRoute: () => AppRoute,
} as any)
const AppAnalyticsRoute = AppAnalyticsRouteImport.update({
  id: '/analytics',
  path: '/analytics',
  getParentRoute: () => AppRoute,
} as any)
const AppConsentRoute = AppConsentRouteImport.update({
  id: '/consent',
  path: '/consent',
  getParentRoute: () => AppRoute,
} as any)
const AppDashboardRoute = AppDashboardRouteImport.update({
  id: '/dashboard',
  path: '/dashboard',
  getParentRoute: () => AppRoute,
} as any)
const AppEmployersRoute = AppEmployersRouteImport.update({
  id: '/employers',
  path: '/employers',
  getParentRoute: () => AppRoute,
} as any)
const AppFollowupsRoute = AppFollowupsRouteImport.update({
  id: '/followups',
  path: '/followups',
  getParentRoute: () => AppRoute,
} as any)
const AppOutcomesRoute = AppOutcomesRouteImport.update({
  id: '/outcomes',
  path: '/outcomes',
  getParentRoute: () => AppRoute,
} as any)
const AppProgramsRoute = AppProgramsRouteImport.update({
  id: '/programs',
  path: '/programs',
  getParentRoute: () => AppRoute,
} as any)
const AppProvidersRoute = AppProvidersRouteImport.update({
  id: '/providers',
  path: '/providers',
  getParentRoute: () => AppRoute,
} as any)
const AppReportsRoute = AppReportsRouteImport.update({
  id: '/reports',
  path: '/reports',
  getParentRoute: () => AppRoute,
} as any)
const AppSettingsRoute = AppSettingsRouteImport.update({
  id: '/settings',
  path: '/settings',
  getParentRoute: () => AppRoute,
} as any)
const AppSkillGapsRoute = AppSkillGapsRouteImport.update({
  id: '/skill-gaps',
  path: '/skill-gaps',
  getParentRoute: () => AppRoute,
} as any)
const AppTraineesIndexRoute = AppTraineesIndexRouteImport.update({
  id: '/trainees/',
  path: '/trainees/',
  getParentRoute: () => AppRoute,
} as any)
const AppTraineesTraineeIdRoute = AppTraineesTraineeIdRouteImport.update({
  id: '/trainees/$traineeId',
  path: '/trainees/$traineeId',
  getParentRoute: () => AppRoute,
} as any)

export interface FileRoutesByFullPath {
  '/': typeof IndexRoute
  '/app': typeof AppRouteWithChildren
  '/login': typeof LoginRoute
  '/app/analytics': typeof AppAnalyticsRoute
  '/app/consent': typeof AppConsentRoute
  '/app/dashboard': typeof AppDashboardRoute
  '/app/employers': typeof AppEmployersRoute
  '/app/followups': typeof AppFollowupsRoute
  '/app/outcomes': typeof AppOutcomesRoute
  '/app/programs': typeof AppProgramsRoute
  '/app/providers': typeof AppProvidersRoute
  '/app/reports': typeof AppReportsRoute
  '/app/settings': typeof AppSettingsRoute
  '/app/skill-gaps': typeof AppSkillGapsRoute
  '/app/': typeof AppIndexRoute
  '/app/trainees/$traineeId': typeof AppTraineesTraineeIdRoute
  '/app/trainees/': typeof AppTraineesIndexRoute
}
export interface FileRoutesByTo {
  '/': typeof IndexRoute
  '/login': typeof LoginRoute
  '/app/analytics': typeof AppAnalyticsRoute
  '/app/consent': typeof AppConsentRoute
  '/app/dashboard': typeof AppDashboardRoute
  '/app/employers': typeof AppEmployersRoute
  '/app/followups': typeof AppFollowupsRoute
  '/app/outcomes': typeof AppOutcomesRoute
  '/app/programs': typeof AppProgramsRoute
  '/app/providers': typeof AppProvidersRoute
  '/app/reports': typeof AppReportsRoute
  '/app/settings': typeof AppSettingsRoute
  '/app/skill-gaps': typeof AppSkillGapsRoute
  '/app': typeof AppIndexRoute
  '/app/trainees/$traineeId': typeof AppTraineesTraineeIdRoute
  '/app/trainees': typeof AppTraineesIndexRoute
}
export interface FileRoutesById {
  __root__: typeof rootRouteImport
  '/': typeof IndexRoute
  '/app': typeof AppRouteWithChildren
  '/login': typeof LoginRoute
  '/app/analytics': typeof AppAnalyticsRoute
  '/app/consent': typeof AppConsentRoute
  '/app/dashboard': typeof AppDashboardRoute
  '/app/employers': typeof AppEmployersRoute
  '/app/followups': typeof AppFollowupsRoute
  '/app/outcomes': typeof AppOutcomesRoute
  '/app/programs': typeof AppProgramsRoute
  '/app/providers': typeof AppProvidersRoute
  '/app/reports': typeof AppReportsRoute
  '/app/settings': typeof AppSettingsRoute
  '/app/skill-gaps': typeof AppSkillGapsRoute
  '/app/': typeof AppIndexRoute
  '/app/trainees/$traineeId': typeof AppTraineesTraineeIdRoute
  '/app/trainees/': typeof AppTraineesIndexRoute
}
export interface FileRouteTypes {
  fileRoutesByFullPath: FileRoutesByFullPath
  fullPaths:
    | '/'
    | '/app'
    | '/login'
    | '/app/analytics'
    | '/app/consent'
    | '/app/dashboard'
    | '/app/employers'
    | '/app/followups'
    | '/app/outcomes'
    | '/app/programs'
    | '/app/providers'
    | '/app/reports'
    | '/app/settings'
    | '/app/skill-gaps'
    | '/app/'
    | '/app/trainees/$traineeId'
    | '/app/trainees/'
  fileRoutesByTo: FileRoutesByTo
  to:
    | '/'
    | '/login'
    | '/app/analytics'
    | '/app/consent'
    | '/app/dashboard'
    | '/app/employers'
    | '/app/followups'
    | '/app/outcomes'
    | '/app/programs'
    | '/app/providers'
    | '/app/reports'
    | '/app/settings'
    | '/app/skill-gaps'
    | '/app'
    | '/app/trainees/$traineeId'
    | '/app/trainees'
  id:
    | '__root__'
    | '/'
    | '/app'
    | '/login'
    | '/app/analytics'
    | '/app/consent'
    | '/app/dashboard'
    | '/app/employers'
    | '/app/followups'
    | '/app/outcomes'
    | '/app/programs'
    | '/app/providers'
    | '/app/reports'
    | '/app/settings'
    | '/app/skill-gaps'
    | '/app/'
    | '/app/trainees/$traineeId'
    | '/app/trainees/'
  fileRoutesById: FileRoutesById
}
export interface RootRouteChildren {
  IndexRoute: typeof IndexRoute
  AppRoute: typeof AppRouteWithChildren
  LoginRoute: typeof LoginRoute
}

declare module '@tanstack/react-router' {
  interface FileRoutesByPath {
    '/': {
      id: '/'
      path: '/'
      fullPath: '/'
      preLoaderRoute: typeof IndexRouteImport
      parentRoute: typeof rootRouteImport
    }
    '/app': {
      id: '/app'
      path: '/app'
      fullPath: '/app'
      preLoaderRoute: typeof AppRouteImport
      parentRoute: typeof rootRouteImport
    }
    '/login': {
      id: '/login'
      path: '/login'
      fullPath: '/login'
      preLoaderRoute: typeof LoginRouteImport
      parentRoute: typeof rootRouteImport
    }
    '/app/': {
      id: '/app/'
      path: '/'
      fullPath: '/app/'
      preLoaderRoute: typeof AppIndexRouteImport
      parentRoute: typeof AppRoute
    }
    '/app/analytics': {
      id: '/app/analytics'
      path: '/analytics'
      fullPath: '/app/analytics'
      preLoaderRoute: typeof AppAnalyticsRouteImport
      parentRoute: typeof AppRoute
    }
    '/app/consent': {
      id: '/app/consent'
      path: '/consent'
      fullPath: '/app/consent'
      preLoaderRoute: typeof AppConsentRouteImport
      parentRoute: typeof AppRoute
    }
    '/app/dashboard': {
      id: '/app/dashboard'
      path: '/dashboard'
      fullPath: '/app/dashboard'
      preLoaderRoute: typeof AppDashboardRouteImport
      parentRoute: typeof AppRoute
    }
    '/app/employers': {
      id: '/app/employers'
      path: '/employers'
      fullPath: '/app/employers'
      preLoaderRoute: typeof AppEmployersRouteImport
      parentRoute: typeof AppRoute
    }
    '/app/followups': {
      id: '/app/followups'
      path: '/followups'
      fullPath: '/app/followups'
      preLoaderRoute: typeof AppFollowupsRouteImport
      parentRoute: typeof AppRoute
    }
    '/app/outcomes': {
      id: '/app/outcomes'
      path: '/outcomes'
      fullPath: '/app/outcomes'
      preLoaderRoute: typeof AppOutcomesRouteImport
      parentRoute: typeof AppRoute
    }
    '/app/programs': {
      id: '/app/programs'
      path: '/programs'
      fullPath: '/app/programs'
      preLoaderRoute: typeof AppProgramsRouteImport
      parentRoute: typeof AppRoute
    }
    '/app/providers': {
      id: '/app/providers'
      path: '/providers'
      fullPath: '/app/providers'
      preLoaderRoute: typeof AppProvidersRouteImport
      parentRoute: typeof AppRoute
    }
    '/app/reports': {
      id: '/app/reports'
      path: '/reports'
      fullPath: '/app/reports'
      preLoaderRoute: typeof AppReportsRouteImport
      parentRoute: typeof AppRoute
    }
    '/app/settings': {
      id: '/app/settings'
      path: '/settings'
      fullPath: '/app/settings'
      preLoaderRoute: typeof AppSettingsRouteImport
      parentRoute: typeof AppRoute
    }
    '/app/skill-gaps': {
      id: '/app/skill-gaps'
      path: '/skill-gaps'
      fullPath: '/app/skill-gaps'
      preLoaderRoute: typeof AppSkillGapsRouteImport
      parentRoute: typeof AppRoute
    }
    '/app/trainees/': {
      id: '/app/trainees/'
      path: '/trainees'
      fullPath: '/app/trainees/'
      preLoaderRoute: typeof AppTraineesIndexRouteImport
      parentRoute: typeof AppRoute
    }
    '/app/trainees/$traineeId': {
      id: '/app/trainees/$traineeId'
      path: '/trainees/$traineeId'
      fullPath: '/app/trainees/$traineeId'
      preLoaderRoute: typeof AppTraineesTraineeIdRouteImport
      parentRoute: typeof AppRoute
    }
  }
}

interface AppRouteChildren {
  AppAnalyticsRoute: typeof AppAnalyticsRoute
  AppConsentRoute: typeof AppConsentRoute
  AppDashboardRoute: typeof AppDashboardRoute
  AppEmployersRoute: typeof AppEmployersRoute
  AppFollowupsRoute: typeof AppFollowupsRoute
  AppOutcomesRoute: typeof AppOutcomesRoute
  AppProgramsRoute: typeof AppProgramsRoute
  AppProvidersRoute: typeof AppProvidersRoute
  AppReportsRoute: typeof AppReportsRoute
  AppSettingsRoute: typeof AppSettingsRoute
  AppSkillGapsRoute: typeof AppSkillGapsRoute
  AppIndexRoute: typeof AppIndexRoute
  AppTraineesTraineeIdRoute: typeof AppTraineesTraineeIdRoute
  AppTraineesIndexRoute: typeof AppTraineesIndexRoute
}

const AppRouteChildren: AppRouteChildren = {
  AppAnalyticsRoute: AppAnalyticsRoute,
  AppConsentRoute: AppConsentRoute,
  AppDashboardRoute: AppDashboardRoute,
  AppEmployersRoute: AppEmployersRoute,
  AppFollowupsRoute: AppFollowupsRoute,
  AppOutcomesRoute: AppOutcomesRoute,
  AppProgramsRoute: AppProgramsRoute,
  AppProvidersRoute: AppProvidersRoute,
  AppReportsRoute: AppReportsRoute,
  AppSettingsRoute: AppSettingsRoute,
  AppSkillGapsRoute: AppSkillGapsRoute,
  AppIndexRoute: AppIndexRoute,
  AppTraineesTraineeIdRoute: AppTraineesTraineeIdRoute,
  AppTraineesIndexRoute: AppTraineesIndexRoute,
}

const AppRouteWithChildren = AppRoute._addFileChildren(AppRouteChildren)

const rootRouteChildren: RootRouteChildren = {
  IndexRoute: IndexRoute,
  AppRoute: AppRouteWithChildren,
  LoginRoute: LoginRoute,
}
export const routeTree = rootRouteImport
  ._addFileChildren(rootRouteChildren)
  ._addFileTypes<FileRouteTypes>()

import type { getRouter } from './router.tsx'
import type { startInstance } from './start.ts'
declare module '@tanstack/react-start' {
  interface Register {
    ssr: true
    router: Awaited<ReturnType<typeof getRouter>>
    config: Awaited<ReturnType<typeof startInstance.getOptions>>
  }
}

```

## FILE 80: src/router.tsx

```tsx
import { QueryClient } from "@tanstack/react-query";
import { createRouter } from "@tanstack/react-router";
import { routeTree } from "./routeTree.gen";

export const getRouter = () => {
  const queryClient = new QueryClient();

  const router = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0,
  });

  return router;
};

```

## FILE 81: src/routes/README.md

```md
# Routes

TanStack Start uses **file-based routing**. Every `.tsx` file in this directory
defines a route. Do **not** create `src/pages/`, `src/routes/_app/index.tsx`, or
`app/layout.tsx` — those are Next.js / Remix conventions. The only root layout
is `src/routes/__root.tsx`.

## Conventions

| File | URL |
| --- | --- |
| `index.tsx` | `/` |
| `about.tsx` | `/about` |
| `users/index.tsx` | `/users` |
| `users/$id.tsx` | `/users/:id` (dynamic — bare `$`, no curly braces) |
| `posts/{-$category}.tsx` | `/posts/:category?` (optional segment) |
| `files/$.tsx` | `/files/*` (splat — read via `_splat` param, never `*`) |
| `_layout.tsx` | layout route (renders children via `<Outlet />`) |
| `__root.tsx` | app shell — wraps every page; preserve `<Outlet />` |

`routeTree.gen.ts` is auto-generated. Don't edit it by hand.

```

## FILE 82: src/routes/__root.tsx

```tsx
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { AuthProvider } from "../auth/auth-context";
import { StoreProvider } from "../services/store";
import { Toaster } from "../components/ui/sonner";
import { reportLovableError } from "../lib/lovable-error-reporting";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "MahaSkillTrack — Maharashtra Skill Outcome Intelligence" },
      { name: "description", content: "Track skill-development outcomes across Maharashtra from training to employment." },
      { name: "author", content: "Maharashtra State Skill Development Mission (prototype)" },
      { property: "og:title", content: "MahaSkillTrack" },
      { property: "og:description", content: "From Training to Employment — Measuring What Really Matters." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:site", content: "@Lovable" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <StoreProvider>
          {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
          <Outlet />
          <Toaster richColors position="top-right" />
        </StoreProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

```

## FILE 83: src/routes/app.analytics.tsx

```tsx
import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";

import { ChartCard } from "@/components/common/chart-card";
import { FilterBar } from "@/components/common/filter-bar";
import { PageHeader } from "@/components/common/page-header";
import { EmptyState } from "@/components/common/states";
import { CourseComparisonBars, DistrictBars, ReasonBars, RetentionLine, SalaryLine } from "@/components/charts/dashboard-charts";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useScope } from "@/hooks/use-scope";
import { EMPTY_FILTERS, applyFilters, courseStats, districtStats, formatINR, nonPlacementReasons, retentionTrend, salaryProgressionAvg } from "@/services/analytics";
import type { Filters } from "@/types";

export const Route = createFileRoute("/app/analytics")({
  head: () => ({
    meta: [
      { title: "Analytics — MahaSkillTrack" },
      { name: "description", content: "Cross-cutting analytics on districts, courses, retention, salary growth and non-placement reasons." },
      { property: "og:title", content: "Outcome Analytics — MahaSkillTrack" },
      { property: "og:description", content: "Aggregated analytics for Maharashtra skill training outcomes." },
    ],
  }),
  component: AnalyticsPage,
});

function AnalyticsPage() {
  const scope = useScope();
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);
  const rows = useMemo(() => applyFilters(scope.trainees, filters), [scope.trainees, filters]);
  const districts = useMemo(() => districtStats(rows), [rows]);
  const courses = useMemo(() => courseStats(rows), [rows]);
  const salary = useMemo(() => salaryProgressionAvg(rows).filter((p) => p.salary > 0), [rows]);
  const reasons = useMemo(() => nonPlacementReasons(rows), [rows]);

  return (
    <div className="space-y-6">
      <PageHeader title="Analytics" description={`Aggregated, privacy-safe analysis across ${rows.length} trainee records.`} />
      <FilterBar filters={filters} onChange={setFilters} hideProvider={scope.role === "provider"} />
      {rows.length === 0 ? (
        <EmptyState title="No data for these filters" description="Widen the filters to run the analysis." />
      ) : (
        <>
          <div className="grid gap-5 lg:grid-cols-2">
            <ChartCard title="District employment rate" description="Placement performance by district">
              <DistrictBars data={districts} />
            </ChartCard>
            <ChartCard title="Retention by milestone" description="Share still employed at 3, 6 and 12 months">
              <RetentionLine data={retentionTrend(rows)} />
            </ChartCard>
            <ChartCard title="Course placement vs retention" description="Sustained outcomes by program">
              <CourseComparisonBars data={courses.map((c) => ({ course: c.course, placementRate: c.placementRate, retention12: c.retention12 }))} />
            </ChartCard>
            <ChartCard title="Average salary progression" description="Income growth from joining to 12 months">
              {salary.length ? <SalaryLine data={salary} /> : <EmptyState title="No salary data" description="No placements recorded in this scope." />}
            </ChartCard>
          </div>
          <ChartCard title="Non-placement reasons" description="Where the pipeline breaks down">
            {reasons.length ? <ReasonBars data={reasons} /> : <EmptyState title="No reason codes" description="All trainees in this scope are placed." />}
          </ChartCard>
          <Card>
            <CardContent className="overflow-x-auto p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>District</TableHead>
                    <TableHead>Trainees</TableHead>
                    <TableHead>Employment</TableHead>
                    <TableHead>Retention 6m</TableHead>
                    <TableHead className="text-right">Avg salary</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {districts.map((d) => (
                    <TableRow key={d.district}>
                      <TableCell className="font-medium">{d.district}</TableCell>
                      <TableCell>{d.trainees}</TableCell>
                      <TableCell>{d.employmentRate}%</TableCell>
                      <TableCell>{d.retention}%</TableCell>
                      <TableCell className="text-right">{formatINR(d.avgSalary)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

```

## FILE 84: src/routes/app.consent.tsx

```tsx
import { createFileRoute } from "@tanstack/react-router";
import { ShieldCheck } from "lucide-react";

import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useScope } from "@/hooks/use-scope";
import { pct } from "@/services/analytics";

export const Route = createFileRoute("/app/consent")({
  head: () => ({
    meta: [
      { title: "Consent & privacy — MahaSkillTrack" },
      { name: "description", content: "Consent status, data-sharing preferences and the privacy safeguards applied to outcome tracking." },
      { property: "og:title", content: "Consent & Privacy — MahaSkillTrack" },
      { property: "og:description", content: "How trainee consent governs data sharing and analytics." },
    ],
  }),
  component: ConsentPage,
});

function ConsentPage() {
  const { trainees, self, role } = useScope();
  const granted = trainees.filter((t) => t.consent === "Granted").length;
  const partial = trainees.filter((t) => t.consent === "Partial").length;
  const withdrawn = trainees.filter((t) => t.consent === "Withdrawn").length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Consent and privacy"
        description="Outcome tracking runs only on the data trainees have agreed to share."
      />
      {role === "trainee" && self ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">My consent preferences</CardTitle>
            <CardDescription>Recorded {self.consentDate}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Overall consent</span>
              <StatusBadge status={self.consent} />
            </div>
            {[
              ["Share anonymised data for analytics", self.dataSharing.analytics],
              ["Share profile with verified employers", self.dataSharing.employers],
              ["Share anonymised data for research", self.dataSharing.research],
            ].map(([label, value]) => (
              <div key={String(label)} className="flex items-center justify-between border-t border-border/60 pt-2">
                <span className="text-muted-foreground">{label}</span>
                <StatusBadge status={value ? "Granted" : "Withdrawn"} />
              </div>
            ))}
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-3">
          <StatCard label="Full consent" value={`${pct(granted, trainees.length)}%`} description={`${granted} trainees`} icon={ShieldCheck} accent="success" />
          <StatCard label="Partial consent" value={`${pct(partial, trainees.length)}%`} description={`${partial} trainees limit sharing`} icon={ShieldCheck} accent="saffron" />
          <StatCard label="Withdrawn" value={`${pct(withdrawn, trainees.length)}%`} description={`${withdrawn} excluded from sharing`} icon={ShieldCheck} />
        </div>
      )}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Privacy safeguards in this platform</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>· All trainee names, IDs and employers in this demo are synthetic — no real personal data is used.</p>
          <p>· Analytics and report screens show aggregated figures only; contact details are never exported.</p>
          <p>· Employers see only trainees they employ; providers see only their own cohorts.</p>
          <p>· Consent status is stored with each record and can be withdrawn at any time.</p>
        </CardContent>
      </Card>
    </div>
  );
}

```

## FILE 85: src/routes/app.dashboard.tsx

```tsx
import { Link, createFileRoute } from "@tanstack/react-router";
import {
  ArrowRight,
  Award,
  Briefcase,
  ClipboardList,
  Download,
  GraduationCap,
  IndianRupee,
  Lightbulb,
  ShieldCheck,
  TrendingUp,
  Users,
} from "lucide-react";
import { useMemo, useState } from "react";

import { ROLE_LABEL, useAuth } from "@/auth/auth-context";
import { ChartCard } from "@/components/common/chart-card";
import { FilterBar } from "@/components/common/filter-bar";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/states";
import { StatusBadge } from "@/components/common/status-badge";
import { Timeline } from "@/components/common/timeline";
import {
  DistrictBars,
  OutcomeDonut,
  RetentionLine,
  SalaryLine,
} from "@/components/charts/dashboard-charts";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { useScope } from "@/hooks/use-scope";
import {
  EMPTY_FILTERS,
  applyFilters,
  districtStats,
  formatINR,
  kpis,
  outcomeBreakdown,
  pendingFollowUps,
  retentionTrend,
  salaryProgressionAvg,
  skillInsights,
} from "@/services/analytics";
import { useStore } from "@/services/store";
import { downloadCsv } from "@/utils/export";
import type { Filters } from "@/types";

export const Route = createFileRoute("/app/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — MahaSkillTrack" },
      {
        name: "description",
        content:
          "Live outcome dashboard: placement, retention, salary growth and follow-up progress across Maharashtra skill programs.",
      },
      { property: "og:title", content: "Outcome Dashboard — MahaSkillTrack" },
      {
        property: "og:description",
        content: "Role-based KPIs and charts for Maharashtra skill training outcomes.",
      },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  const { user } = useAuth();
  const scope = useScope();
  const { courseName, providerName } = useStore();
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);

  const rows = useMemo(() => applyFilters(scope.trainees, filters), [scope.trainees, filters]);
  const k = useMemo(() => kpis(rows), [rows]);
  const outcomes = useMemo(() => outcomeBreakdown(rows).filter((o) => o.value > 0), [rows]);
  const districts = useMemo(() => districtStats(rows), [rows]);
  const retention = useMemo(() => retentionTrend(rows), [rows]);
  const salary = useMemo(() => salaryProgressionAvg(rows).filter((p) => p.salary > 0), [rows]);
  const insight = useMemo(() => skillInsights(), []);
  const followUps = useMemo(
    () => pendingFollowUps(rows).filter((f) => f.followUp.status !== "Completed").slice(0, 5),
    [rows],
  );

  if (scope.role === "trainee") return <TraineeDashboard />;

  return (
    <div className="space-y-6">
      <PageHeader
        title={`Welcome, ${user?.name?.split(" ")[0] ?? "Officer"}`}
        description={`${ROLE_LABEL[scope.role]} · ${scope.scopeLabel} · ${rows.length} trainee records in view.`}
        actions={
          <>
            <Button variant="outline" asChild>
              <Link to="/app/reports">
                <Download className="mr-2 size-4" aria-hidden />
                Reports
              </Link>
            </Button>
            <Button asChild>
              <Link to="/app/outcomes">
                Record outcome
                <ArrowRight className="ml-2 size-4" aria-hidden />
              </Link>
            </Button>
          </>
        }
      />

      <FilterBar filters={filters} onChange={setFilters} hideProvider={scope.role === "provider"} />

      {rows.length === 0 ? (
        <EmptyState
          title="No trainees match these filters"
          description="Try widening the district, course or outcome filters to see results."
          action={
            <Button variant="outline" onClick={() => setFilters(EMPTY_FILTERS)}>
              Reset filters
            </Button>
          }
        />

      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard
              label="Total trainees"
              value={k.total.toLocaleString("en-IN")}
              description="Enrolled in the selected scope"
              icon={Users}
              change={6}
            />
            <StatCard
              label="Training completion"
              value={`${k.completionRate}%`}
              description={`${k.completed} completed · ${k.certified} certified`}
              icon={GraduationCap}
              accent="info"
              change={4}
            />
            <StatCard
              label="Employment rate"
              value={`${k.employmentRate}%`}
              description={`Employed ${k.employedRate}% · self-employed ${k.selfRate}%`}
              icon={Briefcase}
              accent="success"
              change={9}
            />
            <StatCard
              label="Average salary"
              value={formatINR(k.avgSalary)}
              description={`12-month retention ${k.retention12}%`}
              icon={IndianRupee}
              accent="saffron"
              change={12}
            />
          </div>

          <div className="grid gap-5 lg:grid-cols-2">
            <ChartCard
              title="Employment outcome distribution"
              description="Where trainees are today across all outcome categories"
            >
              <OutcomeDonut data={outcomes} />
            </ChartCard>
            <ChartCard
              title="District-wise employment rate"
              description="Placement performance by district"
              action={
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() =>
                    downloadCsv(
                      "district-employment",
                      districts.map((d) => ({
                        District: d.district,
                        Trainees: d.trainees,
                        "Employment rate %": d.employmentRate,
                        "Average salary": d.avgSalary,
                      })),
                    )
                  }
                >
                  <Download className="mr-1.5 size-4" aria-hidden />
                  CSV
                </Button>
              }
            >
              <DistrictBars data={districts} />
            </ChartCard>
            <ChartCard
              title="Retention over time"
              description="Share still employed at each follow-up milestone"
            >
              <RetentionLine data={retention} />
            </ChartCard>
            <ChartCard
              title="Average salary progression"
              description="Monthly income growth from joining to 12 months"
            >
              {salary.length ? (
                <SalaryLine data={salary} />
              ) : (
                <EmptyState
                  title="No salary data yet"
                  description="Salary progression appears once placements and follow-ups are recorded."
                />
              )}
            </ChartCard>
          </div>

          <div className="grid gap-5 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader className="flex flex-row items-start justify-between gap-3">
                <div>
                  <CardTitle className="text-base">Follow-ups needing attention</CardTitle>
                  <CardDescription>Due and pending milestone check-ins</CardDescription>
                </div>
                <Button variant="ghost" size="sm" asChild>
                  <Link to="/app/followups">
                    View all
                    <ArrowRight className="ml-1.5 size-4" aria-hidden />
                  </Link>
                </Button>
              </CardHeader>
              <CardContent className="space-y-2">
                {followUps.length ? (
                  followUps.map((f) => (
                    <Link
                      key={`${f.traineeId}-${f.followUp.id}`}
                      to="/app/trainees/$traineeId"
                      params={{ traineeId: f.traineeId }}
                      className="flex items-center justify-between gap-3 rounded-lg border border-border px-3 py-2.5 transition-colors hover:border-primary/40 hover:bg-muted/50"
                    >
                      <span className="min-w-0">
                        <span className="block truncate text-sm font-medium">{f.traineeName}</span>
                        <span className="block truncate text-xs text-muted-foreground">
                          {courseName(f.courseId)} · {f.district} · {f.followUp.milestone} · due{" "}
                          {f.followUp.dueDate}
                        </span>
                      </span>
                      <StatusBadge status={f.followUp.status} />
                    </Link>
                  ))
                ) : (
                  <EmptyState
                    title="All follow-ups are complete"
                    description="No pending milestone check-ins in this scope."
                  />
                )}
              </CardContent>
            </Card>

            <Card className="border-accent/40 bg-accent/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Lightbulb className="size-4 text-accent-foreground" aria-hidden />
                  Insight of the day
                </CardTitle>
                <CardDescription>Rule-based recommendation engine</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <p>{insight.insight}</p>
                <Separator />
                <p className="font-medium">Recommended action</p>
                <p className="text-muted-foreground">{insight.action}</p>
                <Button variant="outline" size="sm" asChild className="w-full">
                  <Link to="/app/skill-gaps">
                    Open skill-gap analysis
                    <ArrowRight className="ml-1.5 size-4" aria-hidden />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>

          {scope.isAdmin ? (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Top districts by employment rate</CardTitle>
                <CardDescription>Ranked on placements within the current filters</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {[...districts]
                  .sort((a, b) => b.employmentRate - a.employmentRate)
                  .slice(0, 5)
                  .map((d) => (
                    <div key={d.district} className="space-y-1.5">
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-medium">{d.district}</span>
                        <span className="text-muted-foreground">
                          {d.employmentRate}% · {formatINR(d.avgSalary)} avg
                        </span>
                      </div>
                      <Progress value={d.employmentRate} />
                    </div>
                  ))}
              </CardContent>
            </Card>
          ) : null}

          <p className="flex items-center gap-2 text-xs text-muted-foreground">
            <ShieldCheck className="size-3.5" aria-hidden />
            Aggregated view · personal contact details are hidden from analytics screens.
          </p>
        </>
      )}
    </div>
  );
}

function TraineeDashboard() {
  const { self } = useScope();
  const { courseName, providerName } = useStore();

  if (!self) {
    return (
      <EmptyState
        title="No trainee record linked"
        description="This demo account is not linked to a trainee profile."
      />
    );
  }

  const nextFollowUp = self.followUps.find((f) => f.status !== "Completed");
  const latestSalary = self.salaryProgression.at(-1)?.salary ?? 0;
  const firstSalary = self.salaryProgression[0]?.salary ?? 0;
  const growth = firstSalary ? Math.round(((latestSalary - firstSalary) / firstSalary) * 100) : 0;

  return (
    <div className="space-y-6">
      <PageHeader
        title={`My journey · ${self.name}`}
        description={`${courseName(self.courseId)} at ${providerName(self.providerId)} · ${self.district} district`}
        actions={<StatusBadge status={self.employmentStatus} />}
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Training status"
          value={self.trainingStatus}
          description={`Attendance ${self.attendance}% · score ${self.assessmentScore}`}
          icon={GraduationCap}
        />
        <StatCard
          label="Certification"
          value={self.certified ? "Certified" : "Pending"}
          description={self.certified ? "Certificate issued by provider" : "Awaiting assessment"}
          icon={Award}
          accent="info"
        />
        <StatCard
          label="Current income"
          value={formatINR(latestSalary)}
          description={growth ? `${growth > 0 ? "+" : ""}${growth}% since joining` : "Not employed yet"}
          icon={IndianRupee}
          accent="saffron"
          {...(growth ? { change: growth } : {})}
        />
        <StatCard
          label="Next follow-up"
          value={nextFollowUp?.milestone ?? "Complete"}
          description={nextFollowUp ? `Due ${nextFollowUp.dueDate}` : "All milestones recorded"}
          icon={ClipboardList}
          accent="success"
        />
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">My career timeline</CardTitle>
            <CardDescription>Every recorded milestone in your journey</CardDescription>
          </CardHeader>
          <CardContent>
            <Timeline events={self.timeline} />
          </CardContent>
        </Card>
        <div className="space-y-5">
          <ChartCard title="My salary progression" description="Reported monthly income">
            {self.salaryProgression.length ? (
              <SalaryLine data={self.salaryProgression} height={240} />
            ) : (
              <EmptyState
                title="No income recorded"
                description="Your income appears here once employment is recorded."
              />
            )}
          </ChartCard>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Current employment</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <Row label="Employer" value={self.employment.employerName ?? "—"} />
              <Row label="Role" value={self.employment.jobTitle ?? "—"} />
              <Row label="Joined" value={self.employment.joiningDate ?? "—"} />
              <Row label="Location" value={self.employment.location ?? "—"} />
              <Row
                label="Verification"
                value={self.employment.verified ? "Verified by employer" : "Pending verification"}
              />
              <Button variant="outline" size="sm" asChild className="mt-2 w-full">
                <Link to="/app/consent">
                  <ShieldCheck className="mr-1.5 size-4" aria-hidden />
                  Manage my data consent
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <TrendingUp className="size-4 text-success" aria-hidden />
            My follow-up history
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {self.followUps.map((f) => (
            <div
              key={f.id}
              className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border px-3 py-2.5 text-sm"
            >
              <span>
                <span className="font-medium">{f.milestone}</span>
                <span className="ml-2 text-xs text-muted-foreground">
                  {f.status === "Completed" ? `Recorded ${f.completedDate}` : `Due ${f.dueDate}`}
                  {f.salary ? ` · ${formatINR(f.salary)}` : ""}
                </span>
              </span>
              <StatusBadge status={f.status} />
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-border/60 pb-1.5 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{value}</span>
    </div>
  );
}

```

## FILE 86: src/routes/app.employers.tsx

```tsx
import { createFileRoute } from "@tanstack/react-router";
import { Briefcase } from "lucide-react";

import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useScope } from "@/hooks/use-scope";
import { formatINR, salaryOf } from "@/services/analytics";
import { useStore } from "@/services/store";

export const Route = createFileRoute("/app/employers")({
  head: () => ({
    meta: [
      { title: "Employers — MahaSkillTrack" },
      { name: "description", content: "Partner employers, hiring volumes, verification status and skill requirements feedback." },
      { property: "og:title", content: "Employer Network — MahaSkillTrack" },
      { property: "og:description", content: "Employer hiring records and skill requirement feedback." },
    ],
  }),
  component: EmployersPage,
});

function EmployersPage() {
  const { employers, trainees } = useStore();
  const scope = useScope();
  const visible = scope.role === "employer" ? employers.filter((e) => scope.trainees.some((t) => t.employment.employerId === e.id)) : employers;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Employer network"
        description="Who is hiring skilled trainees, and what skills do they still find missing?"
      />
      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {visible.map((e) => {
          const hires = trainees.filter((t) => t.employment.employerId === e.id);
          const avg = hires.length
            ? Math.round(hires.reduce((a, t) => a + salaryOf(t), 0) / hires.length)
            : 0;
          return (
            <Card key={e.id}>
              <CardHeader className="flex flex-row items-start justify-between gap-3">
                <div>
                  <CardTitle className="text-base">{e.name}</CardTitle>
                  <CardDescription>
                    {e.sector} · {e.district}
                  </CardDescription>
                </div>
                <StatusBadge status={e.status} />
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <p className="flex items-center gap-2 text-muted-foreground">
                  <Briefcase className="size-4" aria-hidden />
                  {hires.length} trainees hired · {formatINR(avg)} average salary
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {e.skillRequirements.map((s) => (
                    <Badge key={s} variant="secondary">
                      {s}
                    </Badge>
                  ))}
                </div>
                <p className="rounded-lg bg-muted/60 p-3 text-xs text-muted-foreground">"{e.feedback}"</p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

```

## FILE 87: src/routes/app.followups.tsx

```tsx
import { Link, createFileRoute } from "@tanstack/react-router";
import { ClipboardList } from "lucide-react";
import { useMemo, useState } from "react";

import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/states";
import { StatusBadge } from "@/components/common/status-badge";
import { FollowUpDialog } from "@/components/forms/follow-up-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useScope } from "@/hooks/use-scope";
import { formatINR, pendingFollowUps } from "@/services/analytics";
import { useStore } from "@/services/store";

export const Route = createFileRoute("/app/followups")({
  head: () => ({
    meta: [
      { title: "Follow-ups — MahaSkillTrack" },
      { name: "description", content: "Manage 3, 6 and 12-month follow-up check-ins and record verified outcome updates." },
      { property: "og:title", content: "Follow-up Tracker — MahaSkillTrack" },
      { property: "og:description", content: "Milestone follow-up scheduling and recording." },
    ],
  }),
  component: FollowUpsPage,
});

function FollowUpsPage() {
  const scope = useScope();
  const { courseName, getTrainee } = useStore();
  const [tab, setTab] = useState("due");
  const [active, setActive] = useState<{ traineeId: string; followUpId: string } | null>(null);

  const all = useMemo(() => pendingFollowUps(scope.trainees), [scope.trainees]);
  const counts = {
    due: all.filter((f) => f.followUp.status === "Due").length,
    pending: all.filter((f) => f.followUp.status === "Pending").length,
    unreachable: all.filter((f) => f.followUp.status === "Unreachable").length,
    completed: all.filter((f) => f.followUp.status === "Completed").length,
  };
  const filtered = all.filter((f) =>
    tab === "due"
      ? f.followUp.status === "Due"
      : tab === "pending"
        ? f.followUp.status === "Pending"
        : tab === "unreachable"
          ? f.followUp.status === "Unreachable"
          : f.followUp.status === "Completed",
  );

  const trainee = active ? getTrainee(active.traineeId) : undefined;

  return (
    <div className="space-y-6">
      <PageHeader title="Follow-up tracker" description="Structured 3, 6 and 12-month check-ins keep outcome data honest." />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Due now" value={String(counts.due)} description="Milestones ready to record" icon={ClipboardList} accent="saffron" />
        <StatCard label="Upcoming" value={String(counts.pending)} description="Scheduled for later dates" icon={ClipboardList} accent="info" />
        <StatCard label="Unreachable" value={String(counts.unreachable)} description="Require alternate contact" icon={ClipboardList} />
        <StatCard label="Completed" value={String(counts.completed)} description="Verified check-ins on record" icon={ClipboardList} accent="success" />
      </div>
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex-wrap">
          <TabsTrigger value="due">Due ({counts.due})</TabsTrigger>
          <TabsTrigger value="pending">Upcoming ({counts.pending})</TabsTrigger>
          <TabsTrigger value="unreachable">Unreachable ({counts.unreachable})</TabsTrigger>
          <TabsTrigger value="completed">Completed ({counts.completed})</TabsTrigger>
        </TabsList>
      </Tabs>
      {filtered.length === 0 ? (
        <EmptyState icon={ClipboardList} title="Nothing in this queue" description="Switch tabs to review other follow-up states." />
      ) : (
        <Card>
          <CardContent className="space-y-2 p-4 sm:p-5">
            {filtered.slice(0, 30).map((f) => (
              <div key={`${f.traineeId}-${f.followUp.id}`} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-3">
                <div className="min-w-0">
                  <Link to="/app/trainees/$traineeId" params={{ traineeId: f.traineeId }} className="text-sm font-medium hover:underline">
                    {f.traineeName}
                  </Link>
                  <p className="text-xs text-muted-foreground">
                    {courseName(f.courseId)} · {f.district} · {f.followUp.milestone} · due {f.followUp.dueDate}
                    {f.followUp.salary ? ` · ${formatINR(f.followUp.salary)}` : ""}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status={f.followUp.status} />
                  {scope.canEdit ? (
                    <Button size="sm" variant="outline" onClick={() => setActive({ traineeId: f.traineeId, followUpId: f.followUp.id })}>
                      Record
                    </Button>
                  ) : null}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
      {trainee && active ? (
        <FollowUpDialog trainee={trainee} followUpId={active.followUpId} onClose={() => setActive(null)} />
      ) : null}
    </div>
  );
}

```

## FILE 88: src/routes/app.index.tsx

```tsx
import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/app/")({
  beforeLoad: () => {
    throw redirect({ to: "/app/dashboard" });
  },
});

```

## FILE 89: src/routes/app.outcomes.tsx

```tsx
import { createFileRoute } from "@tanstack/react-router";
import { Download, Search } from "lucide-react";
import { useMemo, useState } from "react";

import { ChartCard } from "@/components/common/chart-card";
import { FilterBar } from "@/components/common/filter-bar";
import { PageHeader } from "@/components/common/page-header";
import { EmptyState } from "@/components/common/states";
import { StatusBadge } from "@/components/common/status-badge";
import { OutcomeDonut, ReasonBars } from "@/components/charts/dashboard-charts";
import { OutcomeDialog } from "@/components/forms/outcome-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useScope } from "@/hooks/use-scope";
import { EMPTY_FILTERS, applyFilters, formatINR, nonPlacementReasons, outcomeBreakdown, salaryOf } from "@/services/analytics";
import { useStore } from "@/services/store";
import { downloadCsv } from "@/utils/export";
import type { Filters, Trainee } from "@/types";

export const Route = createFileRoute("/app/outcomes")({
  head: () => ({
    meta: [
      { title: "Employment outcomes — MahaSkillTrack" },
      { name: "description", content: "Record and review employment outcomes, self-employment and reasons for non-placement." },
      { property: "og:title", content: "Employment Outcomes — MahaSkillTrack" },
      { property: "og:description", content: "Outcome registry with reason-code analysis for unplaced trainees." },
    ],
  }),
  component: OutcomesPage,
});

function OutcomesPage() {
  const scope = useScope();
  const { courseName } = useStore();
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<Trainee | null>(null);

  const rows = useMemo(() => {
    const list = applyFilters(scope.trainees, filters);
    const q = query.trim().toLowerCase();
    return q ? list.filter((t) => t.name.toLowerCase().includes(q) || t.id.toLowerCase().includes(q)) : list;
  }, [scope.trainees, filters, query]);

  const donut = useMemo(() => outcomeBreakdown(rows).filter((o) => o.value > 0), [rows]);
  const reasons = useMemo(() => nonPlacementReasons(rows), [rows]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Employment outcome registry"
        description="Update outcomes, capture self-employment and record why trainees remain unplaced."
        actions={
          <Button
            variant="outline"
            onClick={() =>
              downloadCsv(
                "employment-outcomes",
                rows.map((t) => ({
                  "Trainee ID": t.id,
                  Name: t.name,
                  District: t.district,
                  Course: courseName(t.courseId),
                  Outcome: t.employmentStatus,
                  Employer: t.employment.employerName ?? "",
                  Income: salaryOf(t) || "",
                  "Reason not placed": t.nonPlacementReason ?? "",
                })),
              )
            }
          >
            <Download className="mr-2 size-4" aria-hidden />
            Export CSV
          </Button>
        }
      />
      <FilterBar filters={filters} onChange={setFilters} hideProvider={scope.role === "provider"} />
      <div className="grid gap-5 lg:grid-cols-2">
        <ChartCard title="Outcome mix" description="Distribution across all outcome categories">
          {donut.length ? <OutcomeDonut data={donut} /> : <EmptyState title="No outcomes" description="No records match these filters." />}
        </ChartCard>
        <ChartCard title="Why trainees are not placed" description="Reason codes captured during follow-ups">
          {reasons.length ? <ReasonBars data={reasons} /> : <EmptyState title="No reason codes" description="Every trainee in this scope is placed." />}
        </ChartCard>
      </div>
      <Card>
        <CardContent className="space-y-4 p-4 sm:p-5">
          <div className="relative max-w-sm">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
            <Input className="pl-9" aria-label="Search outcomes" placeholder="Search trainee name or ID" value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Trainee</TableHead>
                  <TableHead>Outcome</TableHead>
                  <TableHead className="hidden md:table-cell">Employer</TableHead>
                  <TableHead>Income</TableHead>
                  {scope.canEdit ? <TableHead className="text-right">Action</TableHead> : null}
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.slice(0, 25).map((t) => (
                  <TableRow key={t.id}>
                    <TableCell>
                      <span className="block font-medium">{t.name}</span>
                      <span className="block text-xs text-muted-foreground">
                        {t.id} · {courseName(t.courseId)} · {t.district}
                      </span>
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={t.employmentStatus} />
                    </TableCell>
                    <TableCell className="hidden text-sm md:table-cell">{t.employment.employerName ?? "—"}</TableCell>
                    <TableCell className="text-sm font-medium">{formatINR(salaryOf(t))}</TableCell>
                    {scope.canEdit ? (
                      <TableCell className="text-right">
                        <Button variant="outline" size="sm" onClick={() => setEditing(t)}>
                          Update
                        </Button>
                      </TableCell>
                    ) : null}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <p className="text-xs text-muted-foreground">Showing up to 25 records · refine filters to narrow the list.</p>
        </CardContent>
      </Card>
      {editing ? (
        <OutcomeDialog trainee={editing} open onOpenChange={(o) => (!o ? setEditing(null) : undefined)} />
      ) : null}
    </div>
  );
}

```

## FILE 90: src/routes/app.programs.tsx

```tsx
import { createFileRoute } from "@tanstack/react-router";
import { Download, GraduationCap } from "lucide-react";
import { useMemo, useState } from "react";

import { ChartCard } from "@/components/common/chart-card";
import { FilterBar } from "@/components/common/filter-bar";
import { PageHeader } from "@/components/common/page-header";
import { EmptyState } from "@/components/common/states";
import { CourseComparisonBars } from "@/components/charts/dashboard-charts";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useScope } from "@/hooks/use-scope";
import { EMPTY_FILTERS, applyFilters, courseStats, formatINR } from "@/services/analytics";
import { useStore } from "@/services/store";
import { downloadCsv } from "@/utils/export";
import type { Filters } from "@/types";

export const Route = createFileRoute("/app/programs")({
  head: () => ({
    meta: [
      { title: "Training programs — MahaSkillTrack" },
      {
        name: "description",
        content:
          "Compare skill-training programs on completion, certification, placement, retention and salary outcomes.",
      },
      { property: "og:title", content: "Program Effectiveness — MahaSkillTrack" },
      {
        property: "og:description",
        content: "Course-level outcome comparison for Maharashtra skill programs.",
      },
    ],
  }),
  component: ProgramsPage,
});

function ProgramsPage() {
  const scope = useScope();
  const { courses } = useStore();
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);
  const rows = useMemo(() => applyFilters(scope.trainees, filters), [scope.trainees, filters]);
  const stats = useMemo(() => courseStats(rows), [rows]);

  const best = [...stats].sort((a, b) => b.placementRate - a.placementRate)[0];
  const worst = [...stats].sort((a, b) => a.placementRate - b.placementRate)[0];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Training program effectiveness"
        description="Which courses actually lead to jobs, retention and income growth?"
        actions={
          <Button
            variant="outline"
            disabled={!stats.length}
            onClick={() =>
              downloadCsv(
                "program-effectiveness",
                stats.map((s) => ({
                  Course: s.course,
                  Sector: s.sector,
                  Trainees: s.trainees,
                  "Completion %": s.completionRate,
                  "Certification %": s.certificationRate,
                  "Placement %": s.placementRate,
                  "Retention 12m %": s.retention12,
                  "Avg salary": s.avgSalary,
                  Satisfaction: s.traineeSatisfaction,
                })),
              )
            }
          >
            <Download className="mr-2 size-4" aria-hidden />
            Export CSV
          </Button>
        }
      />

      <FilterBar filters={filters} onChange={setFilters} hideProvider={scope.role === "provider"} />

      {!stats.length ? (
        <EmptyState
          icon={GraduationCap}
          title="No program data in this scope"
          description="Reset the filters to see program comparisons."
          action={
            <Button variant="outline" onClick={() => setFilters(EMPTY_FILTERS)}>
              Reset filters
            </Button>
          }
        />
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2">
            <Card className="border-success/40 bg-success/5">
              <CardContent className="p-5">
                <p className="text-xs tracking-wide text-muted-foreground uppercase">
                  Best performing program
                </p>
                <p className="mt-1 text-lg font-semibold">{best?.course}</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  {best?.placementRate}% placement · {formatINR(best?.avgSalary ?? 0)} average salary
                </p>
              </CardContent>
            </Card>
            <Card className="border-destructive/40 bg-destructive/5">
              <CardContent className="p-5">
                <p className="text-xs tracking-wide text-muted-foreground uppercase">
                  Needs intervention
                </p>
                <p className="mt-1 text-lg font-semibold">{worst?.course}</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  {worst?.placementRate}% placement · review curriculum and employer linkages
                </p>
              </CardContent>
            </Card>
          </div>

          <ChartCard
            title="Placement vs 12-month retention by course"
            description="Programs where placements hold up over time"
          >
            <CourseComparisonBars
              data={stats.map((s) => ({
                course: s.course,
                placementRate: s.placementRate,
                retention12: s.retention12,
              }))}
            />
          </ChartCard>

          <Card>
            <CardContent className="overflow-x-auto p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Course</TableHead>
                    <TableHead>Trainees</TableHead>
                    <TableHead>Completion</TableHead>
                    <TableHead>Certification</TableHead>
                    <TableHead>Placement</TableHead>
                    <TableHead>Retention 3/6/12</TableHead>
                    <TableHead className="text-right">Avg salary</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stats.map((s) => (
                    <TableRow key={s.courseId}>
                      <TableCell>
                        <span className="block font-medium">{s.course}</span>
                        <span className="block text-xs text-muted-foreground">
                          {s.sector} ·{" "}
                          {courses.find((c) => c.id === s.courseId)?.durationWeeks ?? "—"} weeks
                        </span>
                      </TableCell>
                      <TableCell>{s.trainees}</TableCell>
                      <TableCell>{s.completionRate}%</TableCell>
                      <TableCell>{s.certificationRate}%</TableCell>
                      <TableCell>
                        <Badge variant={s.placementRate >= 70 ? "default" : "secondary"}>
                          {s.placementRate}%
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">
                        {s.retention3}% / {s.retention6}% / {s.retention12}%
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        {formatINR(s.avgSalary)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

```

## FILE 91: src/routes/app.providers.tsx

```tsx
import { createFileRoute } from "@tanstack/react-router";
import { Download } from "lucide-react";
import { useMemo } from "react";

import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useScope } from "@/hooks/use-scope";
import { formatINR, providerStats } from "@/services/analytics";
import { downloadCsv } from "@/utils/export";

export const Route = createFileRoute("/app/providers")({
  head: () => ({
    meta: [
      { title: "Training providers — MahaSkillTrack" },
      { name: "description", content: "Compare accredited training providers on completion, placement, retention and salary outcomes." },
      { property: "og:title", content: "Provider Performance — MahaSkillTrack" },
      { property: "og:description", content: "Accreditation-linked provider performance league table." },
    ],
  }),
  component: ProvidersPage,
});

function ProvidersPage() {
  const scope = useScope();
  const stats = useMemo(() => providerStats(scope.trainees), [scope.trainees]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Training provider performance"
        description="Accreditation grade against real employment outcomes for each empanelled provider."
        actions={
          <Button
            variant="outline"
            onClick={() =>
              downloadCsv(
                "provider-performance",
                stats.map((p) => ({
                  Provider: p.provider,
                  District: p.district,
                  Accreditation: p.accreditation,
                  Trainees: p.trainees,
                  "Completion %": p.completionRate,
                  "Employment %": p.employmentRate,
                  "Retention 6m %": p.retention,
                  "Avg salary": p.avgSalary,
                })),
              )
            }
          >
            <Download className="mr-2 size-4" aria-hidden />
            Export CSV
          </Button>
        }
      />
      <Card>
        <CardContent className="overflow-x-auto p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Provider</TableHead>
                <TableHead>Accreditation</TableHead>
                <TableHead>Trainees</TableHead>
                <TableHead>Completion</TableHead>
                <TableHead>Employment</TableHead>
                <TableHead>Retention 6m</TableHead>
                <TableHead className="text-right">Avg salary</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...stats]
                .sort((a, b) => b.employmentRate - a.employmentRate)
                .map((p) => (
                  <TableRow key={p.providerId}>
                    <TableCell>
                      <span className="block font-medium">{p.provider}</span>
                      <span className="block text-xs text-muted-foreground">
                        {p.district} · rating {p.rating}/5 · {p.programs} programs
                      </span>
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={p.accreditation === "C" ? "Needs Review" : "Verified"} showIcon={false} />
                    </TableCell>
                    <TableCell>{p.trainees}</TableCell>
                    <TableCell>{p.completionRate}%</TableCell>
                    <TableCell className="font-medium">{p.employmentRate}%</TableCell>
                    <TableCell>{p.retention}%</TableCell>
                    <TableCell className="text-right">{formatINR(p.avgSalary)}</TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

```

## FILE 92: src/routes/app.reports.tsx

```tsx
import { createFileRoute } from "@tanstack/react-router";
import { Download, FileText, Printer } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

import { FilterBar } from "@/components/common/filter-bar";
import { PageHeader } from "@/components/common/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useScope } from "@/hooks/use-scope";
import { EMPTY_FILTERS, applyFilters, courseStats, districtStats, kpis, providerStats, salaryOf } from "@/services/analytics";
import { useStore } from "@/services/store";
import { downloadCsv, downloadPrintableReport } from "@/utils/export";
import type { Filters } from "@/types";

export const Route = createFileRoute("/app/reports")({
  head: () => ({
    meta: [
      { title: "Reports — MahaSkillTrack" },
      { name: "description", content: "Generate district, program, provider and trainee outcome reports as CSV or printable documents." },
      { property: "og:title", content: "Reports & Exports — MahaSkillTrack" },
      { property: "og:description", content: "Export-ready outcome reporting for review meetings." },
    ],
  }),
  component: ReportsPage,
});

function ReportsPage() {
  const scope = useScope();
  const { courseName, providerName } = useStore();
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);
  const rows = useMemo(() => applyFilters(scope.trainees, filters), [scope.trainees, filters]);
  const k = kpis(rows);
  const subtitle = `${rows.length} trainee records · generated ${new Date().toLocaleDateString("en-IN")}`;

  const reports = [
    {
      title: "Outcome summary",
      description: "Headline KPIs: completion, employment, retention and average salary.",
      rows: [
        { Metric: "Total trainees", Value: k.total },
        { Metric: "Completion rate %", Value: k.completionRate },
        { Metric: "Employment rate %", Value: k.employmentRate },
        { Metric: "Self-employed %", Value: k.selfRate },
        { Metric: "12-month retention %", Value: k.retention12 },
        { Metric: "Average salary", Value: k.avgSalary },
      ] as Record<string, string | number>[],
    },
    {
      title: "District performance",
      description: "Employment rate, retention and salary by district.",
      rows: districtStats(rows).map((d) => ({
        District: d.district,
        Trainees: d.trainees,
        "Employment %": d.employmentRate,
        "Retention 6m %": d.retention,
        "Avg salary": d.avgSalary,
      })) as Record<string, string | number>[],
    },
    {
      title: "Program effectiveness",
      description: "Completion, certification, placement and retention per course.",
      rows: courseStats(rows).map((c) => ({
        Course: c.course,
        Trainees: c.trainees,
        "Completion %": c.completionRate,
        "Placement %": c.placementRate,
        "Retention 12m %": c.retention12,
        "Avg salary": c.avgSalary,
      })) as Record<string, string | number>[],
    },
    {
      title: "Provider performance",
      description: "Provider-wise outcome league table.",
      rows: providerStats(rows).map((p) => ({
        Provider: p.provider,
        District: p.district,
        Accreditation: p.accreditation,
        Trainees: p.trainees,
        "Employment %": p.employmentRate,
        "Avg salary": p.avgSalary,
      })) as Record<string, string | number>[],
    },
    {
      title: "Trainee outcome list",
      description: "Record-level outcomes without personal contact details.",
      rows: rows.map((t) => ({
        "Trainee ID": t.id,
        District: t.district,
        Course: courseName(t.courseId),
        Provider: providerName(t.providerId),
        Outcome: t.employmentStatus,
        Income: salaryOf(t) || "",
      })) as Record<string, string | number>[],
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader title="Reports and exports" description="Filter the data, then export review-ready reports for departmental meetings." />
      <FilterBar filters={filters} onChange={setFilters} hideProvider={scope.role === "provider"} />
      <div className="grid gap-5 md:grid-cols-2">
        {reports.map((r) => (
          <Card key={r.title}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <FileText className="size-4 text-primary" aria-hidden />
                {r.title}
              </CardTitle>
              <CardDescription>{r.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={!r.rows.length}
                onClick={() => {
                  downloadCsv(r.title.toLowerCase().replace(/\s+/g, "-"), r.rows);
                  toast.success(`${r.title} exported as CSV`);
                }}
              >
                <Download className="mr-1.5 size-4" aria-hidden />
                CSV
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={!r.rows.length}
                onClick={() => {
                  downloadPrintableReport(r.title, subtitle, r.rows);
                  toast.success(`${r.title} generated as a printable report`);
                }}
              >
                <Printer className="mr-1.5 size-4" aria-hidden />
                Printable
              </Button>
              <span className="self-center text-xs text-muted-foreground">{r.rows.length} rows</span>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

```

## FILE 93: src/routes/app.settings.tsx

```tsx
import { createFileRoute } from "@tanstack/react-router";
import { RotateCcw } from "lucide-react";
import { toast } from "sonner";

import { ROLE_LABEL, useAuth } from "@/auth/auth-context";
import { PageHeader } from "@/components/common/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useStore } from "@/services/store";

export const Route = createFileRoute("/app/settings")({
  head: () => ({
    meta: [
      { title: "Settings — MahaSkillTrack" },
      { name: "description", content: "Manage your MahaSkillTrack demo account and reset the seeded demonstration dataset." },
      { property: "og:title", content: "Settings — MahaSkillTrack" },
      { property: "og:description", content: "Account details and demo data controls." },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { user } = useAuth();
  const { resetData, trainees } = useStore();

  return (
    <div className="space-y-6">
      <PageHeader title="Settings" description="Account details and demo environment controls." />
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Account</CardTitle>
          <CardDescription>Signed in with a seeded demonstration account</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <Row label="Name" value={user?.name ?? "—"} />
          <Row label="Email" value={user?.email ?? "—"} />
          <Row label="Role" value={user ? ROLE_LABEL[user.role] : "—"} />
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Demo data</CardTitle>
          <CardDescription>{trainees.length} synthetic trainee records currently loaded</CardDescription>
        </CardHeader>
        <CardContent>
          <Button
            variant="outline"
            onClick={() => {
              resetData();
              toast.success("Demo data reset", { description: "All outcomes and follow-ups are back to their seeded values." });
            }}
          >
            <RotateCcw className="mr-2 size-4" aria-hidden />
            Reset demo data
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-border/60 pb-1.5 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}

```

## FILE 94: src/routes/app.skill-gaps.tsx

```tsx
import { createFileRoute } from "@tanstack/react-router";
import { Lightbulb } from "lucide-react";

import { ChartCard } from "@/components/common/chart-card";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { SkillGapBars } from "@/components/charts/dashboard-charts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { skillGaps, skillInsights } from "@/services/analytics";

export const Route = createFileRoute("/app/skill-gaps")({
  head: () => ({
    meta: [
      { title: "Skill gaps — MahaSkillTrack" },
      { name: "description", content: "Compare employer skill demand with training coverage and act on gap-closing recommendations." },
      { property: "og:title", content: "Skill Gap Intelligence — MahaSkillTrack" },
      { property: "og:description", content: "Demand versus coverage analysis for Maharashtra skill programs." },
    ],
  }),
  component: SkillGapsPage,
});

function SkillGapsPage() {
  const gaps = skillGaps();
  const insight = skillInsights();

  return (
    <div className="space-y-6">
      <PageHeader title="Skill gap intelligence" description="Where employer demand outpaces what training programs currently teach." />
      <Card className="border-accent/40 bg-accent/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Lightbulb className="size-4 text-accent-foreground" aria-hidden />
            Recommendation
          </CardTitle>
          <CardDescription>{insight.highCount} skills currently show a high-severity gap</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p>{insight.insight}</p>
          <p className="text-muted-foreground">{insight.action}</p>
        </CardContent>
      </Card>
      <ChartCard title="Employer demand vs training coverage" description="Percentage of employers requiring the skill against percentage of programs teaching it">
        <SkillGapBars data={gaps.map((g) => ({ skill: g.skill, demand: g.demand, coverage: g.coverage }))} />
      </ChartCard>
      <Card>
        <CardContent className="overflow-x-auto p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Skill</TableHead>
                <TableHead>Employer demand</TableHead>
                <TableHead>Training coverage</TableHead>
                <TableHead>Gap</TableHead>
                <TableHead>Severity</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {gaps.map((g) => (
                <TableRow key={g.skill}>
                  <TableCell className="font-medium">{g.skill}</TableCell>
                  <TableCell>{g.demand}%</TableCell>
                  <TableCell>{g.coverage}%</TableCell>
                  <TableCell className="font-medium">{g.gap} pts</TableCell>
                  <TableCell>
                    <StatusBadge status={g.severity} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

```

## FILE 95: src/routes/app.trainees.$traineeId.tsx

```tsx
import { Link, createFileRoute, useParams } from "@tanstack/react-router";
import {
  ArrowLeft,
  Award,
  BadgeCheck,
  Building2,
  CalendarClock,
  Download,
  GraduationCap,
  IndianRupee,
  MapPin,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/common/page-header";
import { EmptyState } from "@/components/common/states";
import { StatusBadge } from "@/components/common/status-badge";
import { Timeline } from "@/components/common/timeline";
import { SalaryLine } from "@/components/charts/dashboard-charts";
import { FollowUpDialog } from "@/components/forms/follow-up-dialog";
import { OutcomeDialog } from "@/components/forms/outcome-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useScope } from "@/hooks/use-scope";
import { formatINR } from "@/services/analytics";
import { useStore } from "@/services/store";
import { downloadPrintableReport } from "@/utils/export";

export const Route = createFileRoute("/app/trainees/$traineeId")({
  head: () => ({
    meta: [
      { title: "Trainee profile — MahaSkillTrack" },
      {
        name: "description",
        content:
          "Full trainee journey: training record, certification, employment outcome, salary progression and follow-up history.",
      },
      { property: "og:title", content: "Trainee Journey — MahaSkillTrack" },
      {
        property: "og:description",
        content: "Individual outcome record with timeline, follow-ups and verification status.",
      },
    ],
  }),
  component: TraineeProfile,
});

function TraineeProfile() {
  const { traineeId } = useParams({ from: "/app/trainees/$traineeId" });
  const { getTrainee, courseName, providerName, courses, verifyEmployment } = useStore();
  const scope = useScope();
  const [outcomeOpen, setOutcomeOpen] = useState(false);
  const [followUpId, setFollowUpId] = useState<string | null>(null);

  const t = getTrainee(traineeId);

  if (!t) {
    return (
      <EmptyState
        title="Trainee not found"
        description={`No record exists for ID ${traineeId}.`}
        action={
          <Button asChild variant="outline">
            <Link to="/app/trainees">Back to registry</Link>
          </Button>
        }
      />
    );
  }

  const course = courses.find((c) => c.id === t.courseId);
  const first = t.salaryProgression[0]?.salary ?? 0;
  const latest = t.salaryProgression.at(-1)?.salary ?? 0;
  const growth = first ? Math.round(((latest - first) / first) * 100) : 0;
  const canEdit = scope.canEdit;

  return (
    <div className="space-y-6">
      <Button variant="ghost" size="sm" asChild className="-ml-2">
        <Link to="/app/trainees">
          <ArrowLeft className="mr-1.5 size-4" aria-hidden />
          Back to registry
        </Link>
      </Button>

      <PageHeader
        title={t.name}
        description={`${t.id} · ${t.age} years · ${t.gender} · ${t.education} · ${t.district} district`}
        actions={
          <>
            <StatusBadge status={t.employmentStatus} />
            <Button
              variant="outline"
              onClick={() =>
                downloadPrintableReport(
                  `Trainee Outcome Record ${t.id}`,
                  `${t.name} · ${courseName(t.courseId)} · ${providerName(t.providerId)}`,
                  [
                    { Field: "Trainee ID", Value: t.id },
                    { Field: "District", Value: t.district },
                    { Field: "Course", Value: courseName(t.courseId) },
                    { Field: "Provider", Value: providerName(t.providerId) },
                    { Field: "Training status", Value: t.trainingStatus },
                    { Field: "Certified", Value: t.certified ? "Yes" : "No" },
                    { Field: "Employment status", Value: t.employmentStatus },
                    { Field: "Employer", Value: t.employment.employerName ?? "—" },
                    { Field: "Current income", Value: formatINR(latest) },
                    { Field: "Salary growth", Value: `${growth}%` },
                  ],
                )
              }
            >
              <Download className="mr-2 size-4" aria-hidden />
              Export record
            </Button>
            {canEdit ? <Button onClick={() => setOutcomeOpen(true)}>Update outcome</Button> : null}
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MiniStat
          icon={GraduationCap}
          label="Training"
          value={t.trainingStatus}
          sub={`${t.startDate} → ${t.endDate}`}
        />
        <MiniStat
          icon={Award}
          label="Assessment"
          value={`${t.assessmentScore}/100`}
          sub={`Attendance ${t.attendance}%`}
        />
        <MiniStat
          icon={IndianRupee}
          label="Current income"
          value={formatINR(latest)}
          sub={growth ? `${growth > 0 ? "+" : ""}${growth}% since joining` : "No income recorded"}
        />
        <MiniStat
          icon={ShieldCheck}
          label="Consent"
          value={t.consent}
          sub={`Recorded ${t.consentDate}`}
        />
      </div>

      <Tabs defaultValue="journey">
        <TabsList className="flex-wrap">
          <TabsTrigger value="journey">Journey</TabsTrigger>
          <TabsTrigger value="training">Training</TabsTrigger>
          <TabsTrigger value="employment">Employment</TabsTrigger>
          <TabsTrigger value="followups">Follow-ups</TabsTrigger>
          <TabsTrigger value="privacy">Privacy</TabsTrigger>
        </TabsList>

        <TabsContent value="journey" className="mt-5 grid gap-5 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Career timeline</CardTitle>
              <CardDescription>Enrollment through the latest verified milestone</CardDescription>
            </CardHeader>
            <CardContent>
              <Timeline events={t.timeline} />
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Salary progression</CardTitle>
              <CardDescription>Reported monthly income at each milestone</CardDescription>
            </CardHeader>
            <CardContent>
              {t.salaryProgression.length ? (
                <SalaryLine data={t.salaryProgression} height={260} />
              ) : (
                <EmptyState
                  title="No income data"
                  description="Income appears once an employment outcome is recorded."
                />
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="training" className="mt-5 grid gap-5 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Training record</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <Row label="Course" value={courseName(t.courseId)} />
              <Row label="Sector" value={course?.sector ?? "—"} />
              <Row label="Duration" value={`${course?.durationWeeks ?? "—"} weeks`} />
              <Row label="Provider" value={providerName(t.providerId)} />
              <Row label="Centre" value={t.trainingCenter} />
              <Row label="Batch year" value={String(t.trainingYear)} />
              <Row label="Certified" value={t.certified ? "Yes" : "No"} />
              <div className="pt-2">
                <p className="mb-1.5 text-xs text-muted-foreground">Attendance</p>
                <Progress value={t.attendance} />
              </div>
              <div className="pt-1">
                <p className="mb-1.5 text-xs text-muted-foreground">Assessment score</p>
                <Progress value={t.assessmentScore} />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Sparkles className="size-4 text-accent-foreground" aria-hidden />
                Skills acquired
              </CardTitle>
              <CardDescription>Curriculum skills mapped to employer demand</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-wrap gap-2">
              {(course?.skills ?? []).map((s) => (
                <Badge key={s} variant="secondary">
                  {s}
                </Badge>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="employment" className="mt-5 grid gap-5 lg:grid-cols-2">
          <Card>
            <CardHeader className="flex flex-row items-start justify-between gap-3">
              <div>
                <CardTitle className="text-base">Employment details</CardTitle>
                <CardDescription>Current recorded outcome</CardDescription>
              </div>
              {t.employment.verified ? (
                <StatusBadge status="Verified" />
              ) : (
                <StatusBadge status="Pending Verification" />
              )}
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <Row label="Status" value={t.employmentStatus} />
              <Row label="Employer" value={t.employment.employerName ?? "—"} />
              <Row label="Job title" value={t.employment.jobTitle ?? t.employment.businessType ?? "—"} />
              <Row label="Employment type" value={t.employment.employmentType ?? "—"} />
              <Row
                label="Start date"
                value={t.employment.joiningDate ?? t.employment.businessStartDate ?? "—"}
              />
              <Row label="Location" value={t.employment.location ?? "—"} />
              <Row
                label="Income"
                value={formatINR(t.employment.salary ?? t.employment.monthlyIncome ?? 0)}
              />
              {t.nonPlacementReason ? (
                <Row label="Reason not placed" value={t.nonPlacementReason} />
              ) : null}
              {!t.employment.verified && t.employment.employerName ? (
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-2 w-full"
                  onClick={() => {
                    verifyEmployment(t.id);
                    toast.success("Employment verified", {
                      description: `${t.name}'s placement is now marked as employer-verified.`,
                    });
                  }}
                >
                  <BadgeCheck className="mr-1.5 size-4" aria-hidden />
                  Verify employment
                </Button>
              ) : null}
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Placement context</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <p className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="size-4" aria-hidden />
                Home district: {t.district}
              </p>
              <p className="flex items-center gap-2 text-muted-foreground">
                <Building2 className="size-4" aria-hidden />
                Training provider: {providerName(t.providerId)}
              </p>
              <p className="flex items-center gap-2 text-muted-foreground">
                <CalendarClock className="size-4" aria-hidden />
                Training completed: {t.endDate}
              </p>
              <p className="rounded-lg bg-muted/60 p-3 text-xs">
                Trainee satisfaction rating: <strong>{t.satisfaction}/5</strong>. Contact status:{" "}
                <strong>{t.contactReachable ? "Reachable" : "Unreachable"}</strong>.
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="followups" className="mt-5">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Follow-up milestones</CardTitle>
              <CardDescription>3, 6 and 12-month outcome verification</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {t.followUps.map((f) => (
                <div
                  key={f.id}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-3"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-medium">{f.milestone} follow-up</p>
                    <p className="text-xs text-muted-foreground">
                      {f.status === "Completed"
                        ? `Recorded ${f.completedDate} · ${f.employmentStatus ?? "—"}${f.salary ? ` · ${formatINR(f.salary)}` : ""}`
                        : `Due ${f.dueDate}`}
                    </p>
                    {f.notes ? <p className="mt-1 text-xs text-muted-foreground">{f.notes}</p> : null}
                  </div>
                  <div className="flex items-center gap-2">
                    <StatusBadge status={f.status} />
                    {canEdit ? (
                      <Button variant="outline" size="sm" onClick={() => setFollowUpId(f.id)}>
                        {f.status === "Completed" ? "Edit" : "Record"}
                      </Button>
                    ) : null}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="privacy" className="mt-5">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Consent and data sharing</CardTitle>
              <CardDescription>
                Personal contact details are never shown on analytics screens.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <Row label="Consent status" value={t.consent} />
              <Row label="Consent recorded" value={t.consentDate} />
              <Row label="Share with analytics" value={t.dataSharing.analytics ? "Allowed" : "Denied"} />
              <Row label="Share with employers" value={t.dataSharing.employers ? "Allowed" : "Denied"} />
              <Row label="Share for research" value={t.dataSharing.research ? "Allowed" : "Denied"} />
              <p className="mt-3 rounded-lg bg-muted/60 p-3 text-xs text-muted-foreground">
                All names and identifiers in this demo are synthetic. Aggregated reports exclude
                contact information entirely.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <OutcomeDialog trainee={t} open={outcomeOpen} onOpenChange={setOutcomeOpen} />
      <FollowUpDialog
        trainee={t}
        followUpId={followUpId}
        onClose={() => setFollowUpId(null)}
      />
    </div>
  );
}

function MiniStat({
  icon: Icon,
  label,
  value,
  sub,
}: {
  icon: typeof Award;
  label: string;
  value: string;
  sub: string;
}) {
  return (
    <Card>
      <CardContent className="flex items-start gap-3 p-4">
        <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
          <Icon className="size-5" aria-hidden />
        </span>
        <span className="min-w-0">
          <span className="block text-xs text-muted-foreground">{label}</span>
          <span className="block truncate text-sm font-semibold">{value}</span>
          <span className="block truncate text-xs text-muted-foreground">{sub}</span>
        </span>
      </CardContent>
    </Card>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-border/60 pb-1.5 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{value}</span>
    </div>
  );
}

```

## FILE 96: src/routes/app.trainees.index.tsx

```tsx
import { Link, createFileRoute } from "@tanstack/react-router";
import { Download, Search, Users } from "lucide-react";
import { useMemo, useState } from "react";

import { FilterBar } from "@/components/common/filter-bar";
import { PageHeader } from "@/components/common/page-header";
import { EmptyState } from "@/components/common/states";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useScope } from "@/hooks/use-scope";
import { EMPTY_FILTERS, applyFilters, formatINR, salaryOf } from "@/services/analytics";
import { useStore } from "@/services/store";
import { downloadCsv } from "@/utils/export";
import type { Filters } from "@/types";

export const Route = createFileRoute("/app/trainees/")({
  head: () => ({
    meta: [
      { title: "Trainees — MahaSkillTrack" },
      {
        name: "description",
        content:
          "Search, filter and export trainee records with training status, outcomes and salary details.",
      },
      { property: "og:title", content: "Trainee Registry — MahaSkillTrack" },
      {
        property: "og:description",
        content: "Consent-aware trainee registry with outcome and follow-up status.",
      },
    ],
  }),
  component: TraineesPage,
});

const PAGE_SIZE = 12;

function TraineesPage() {
  const scope = useScope();
  const { courseName, providerName } = useStore();
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);

  const rows = useMemo(() => {
    const filtered = applyFilters(scope.trainees, filters);
    const q = query.trim().toLowerCase();
    if (!q) return filtered;
    return filtered.filter(
      (t) =>
        t.name.toLowerCase().includes(q) ||
        t.id.toLowerCase().includes(q) ||
        t.district.toLowerCase().includes(q),
    );
  }, [scope.trainees, filters, query]);

  const pageCount = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const current = Math.min(page, pageCount);
  const visible = rows.slice((current - 1) * PAGE_SIZE, current * PAGE_SIZE);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Trainee registry"
        description={`${scope.scopeLabel} · ${rows.length} records match your search and filters.`}
        actions={
          <Button
            variant="outline"
            onClick={() =>
              downloadCsv(
                "trainees",
                rows.map((t) => ({
                  "Trainee ID": t.id,
                  Name: t.name,
                  District: t.district,
                  Course: courseName(t.courseId),
                  Provider: providerName(t.providerId),
                  "Training status": t.trainingStatus,
                  Certified: t.certified ? "Yes" : "No",
                  Outcome: t.employmentStatus,
                  Salary: salaryOf(t) || "",
                })),
              )
            }
          >
            <Download className="mr-2 size-4" aria-hidden />
            Export CSV
          </Button>
        }
      />

      <FilterBar filters={filters} onChange={setFilters} hideProvider={scope.role === "provider"} />

      <Card>
        <CardContent className="p-4 sm:p-5">
          <div className="relative max-w-sm">
            <Search
              className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden
            />
            <Input
              className="pl-9"
              placeholder="Search name, trainee ID or district"
              aria-label="Search trainees"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setPage(1);
              }}
            />
          </div>

          {visible.length === 0 ? (
            <div className="pt-6">
              <EmptyState
                icon={Users}
                title="No trainee records found"
                description="Adjust your search text or reset the filters above."
                action={
                  <Button
                    variant="outline"
                    onClick={() => {
                      setFilters(EMPTY_FILTERS);
                      setQuery("");
                    }}
                  >
                    Clear search and filters
                  </Button>
                }
              />
            </div>
          ) : (
            <>
              <div className="mt-4 overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Trainee</TableHead>
                      <TableHead>Course</TableHead>
                      <TableHead className="hidden md:table-cell">Provider</TableHead>
                      <TableHead>Training</TableHead>
                      <TableHead>Outcome</TableHead>
                      <TableHead className="text-right">Income</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {visible.map((t) => (
                      <TableRow key={t.id} className="cursor-pointer">
                        <TableCell>
                          <Link
                            to="/app/trainees/$traineeId"
                            params={{ traineeId: t.id }}
                            className="block"
                          >
                            <span className="block font-medium">{t.name}</span>
                            <span className="block text-xs text-muted-foreground">
                              {t.id} · {t.district} · {t.age}y {t.gender}
                            </span>
                          </Link>
                        </TableCell>
                        <TableCell className="text-sm">{courseName(t.courseId)}</TableCell>
                        <TableCell className="hidden text-sm md:table-cell">
                          {providerName(t.providerId)}
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={t.trainingStatus} />
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={t.employmentStatus} />
                        </TableCell>
                        <TableCell className="text-right text-sm font-medium">
                          {formatINR(salaryOf(t))}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-sm">
                <p className="text-muted-foreground">
                  Page {current} of {pageCount} · {rows.length} records
                </p>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={current === 1}
                    onClick={() => setPage(current - 1)}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={current === pageCount}
                    onClick={() => setPage(current + 1)}
                  >
                    Next
                  </Button>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

```

## FILE 97: src/routes/app.tsx

```tsx
import { Outlet, createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";

import { useAuth } from "@/auth/auth-context";
import { AppShell } from "@/components/layout/app-shell";
import { LoadingState } from "@/components/common/states";

export const Route = createFileRoute("/app")({
  ssr: false,
  component: AppLayout,
});

function AppLayout() {
  const { user, hydrated } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (hydrated && !user) void navigate({ to: "/login", replace: true });
  }, [hydrated, user, navigate]);

  if (!hydrated || !user) {
    return (
      <div className="min-h-screen bg-background p-8">
        <LoadingState label="Preparing your workspace…" />
      </div>
    );
  }

  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
}

```

## FILE 98: src/routes/index.tsx

```tsx
import { Link, createFileRoute } from "@tanstack/react-router";
import {
  ArrowRight,
  BadgeCheck,
  BarChart3,
  Briefcase,
  ChartLine,
  GraduationCap,
  LineChart,
  Radar,
  ShieldCheck,
  Target,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MahaSkillTrack — Skill Training Outcome Intelligence" },
      {
        name: "description",
        content:
          "Track Maharashtra skill-development outcomes from training to employment: placement, retention, salary growth and skill gaps in one platform.",
      },
      { property: "og:title", content: "MahaSkillTrack — From Training to Employment" },
      {
        property: "og:description",
        content:
          "Turn skill-training data into actionable employment intelligence across Maharashtra districts, courses and providers.",
      },
    ],
  }),
  component: Landing,
});

const FEATURES = [
  {
    icon: Target,
    title: "Track",
    body: "Follow every trainee from enrollment and certification through to employment, self-employment or apprenticeship.",
  },
  {
    icon: LineChart,
    title: "Measure",
    body: "Measure placement, 3/6/12-month retention, salary growth and satisfaction with verified follow-up data.",
  },
  {
    icon: Radar,
    title: "Improve",
    body: "Compare districts, courses and providers, expose skill gaps and act on rule-based recommendations.",
  },
];

const PROCESS = ["Training", "Certification", "Employment", "Follow-up", "Impact"];

const STATS = [
  { label: "Trainees tracked", value: "50,240" },
  { label: "Employment rate", value: "72.4%" },
  { label: "12-month retention", value: "81.3%" },
  { label: "Districts covered", value: "8" },
];

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-20 border-b border-border/70 bg-background/85 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <span className="grid size-9 place-items-center rounded-lg bg-primary font-bold text-primary-foreground">
              M
            </span>
            <div className="leading-tight">
              <p className="text-sm font-semibold">MahaSkillTrack</p>
              <p className="hidden text-[11px] text-muted-foreground sm:block">
                Maharashtra Skill Development Outcome Intelligence
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button asChild variant="ghost" size="sm">
              <Link to="/login">Sign in</Link>
            </Button>
            <Button asChild size="sm">
              <Link to="/app/dashboard">
                Explore Dashboard
                <ArrowRight className="ml-1.5 size-4" aria-hidden />
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <section className="gov-gradient relative overflow-hidden text-primary-foreground">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
            <p className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-medium">
              <ShieldCheck className="size-3.5" aria-hidden />
              Government of Maharashtra · Skill Development Mission
            </p>
            <h1 className="mt-5 text-4xl font-semibold tracking-tight sm:text-5xl">
              From Training to Employment.
            </h1>
            <p className="mt-4 max-w-xl text-base/relaxed text-primary-foreground/80">
              Track skill-development outcomes across Maharashtra and turn training data into
              actionable employment intelligence.
            </p>
            <p className="mt-3 text-sm font-medium text-accent">
              Measuring what really matters — placement, retention and income growth.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
                <Link to="/app/dashboard">
                  Explore Dashboard
                  <ArrowRight className="ml-2 size-4" aria-hidden />
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-white/30 bg-transparent text-primary-foreground hover:bg-white/10 hover:text-primary-foreground"
              >
                <Link to="/login">View Demo</Link>
              </Button>
            </div>
            <dl className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-4">
              {STATS.map((s) => (
                <div key={s.label}>
                  <dt className="text-[11px] tracking-wide text-primary-foreground/60 uppercase">
                    {s.label}
                  </dt>
                  <dd className="mt-1 text-xl font-semibold">{s.value}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="animate-in fade-in slide-in-from-bottom-8 relative duration-1000">
            <div className="rounded-2xl border border-white/15 bg-white/10 p-5 shadow-2xl backdrop-blur">
              <p className="text-xs tracking-wide text-primary-foreground/70 uppercase">
                Outcome snapshot · September 2026
              </p>
              <div className="mt-4 space-y-3">
                {[
                  { icon: GraduationCap, label: "Training completed", value: "42,850", tone: "bg-white/15" },
                  { icon: Briefcase, label: "Placed in jobs", value: "36,180", tone: "bg-success/25" },
                  { icon: ChartLine, label: "Average salary growth", value: "+48% in 12 months", tone: "bg-accent/25" },
                  { icon: BarChart3, label: "Largest skill gap", value: "SQL — 29 pt gap", tone: "bg-destructive/25" },
                ].map((row) => (
                  <div
                    key={row.label}
                    className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 p-3"
                  >
                    <span className={`grid size-9 place-items-center rounded-lg ${row.tone}`}>
                      <row.icon className="size-4" aria-hidden />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-xs text-primary-foreground/70">{row.label}</span>
                      <span className="block truncate text-sm font-semibold">{row.value}</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <h2 className="text-2xl font-semibold tracking-tight">
          Did the training actually improve the outcome?
        </h2>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Completion certificates alone do not answer that question. MahaSkillTrack follows the full
          journey and reports what changed in each trainee's livelihood.
        </p>
        <div className="mt-8 grid gap-5 md:grid-cols-3">
          {FEATURES.map((f) => (
            <Card key={f.title} className="transition-shadow hover:shadow-lg">
              <CardContent className="p-6">
                <span className="grid size-11 place-items-center rounded-xl bg-primary/10 text-primary">
                  <f.icon className="size-5" aria-hidden />
                </span>
                <h3 className="mt-4 text-lg font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{f.body}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="border-y border-border bg-muted/40 py-14">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <h2 className="text-xl font-semibold tracking-tight">The outcome pipeline</h2>
          <ol className="mt-6 flex flex-col gap-3 md:flex-row md:items-center">
            {PROCESS.map((step, i) => (
              <li key={step} className="flex flex-1 items-center gap-3">
                <div className="flex flex-1 items-center gap-3 rounded-xl border border-border bg-card px-4 py-3 shadow-sm">
                  <span className="grid size-7 shrink-0 place-items-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">
                    {i + 1}
                  </span>
                  <span className="text-sm font-medium">{step}</span>
                </div>
                {i < PROCESS.length - 1 ? (
                  <ArrowRight className="hidden size-4 shrink-0 text-muted-foreground md:block" aria-hidden />
                ) : null}
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <div className="rounded-2xl border border-border bg-card p-8 shadow-sm sm:p-10">
          <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-xl font-semibold tracking-tight">Try the demo environment</h2>
              <p className="mt-2 max-w-xl text-sm text-muted-foreground">
                Four seeded roles — administrator, training provider, trainee and employer — with
                synthetic Maharashtra data. No real personal information is used.
              </p>
              <p className="mt-3 inline-flex items-center gap-2 text-xs text-muted-foreground">
                <BadgeCheck className="size-4 text-success" aria-hidden />
                Privacy-first: analytics screens show aggregated data only.
              </p>
            </div>
            <Button asChild size="lg">
              <Link to="/login">
                Open demo login
                <ArrowRight className="ml-2 size-4" aria-hidden />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <footer className="border-t border-border py-8">
        <div className="mx-auto max-w-6xl px-4 text-xs text-muted-foreground sm:px-6">
          MahaSkillTrack · Hackathon prototype for the Government of Maharashtra · Synthetic
          demonstration data only.
        </div>
      </footer>
    </div>
  );
}

```

## FILE 99: src/routes/login.tsx

```tsx
import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import { ArrowRight, KeyRound, ShieldCheck, TrendingUp, Users } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { useAuth } from "@/auth/auth-context";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DEMO_USERS } from "@/data/seed";
import { ROLE_LABEL } from "@/auth/auth-context";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Sign in — MahaSkillTrack" },
      {
        name: "description",
        content:
          "Sign in to MahaSkillTrack with a demo administrator, training provider, trainee or employer account.",
      },
      { property: "og:title", content: "Sign in — MahaSkillTrack" },
      {
        property: "og:description",
        content: "Role-based access to Maharashtra skill training outcome intelligence.",
      },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("admin@mahaskill.demo");
  const [password, setPassword] = useState("demo1234");
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!email.includes("@")) {
      setError("Enter a valid email address.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }
    setBusy(true);
    const result = signIn(email, password);
    setBusy(false);
    if (!result.ok) {
      setError(result.error ?? "Sign in failed.");
      return;
    }
    toast.success(`Signed in as ${ROLE_LABEL[result.role!]}`);
    void navigate({ to: "/app/dashboard" });
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="gov-gradient hidden flex-col justify-between p-10 text-primary-foreground lg:flex">
        <Link to="/" className="flex items-center gap-3">
          <span className="grid size-10 place-items-center rounded-lg bg-accent font-bold text-accent-foreground">
            M
          </span>
          <span>
            <span className="block font-semibold">MahaSkillTrack</span>
            <span className="block text-xs text-primary-foreground/70">
              Maharashtra Skill Development Outcome Intelligence
            </span>
          </span>
        </Link>
        <div>
          <h1 className="max-w-md text-3xl font-semibold tracking-tight">
            Turning training data into employment outcomes.
          </h1>
          <ul className="mt-8 space-y-4 text-sm text-primary-foreground/80">
            {[
              { icon: Users, text: "One record per trainee, from enrollment to 12-month follow-up." },
              { icon: TrendingUp, text: "Placement, retention and salary progression in real time." },
              { icon: ShieldCheck, text: "Consent-aware data sharing and aggregated analytics." },
            ].map((row) => (
              <li key={row.text} className="flex items-start gap-3">
                <row.icon className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden />
                {row.text}
              </li>
            ))}
          </ul>
        </div>
        <p className="text-xs text-primary-foreground/60">
          Prototype environment · synthetic data · Government of Maharashtra hackathon
        </p>
      </div>

      <div className="flex items-center justify-center bg-background px-4 py-12 sm:px-8">
        <div className="w-full max-w-md">
          <Link to="/" className="mb-8 flex items-center gap-2 text-sm text-muted-foreground lg:hidden">
            <span className="grid size-8 place-items-center rounded-lg bg-primary text-xs font-bold text-primary-foreground">
              M
            </span>
            MahaSkillTrack
          </Link>
          <h2 className="text-2xl font-semibold tracking-tight">Sign in</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Your role and permissions are determined by your account.
          </p>

          <form onSubmit={submit} className="mt-8 space-y-4" noValidate>
            <div className="space-y-1.5">
              <Label htmlFor="email">Email address</Label>
              <Input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                aria-invalid={Boolean(error)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                aria-invalid={Boolean(error)}
              />
            </div>
            {error ? (
              <p role="alert" className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {error}
              </p>
            ) : null}
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 text-sm text-muted-foreground">
                <Checkbox
                  checked={remember}
                  onCheckedChange={(v) => setRemember(Boolean(v))}
                  aria-label="Remember me"
                />
                Remember me
              </label>
              <button
                type="button"
                className="text-sm font-medium text-primary underline-offset-4 hover:underline"
                onClick={() =>
                  toast.info("Password reset is disabled in the demo environment.", {
                    description: "Use any listed demo account with the password demo1234.",
                  })
                }
              >
                Forgot password?
              </button>
            </div>
            <Button type="submit" className="w-full" size="lg" disabled={busy}>
              {busy ? "Signing in…" : "Sign in"}
              <ArrowRight className="ml-2 size-4" aria-hidden />
            </Button>
          </form>

          <Card className="mt-8 border-dashed bg-muted/40">
            <CardContent className="p-4">
              <p className="flex items-center gap-2 text-sm font-semibold">
                <KeyRound className="size-4 text-accent-foreground" aria-hidden />
                Demo login · password <code className="rounded bg-background px-1.5 py-0.5">demo1234</code>
              </p>
              <div className="mt-3 grid gap-2">
                {DEMO_USERS.map((u) => (
                  <button
                    key={u.email}
                    type="button"
                    onClick={() => {
                      setEmail(u.email);
                      setPassword(u.password);
                      setError(null);
                    }}
                    className="flex items-center justify-between rounded-lg border border-border bg-card px-3 py-2 text-left text-sm transition-colors hover:border-primary/40 hover:bg-accent/10"
                  >
                    <span className="min-w-0">
                      <span className="block truncate font-medium">{ROLE_LABEL[u.role]}</span>
                      <span className="block truncate text-xs text-muted-foreground">{u.email}</span>
                    </span>
                    <ArrowRight className="size-4 shrink-0 text-muted-foreground" aria-hidden />
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

```

## FILE 100: src/server.ts

```ts
import "./lib/error-capture";

import { consumeLastCapturedError } from "./lib/error-capture";
import { renderErrorPage } from "./lib/error-page";

type ServerEntry = {
  fetch: (request: Request, env: unknown, ctx: unknown) => Promise<Response> | Response;
};

let serverEntryPromise: Promise<ServerEntry> | undefined;

async function getServerEntry(): Promise<ServerEntry> {
  if (!serverEntryPromise) {
    serverEntryPromise = import("@tanstack/react-start/server-entry").then(
      (m) => (m.default ?? m) as ServerEntry,
    );
  }
  return serverEntryPromise;
}

// h3 swallows in-handler throws into a normal 500 Response with body
// {"unhandled":true,"message":"HTTPError"} — try/catch alone never fires for those.
async function normalizeCatastrophicSsrResponse(response: Response): Promise<Response> {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;

  const body = await response.clone().text();
  if (!isH3SwallowedErrorBody(body)) return response;

  console.error(consumeLastCapturedError() ?? new Error(`h3 swallowed SSR error: ${body}`));
  return new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" },
  });
}

function isH3SwallowedErrorBody(body: string): boolean {
  try {
    const payload = JSON.parse(body) as { unhandled?: unknown; message?: unknown };
    return payload.unhandled === true && payload.message === "HTTPError";
  } catch {
    return false;
  }
}

export default {
  async fetch(request: Request, env: unknown, ctx: unknown) {
    try {
      const handler = await getServerEntry();
      const response = await handler.fetch(request, env, ctx);
      return await normalizeCatastrophicSsrResponse(response);
    } catch (error) {
      console.error(error);
      return new Response(renderErrorPage(), {
        status: 500,
        headers: { "content-type": "text/html; charset=utf-8" },
      });
    }
  },
};

```

## FILE 101: src/services/analytics.ts

```ts
import { COURSES, DISTRICTS, PROVIDERS, SKILL_DEMAND } from "@/data/seed";
import type { EmploymentStatus, Filters, Trainee } from "@/types";

export const EMPTY_FILTERS: Filters = {
  district: "all",
  courseId: "all",
  providerId: "all",
  gender: "all",
  ageGroup: "all",
  trainingYear: "all",
  employmentStatus: "all",
};

export const AGE_GROUPS = ["18-21", "22-25", "26-30", "31+"];

function inAgeGroup(age: number, group: string) {
  if (group === "18-21") return age <= 21;
  if (group === "22-25") return age >= 22 && age <= 25;
  if (group === "26-30") return age >= 26 && age <= 30;
  return age >= 31;
}

export function applyFilters(trainees: Trainee[], f: Filters): Trainee[] {
  return trainees.filter(
    (t) =>
      (f.district === "all" || t.district === f.district) &&
      (f.courseId === "all" || t.courseId === f.courseId) &&
      (f.providerId === "all" || t.providerId === f.providerId) &&
      (f.gender === "all" || t.gender === f.gender) &&
      (f.ageGroup === "all" || inAgeGroup(t.age, f.ageGroup)) &&
      (f.trainingYear === "all" || String(t.trainingYear) === f.trainingYear) &&
      (f.employmentStatus === "all" || t.employmentStatus === f.employmentStatus),
  );
}

const PLACED: EmploymentStatus[] = ["Employed", "Self-employed", "Apprenticeship"];

export function pct(part: number, total: number) {
  if (!total) return 0;
  return Math.round((part / total) * 1000) / 10;
}

export function avg(values: number[]) {
  if (!values.length) return 0;
  return Math.round(values.reduce((a, b) => a + b, 0) / values.length);
}

export function salaryOf(t: Trainee) {
  return t.employment.salary ?? t.employment.monthlyIncome ?? 0;
}

export function isPlaced(t: Trainee) {
  return PLACED.includes(t.employmentStatus);
}

export function retentionAt(trainees: Trainee[], milestone: "3 months" | "6 months" | "12 months") {
  const relevant = trainees.flatMap((t) =>
    t.followUps.filter((f) => f.milestone === milestone && f.status === "Completed"),
  );
  if (!relevant.length) return 0;
  const retained = relevant.filter(
    (f) => f.employmentStatus && PLACED.includes(f.employmentStatus),
  ).length;
  return pct(retained, relevant.length);
}

export function kpis(trainees: Trainee[]) {
  const total = trainees.length;
  const completed = trainees.filter((t) => t.trainingStatus === "Completed").length;
  const employed = trainees.filter((t) => t.employmentStatus === "Employed").length;
  const self = trainees.filter((t) => t.employmentStatus === "Self-employed").length;
  const appr = trainees.filter((t) => t.employmentStatus === "Apprenticeship").length;
  return {
    total,
    completed,
    completionRate: pct(completed, total),
    employmentRate: pct(employed + self + appr, total),
    employedRate: pct(employed, total),
    selfRate: pct(self, total),
    apprRate: pct(appr, total),
    retention12: retentionAt(trainees, "12 months"),
    avgSalary: avg(trainees.filter(isPlaced).map(salaryOf).filter(Boolean)),
    certified: trainees.filter((t) => t.certified).length,
  };
}

export function outcomeBreakdown(trainees: Trainee[]) {
  const statuses: EmploymentStatus[] = [
    "Employed",
    "Self-employed",
    "Apprenticeship",
    "Seeking Employment",
    "Further Education",
    "Unreachable",
  ];
  return statuses.map((s) => ({
    name: s,
    value: trainees.filter((t) => t.employmentStatus === s).length,
  }));
}

export function districtStats(trainees: Trainee[]) {
  return DISTRICTS.map((d) => {
    const list = trainees.filter((t) => t.district === d);
    return {
      district: d,
      trainees: list.length,
      employmentRate: pct(list.filter(isPlaced).length, list.length),
      retention: retentionAt(list, "6 months"),
      avgSalary: avg(list.filter(isPlaced).map(salaryOf).filter(Boolean)),
    };
  }).filter((d) => d.trainees > 0);
}

export function courseStats(trainees: Trainee[]) {
  return COURSES.map((c) => {
    const list = trainees.filter((t) => t.courseId === c.id);
    const completed = list.filter((t) => t.trainingStatus === "Completed");
    return {
      courseId: c.id,
      course: c.name,
      sector: c.sector,
      trainees: list.length,
      completionRate: pct(completed.length, list.length),
      certificationRate: pct(list.filter((t) => t.certified).length, list.length),
      placementRate: pct(list.filter(isPlaced).length, list.length),
      selfRate: pct(list.filter((t) => t.employmentStatus === "Self-employed").length, list.length),
      apprRate: pct(list.filter((t) => t.employmentStatus === "Apprenticeship").length, list.length),
      avgSalary: avg(list.filter(isPlaced).map(salaryOf).filter(Boolean)),
      retention3: retentionAt(list, "3 months"),
      retention6: retentionAt(list, "6 months"),
      retention12: retentionAt(list, "12 months"),
      traineeSatisfaction: list.length
        ? Math.round((list.reduce((a, t) => a + t.satisfaction, 0) / list.length) * 10) / 10
        : 0,
    };
  }).filter((c) => c.trainees > 0);
}

export function providerStats(trainees: Trainee[]) {
  return PROVIDERS.map((p) => {
    const list = trainees.filter((t) => t.providerId === p.id);
    return {
      providerId: p.id,
      provider: p.name,
      district: p.district,
      accreditation: p.accreditation,
      rating: p.rating,
      programs: p.courses.length,
      trainees: list.length,
      completionRate: pct(list.filter((t) => t.trainingStatus === "Completed").length, list.length),
      employmentRate: pct(list.filter(isPlaced).length, list.length),
      avgSalary: avg(list.filter(isPlaced).map(salaryOf).filter(Boolean)),
      retention: retentionAt(list, "6 months"),
    };
  }).filter((p) => p.trainees > 0);
}

export function salaryProgressionAvg(trainees: Trainee[]) {
  const points = ["Joining", "3 months", "6 months", "12 months"];
  return points.map((point) => ({
    point,
    salary: avg(
      trainees
        .flatMap((t) => t.salaryProgression.filter((p) => p.point === point))
        .map((p) => p.salary),
    ),
  }));
}

export function retentionTrend(trainees: Trainee[]) {
  return (["3 months", "6 months", "12 months"] as const).map((m) => ({
    milestone: m,
    retention: retentionAt(trainees, m),
  }));
}

export function nonPlacementReasons(trainees: Trainee[]) {
  const map = new Map<string, number>();
  trainees
    .filter((t) => !isPlaced(t) && t.nonPlacementReason)
    .forEach((t) => map.set(t.nonPlacementReason!, (map.get(t.nonPlacementReason!) ?? 0) + 1));
  return [...map.entries()]
    .map(([reason, count]) => ({ reason, count }))
    .sort((a, b) => b.count - a.count);
}

export function skillGaps() {
  return SKILL_DEMAND.map((s) => {
    const gap = s.demand - s.coverage;
    return {
      ...s,
      gap,
      severity: gap >= 20 ? "High" : gap >= 8 ? "Medium" : "Low",
    };
  }).sort((a, b) => b.gap - a.gap);
}

export function skillInsights() {
  const gaps = skillGaps();
  const top = gaps[0]!;
  return {
    insight: `${top.skill} is currently one of the largest skill gaps, with ${top.demand}% employer demand against ${top.coverage}% training coverage.`,
    action: `Increase ${top.skill} modules and practical assessments in relevant training programs.`,
    highCount: gaps.filter((g) => g.severity === "High").length,
  };
}

export function pendingFollowUps(trainees: Trainee[]) {
  return trainees
    .flatMap((t) =>
      t.followUps.map((f) => ({
        traineeId: t.id,
        traineeName: t.name,
        district: t.district,
        courseId: t.courseId,
        followUp: f,
      })),
    )
    .sort((a, b) => a.followUp.dueDate.localeCompare(b.followUp.dueDate));
}

export function formatINR(value: number) {
  if (!value) return "—";
  return `₹${value.toLocaleString("en-IN")}`;
}

```

## FILE 102: src/services/store.tsx

```tsx
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

import { COURSES, EMPLOYERS, PROVIDERS, generateTrainees } from "@/data/seed";
import type {
  Course,
  Employer,
  Employment,
  EmploymentStatus,
  FollowUp,
  NonPlacementReason,
  Provider,
  Trainee,
} from "@/types";

const STORAGE_KEY = "mahaskilltrack:data:v1";

export interface OutcomeUpdate {
  employmentStatus: EmploymentStatus;
  employment?: Employment;
  nonPlacementReason?: NonPlacementReason | undefined;
}

interface StoreValue {
  ready: boolean;
  trainees: Trainee[];
  courses: Course[];
  providers: Provider[];
  employers: Employer[];
  getTrainee: (id: string) => Trainee | undefined;
  courseName: (id: string) => string;
  providerName: (id: string) => string;
  updateOutcome: (traineeId: string, update: OutcomeUpdate) => void;
  recordFollowUp: (traineeId: string, followUpId: string, data: Partial<FollowUp>) => void;
  verifyEmployment: (traineeId: string) => void;
  resetData: () => void;
}

const StoreContext = createContext<StoreValue | null>(null);

function withTimeline(t: Trainee): Trainee {
  const placed = ["Employed", "Self-employed", "Apprenticeship"].includes(t.employmentStatus);
  const timeline = t.timeline.map((e) =>
    e.id === "employment"
      ? {
          ...e,
          label: placed ? t.employmentStatus : "Awaiting Placement",
          date: placed ? (t.employment.joiningDate ?? t.employment.businessStartDate ?? "—") : "—",
          status: placed ? ("done" as const) : ("current" as const),
          detail: placed
            ? `${t.employment.jobTitle ?? t.employment.businessType ?? "Outcome"} — recorded in the outcome registry.`
            : `Current status: ${t.employmentStatus}.`,
        }
      : e,
  );
  return { ...t, timeline };
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [trainees, setTrainees] = useState<Trainee[]>(() => generateTrainees());
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setTrainees(JSON.parse(raw) as Trainee[]);
    } catch {
      /* ignore corrupt cache and keep seeded data */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(trainees));
    } catch {
      /* storage may be unavailable */
    }
  }, [trainees, ready]);

  const updateOutcome = useCallback((traineeId: string, update: OutcomeUpdate) => {
    setTrainees((prev) =>
      prev.map((t) => {
        if (t.id !== traineeId) return t;
        const employment: Employment = { ...t.employment, ...(update.employment ?? {}) };
        const salary = employment.salary ?? employment.monthlyIncome;
        const salaryProgression =
          salary && t.salaryProgression.length === 0
            ? [{ point: "Joining", salary }]
            : salary
              ? t.salaryProgression.map((p, i) =>
                  i === t.salaryProgression.length - 1 ? { ...p, salary } : p,
                )
              : t.salaryProgression;
        return withTimeline({
          ...t,
          employmentStatus: update.employmentStatus,
          nonPlacementReason: update.nonPlacementReason,
          employment,
          salaryProgression,
          contactReachable: update.employmentStatus !== "Unreachable",
        });
      }),
    );
  }, []);

  const recordFollowUp = useCallback(
    (traineeId: string, followUpId: string, data: Partial<FollowUp>) => {
      setTrainees((prev) =>
        prev.map((t) => {
          if (t.id !== traineeId) return t;
          const followUps = t.followUps.map((f) => (f.id === followUpId ? { ...f, ...data } : f));
          const updated = followUps.find((f) => f.id === followUpId);
          const salaryProgression =
            updated?.status === "Completed" && updated.salary
              ? [
                  ...t.salaryProgression.filter((p) => p.point !== updated.milestone),
                  { point: updated.milestone, salary: updated.salary },
                ]
              : t.salaryProgression;
          return withTimeline({
            ...t,
            followUps,
            salaryProgression,
            timeline: t.timeline.map((e) =>
              e.id === `fu-${updated?.milestone}`
                ? {
                    ...e,
                    date: updated?.completedDate ?? e.date,
                    status: updated?.status === "Completed" ? "done" : e.status,
                    detail:
                      updated?.status === "Completed"
                        ? `${updated.employmentStatus ?? t.employmentStatus}${updated.salary ? ` · ₹${updated.salary.toLocaleString("en-IN")}/month` : ""}`
                        : `${updated?.status ?? e.status} — due ${updated?.dueDate ?? ""}`,
                  }
                : e,
            ),
          });
        }),
      );
    },
    [],
  );

  const verifyEmployment = useCallback((traineeId: string) => {
    setTrainees((prev) =>
      prev.map((t) =>
        t.id === traineeId ? { ...t, employment: { ...t.employment, verified: true } } : t,
      ),
    );
  }, []);

  const resetData = useCallback(() => {
    setTrainees(generateTrainees());
  }, []);

  const value = useMemo<StoreValue>(
    () => ({
      ready,
      trainees,
      courses: COURSES,
      providers: PROVIDERS,
      employers: EMPLOYERS,
      getTrainee: (id) => trainees.find((t) => t.id === id),
      courseName: (id) => COURSES.find((c) => c.id === id)?.name ?? id,
      providerName: (id) => PROVIDERS.find((p) => p.id === id)?.name ?? id,
      updateOutcome,
      recordFollowUp,
      verifyEmployment,
      resetData,
    }),
    [ready, trainees, updateOutcome, recordFollowUp, verifyEmployment, resetData],
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used inside StoreProvider");
  return ctx;
}

```

## FILE 103: src/start.ts

```ts
import { createStart, createCsrfMiddleware, createMiddleware } from "@tanstack/react-start";

import { renderErrorPage } from "./lib/error-page";

const errorMiddleware = createMiddleware().server(async ({ next }) => {
  try {
    return await next();
  } catch (error) {
    if (error != null && typeof error === "object" && "statusCode" in error) {
      throw error;
    }
    console.error(error);
    return new Response(renderErrorPage(), {
      status: 500,
      headers: { "content-type": "text/html; charset=utf-8" },
    });
  }
});

// Start installs this automatically when src/start.ts is absent; defining the
// file opts out, so re-add it explicitly to keep server functions protected
// from cross-site requests.
const csrfMiddleware = createCsrfMiddleware({
  filter: (ctx) => ctx.handlerType === "serverFn",
});

export const startInstance = createStart(() => ({
  requestMiddleware: [errorMiddleware, csrfMiddleware],
}));

```

## FILE 104: src/utils/export.ts

```ts
export function toCsv(rows: Record<string, string | number>[]): string {
  if (!rows.length) return "";
  const headers = Object.keys(rows[0]!);
  const escape = (v: string | number) => {
    const s = String(v ?? "");
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [headers.join(","), ...rows.map((r) => headers.map((h) => escape(r[h] ?? "")).join(","))].join(
    "\n",
  );
}

export function downloadCsv(filename: string, rows: Record<string, string | number>[]) {
  const blob = new Blob([toCsv(rows)], { type: "text/csv;charset=utf-8;" });
  triggerDownload(blob, filename.endsWith(".csv") ? filename : `${filename}.csv`);
}

export function downloadPrintableReport(
  title: string,
  subtitle: string,
  rows: Record<string, string | number>[],
) {
  const headers = rows.length ? Object.keys(rows[0]!) : [];
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title>
<style>
body{font-family:system-ui,-apple-system,Segoe UI,sans-serif;padding:40px;color:#1e293b}
h1{margin:0 0 4px;font-size:22px;color:#1e3a5f}
p.sub{margin:0 0 24px;color:#64748b;font-size:13px}
table{width:100%;border-collapse:collapse;font-size:12px}
th,td{border:1px solid #e2e8f0;padding:8px 10px;text-align:left}
th{background:#1e3a5f;color:#fff;text-transform:uppercase;font-size:10px;letter-spacing:.05em}
tr:nth-child(even) td{background:#f8fafc}
footer{margin-top:28px;font-size:11px;color:#94a3b8}
</style></head><body>
<h1>MahaSkillTrack — ${title}</h1>
<p class="sub">${subtitle}</p>
<table><thead><tr>${headers.map((h) => `<th>${h}</th>`).join("")}</tr></thead>
<tbody>${rows
    .map((r) => `<tr>${headers.map((h) => `<td>${String(r[h] ?? "")}</td>`).join("")}</tr>`)
    .join("")}</tbody></table>
<footer>Generated by MahaSkillTrack · Maharashtra Skill Development Outcome Intelligence · Aggregated data, no personal contact details included.</footer>
</body></html>`;
  const blob = new Blob([html], { type: "text/html;charset=utf-8;" });
  triggerDownload(blob, `${title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}.html`);
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

```

## INSTALLATION AND RUN

```bash
bun install      # or: npm install
bun run dev      # or: npm run dev   -> http://localhost:8080
bun run build    # production build
```

Note: `src/routeTree.gen.ts` is generated automatically by the TanStack Router Vite plugin from files in `src/routes/`. It is included for completeness but will be regenerated on first `dev`/`build`.

Demo accounts (password `demo1234`): admin@mahaskill.demo, provider@mahaskill.demo, trainee@mahaskill.demo, employer@mahaskill.demo

No environment variables are required; all data is synthetic and stored in localStorage.
