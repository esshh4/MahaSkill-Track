import { createFileRoute } from "@tanstack/react-router";
import { Briefcase } from "lucide-react";

import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useScope } from "@/hooks/use-scope";
import { formatINR, salaryOf } from "@/services/analytics";
import { useStore } from "@/services/store";

export const Route = createFileRoute("/app/employers")({
  head: () => ({
    meta: [
      { title: "Employers — MahaSkillTrack" },
      { name: "description", content: "Partner employers, hiring volumes, verification status and skill requirements feedback." },
      { property: "og:title", content: "Employer Network — MahaSkillTrack" },
      { property: "og:description", content: "Employer hiring records and skill requirement feedback." },
    ],
  }),
  component: EmployersPage,
});

function EmployersPage() {
  const { employers, trainees } = useStore();
  const scope = useScope();
  const visible = scope.role === "employer" ? employers.filter((e) => scope.trainees.some((t) => t.employment.employerId === e.id)) : employers;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Employer network"
        description="Who is hiring skilled trainees, and what skills do they still find missing?"
      />
      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {visible.map((e) => {
          const hires = trainees.filter((t) => t.employment.employerId === e.id);
          const avg = hires.length
            ? Math.round(hires.reduce((a, t) => a + salaryOf(t), 0) / hires.length)
            : 0;
          return (
            <Card key={e.id}>
              <CardHeader className="flex flex-row items-start justify-between gap-3">
                <div>
                  <CardTitle className="text-base">{e.name}</CardTitle>
                  <CardDescription>
                    {e.sector} · {e.district}
                  </CardDescription>
                </div>
                <StatusBadge status={e.status} />
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <p className="flex items-center gap-2 text-muted-foreground">
                  <Briefcase className="size-4" aria-hidden />
                  {hires.length} trainees hired · {formatINR(avg)} average salary
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {e.skillRequirements.map((s) => (
                    <Badge key={s} variant="secondary">
                      {s}
                    </Badge>
                  ))}
                </div>
                <p className="rounded-lg bg-muted/60 p-3 text-xs text-muted-foreground">"{e.feedback}"</p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
