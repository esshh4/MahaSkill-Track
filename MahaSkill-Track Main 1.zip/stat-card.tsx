import { TrendingDown, TrendingUp } from "lucide-react";
import type { LucideIcon } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export interface StatCardProps {
  label: string;
  value: string;
  description: string;
  icon: LucideIcon;
  change?: number;
  accent?: "navy" | "saffron" | "success" | "info";
}

const ACCENTS = {
  navy: "bg-primary/10 text-primary",
  saffron: "bg-accent/15 text-accent-foreground",
  success: "bg-success/10 text-success",
  info: "bg-info/10 text-info",
};

export function StatCard({
  label,
  value,
  description,
  icon: Icon,
  change,
  accent = "navy",
}: StatCardProps) {
  const positive = (change ?? 0) >= 0;
  const Trend = positive ? TrendingUp : TrendingDown;
  return (
    <Card className="group relative overflow-hidden transition-shadow hover:shadow-md">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="truncate text-sm font-medium text-muted-foreground">{label}</p>
            <p className="mt-2 text-2xl font-semibold tracking-tight text-foreground sm:text-3xl">
              {value}
            </p>
          </div>
          <span className={cn("grid size-10 shrink-0 place-items-center rounded-xl", ACCENTS[accent])}>
            <Icon className="size-5" aria-hidden />
          </span>
        </div>
        <div className="mt-3 flex items-center gap-2 text-xs">
          {change !== undefined ? (
            <span
              className={cn(
                "inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 font-medium",
                positive ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive",
              )}
            >
              <Trend className="size-3" aria-hidden />
              {positive ? "+" : ""}
              {change}%
            </span>
          ) : null}
          <span className="truncate text-muted-foreground">{description}</span>
        </div>
      </CardContent>
    </Card>
  );
}
