import { Link, createFileRoute, useParams } from "@tanstack/react-router";
import {
  ArrowLeft,
  Award,
  BadgeCheck,
  Building2,
  CalendarClock,
  Download,
  GraduationCap,
  IndianRupee,
  MapPin,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/common/page-header";
import { EmptyState } from "@/components/common/states";
import { StatusBadge } from "@/components/common/status-badge";
import { Timeline } from "@/components/common/timeline";
import { SalaryLine } from "@/components/charts/dashboard-charts";
import { FollowUpDialog } from "@/components/forms/follow-up-dialog";
import { OutcomeDialog } from "@/components/forms/outcome-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useScope } from "@/hooks/use-scope";
import { formatINR } from "@/services/analytics";
import { useStore } from "@/services/store";
import { downloadPrintableReport } from "@/utils/export";

export const Route = createFileRoute("/app/trainees/$traineeId")({
  head: () => ({
    meta: [
      { title: "Trainee profile — MahaSkillTrack" },
      {
        name: "description",
        content:
          "Full trainee journey: training record, certification, employment outcome, salary progression and follow-up history.",
      },
      { property: "og:title", content: "Trainee Journey — MahaSkillTrack" },
      {
        property: "og:description",
        content: "Individual outcome record with timeline, follow-ups and verification status.",
      },
    ],
  }),
  component: TraineeProfile,
});

function TraineeProfile() {
  const { traineeId } = useParams({ from: "/app/trainees/$traineeId" });
  const { getTrainee, courseName, providerName, courses, verifyEmployment } = useStore();
  const scope = useScope();
  const [outcomeOpen, setOutcomeOpen] = useState(false);
  const [followUpId, setFollowUpId] = useState<string | null>(null);

  const t = getTrainee(traineeId);

  if (!t) {
    return (
      <EmptyState
        title="Trainee not found"
        description={`No record exists for ID ${traineeId}.`}
        action={
          <Button asChild variant="outline">
            <Link to="/app/trainees">Back to registry</Link>
          </Button>
        }
      />
    );
  }

  const course = courses.find((c) => c.id === t.courseId);
  const first = t.salaryProgression[0]?.salary ?? 0;
  const latest = t.salaryProgression.at(-1)?.salary ?? 0;
  const growth = first ? Math.round(((latest - first) / first) * 100) : 0;
  const canEdit = scope.canEdit;

  return (
    <div className="space-y-6">
      <Button variant="ghost" size="sm" asChild className="-ml-2">
        <Link to="/app/trainees">
          <ArrowLeft className="mr-1.5 size-4" aria-hidden />
          Back to registry
        </Link>
      </Button>

      <PageHeader
        title={t.name}
        description={`${t.id} · ${t.age} years · ${t.gender} · ${t.education} · ${t.district} district`}
        actions={
          <>
            <StatusBadge status={t.employmentStatus} />
            <Button
              variant="outline"
              onClick={() =>
                downloadPrintableReport(
                  `Trainee Outcome Record ${t.id}`,
                  `${t.name} · ${courseName(t.courseId)} · ${providerName(t.providerId)}`,
                  [
                    { Field: "Trainee ID", Value: t.id },
                    { Field: "District", Value: t.district },
                    { Field: "Course", Value: courseName(t.courseId) },
                    { Field: "Provider", Value: providerName(t.providerId) },
                    { Field: "Training status", Value: t.trainingStatus },
                    { Field: "Certified", Value: t.certified ? "Yes" : "No" },
                    { Field: "Employment status", Value: t.employmentStatus },
                    { Field: "Employer", Value: t.employment.employerName ?? "—" },
                    { Field: "Current income", Value: formatINR(latest) },
                    { Field: "Salary growth", Value: `${growth}%` },
                  ],
                )
              }
            >
              <Download className="mr-2 size-4" aria-hidden />
              Export record
            </Button>
            {canEdit ? <Button onClick={() => setOutcomeOpen(true)}>Update outcome</Button> : null}
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MiniStat
          icon={GraduationCap}
          label="Training"
          value={t.trainingStatus}
          sub={`${t.startDate} → ${t.endDate}`}
        />
        <MiniStat
          icon={Award}
          label="Assessment"
          value={`${t.assessmentScore}/100`}
          sub={`Attendance ${t.attendance}%`}
        />
        <MiniStat
          icon={IndianRupee}
          label="Current income"
          value={formatINR(latest)}
          sub={growth ? `${growth > 0 ? "+" : ""}${growth}% since joining` : "No income recorded"}
        />
        <MiniStat
          icon={ShieldCheck}
          label="Consent"
          value={t.consent}
          sub={`Recorded ${t.consentDate}`}
        />
      </div>

      <Tabs defaultValue="journey">
        <TabsList className="flex-wrap">
          <TabsTrigger value="journey">Journey</TabsTrigger>
          <TabsTrigger value="training">Training</TabsTrigger>
          <TabsTrigger value="employment">Employment</TabsTrigger>
          <TabsTrigger value="followups">Follow-ups</TabsTrigger>
          <TabsTrigger value="privacy">Privacy</TabsTrigger>
        </TabsList>

        <TabsContent value="journey" className="mt-5 grid gap-5 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Career timeline</CardTitle>
              <CardDescription>Enrollment through the latest verified milestone</CardDescription>
            </CardHeader>
            <CardContent>
              <Timeline events={t.timeline} />
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Salary progression</CardTitle>
              <CardDescription>Reported monthly income at each milestone</CardDescription>
            </CardHeader>
            <CardContent>
              {t.salaryProgression.length ? (
                <SalaryLine data={t.salaryProgression} height={260} />
              ) : (
                <EmptyState
                  title="No income data"
                  description="Income appears once an employment outcome is recorded."
                />
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="training" className="mt-5 grid gap-5 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Training record</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <Row label="Course" value={courseName(t.courseId)} />
              <Row label="Sector" value={course?.sector ?? "—"} />
              <Row label="Duration" value={`${course?.durationWeeks ?? "—"} weeks`} />
              <Row label="Provider" value={providerName(t.providerId)} />
              <Row label="Centre" value={t.trainingCenter} />
              <Row label="Batch year" value={String(t.trainingYear)} />
              <Row label="Certified" value={t.certified ? "Yes" : "No"} />
              <div className="pt-2">
                <p className="mb-1.5 text-xs text-muted-foreground">Attendance</p>
                <Progress value={t.attendance} />
              </div>
              <div className="pt-1">
                <p className="mb-1.5 text-xs text-muted-foreground">Assessment score</p>
                <Progress value={t.assessmentScore} />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Sparkles className="size-4 text-accent-foreground" aria-hidden />
                Skills acquired
              </CardTitle>
              <CardDescription>Curriculum skills mapped to employer demand</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-wrap gap-2">
              {(course?.skills ?? []).map((s) => (
                <Badge key={s} variant="secondary">
                  {s}
                </Badge>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="employment" className="mt-5 grid gap-5 lg:grid-cols-2">
          <Card>
            <CardHeader className="flex flex-row items-start justify-between gap-3">
              <div>
                <CardTitle className="text-base">Employment details</CardTitle>
                <CardDescription>Current recorded outcome</CardDescription>
              </div>
              {t.employment.verified ? (
                <StatusBadge status="Verified" />
              ) : (
                <StatusBadge status="Pending Verification" />
              )}
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <Row label="Status" value={t.employmentStatus} />
              <Row label="Employer" value={t.employment.employerName ?? "—"} />
              <Row label="Job title" value={t.employment.jobTitle ?? t.employment.businessType ?? "—"} />
              <Row label="Employment type" value={t.employment.employmentType ?? "—"} />
              <Row
                label="Start date"
                value={t.employment.joiningDate ?? t.employment.businessStartDate ?? "—"}
              />
              <Row label="Location" value={t.employment.location ?? "—"} />
              <Row
                label="Income"
                value={formatINR(t.employment.salary ?? t.employment.monthlyIncome ?? 0)}
              />
              {t.nonPlacementReason ? (
                <Row label="Reason not placed" value={t.nonPlacementReason} />
              ) : null}
              {!t.employment.verified && t.employment.employerName ? (
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-2 w-full"
                  onClick={() => {
                    verifyEmployment(t.id);
                    toast.success("Employment verified", {
                      description: `${t.name}'s placement is now marked as employer-verified.`,
                    });
                  }}
                >
                  <BadgeCheck className="mr-1.5 size-4" aria-hidden />
                  Verify employment
                </Button>
              ) : null}
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Placement context</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <p className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="size-4" aria-hidden />
                Home district: {t.district}
              </p>
              <p className="flex items-center gap-2 text-muted-foreground">
                <Building2 className="size-4" aria-hidden />
                Training provider: {providerName(t.providerId)}
              </p>
              <p className="flex items-center gap-2 text-muted-foreground">
                <CalendarClock className="size-4" aria-hidden />
                Training completed: {t.endDate}
              </p>
              <p className="rounded-lg bg-muted/60 p-3 text-xs">
                Trainee satisfaction rating: <strong>{t.satisfaction}/5</strong>. Contact status:{" "}
                <strong>{t.contactReachable ? "Reachable" : "Unreachable"}</strong>.
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="followups" className="mt-5">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Follow-up milestones</CardTitle>
              <CardDescription>3, 6 and 12-month outcome verification</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {t.followUps.map((f) => (
                <div
                  key={f.id}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-3"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-medium">{f.milestone} follow-up</p>
                    <p className="text-xs text-muted-foreground">
                      {f.status === "Completed"
                        ? `Recorded ${f.completedDate} · ${f.employmentStatus ?? "—"}${f.salary ? ` · ${formatINR(f.salary)}` : ""}`
                        : `Due ${f.dueDate}`}
                    </p>
                    {f.notes ? <p className="mt-1 text-xs text-muted-foreground">{f.notes}</p> : null}
                  </div>
                  <div className="flex items-center gap-2">
                    <StatusBadge status={f.status} />
                    {canEdit ? (
                      <Button variant="outline" size="sm" onClick={() => setFollowUpId(f.id)}>
                        {f.status === "Completed" ? "Edit" : "Record"}
                      </Button>
                    ) : null}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="privacy" className="mt-5">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Consent and data sharing</CardTitle>
              <CardDescription>
                Personal contact details are never shown on analytics screens.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <Row label="Consent status" value={t.consent} />
              <Row label="Consent recorded" value={t.consentDate} />
              <Row label="Share with analytics" value={t.dataSharing.analytics ? "Allowed" : "Denied"} />
              <Row label="Share with employers" value={t.dataSharing.employers ? "Allowed" : "Denied"} />
              <Row label="Share for research" value={t.dataSharing.research ? "Allowed" : "Denied"} />
              <p className="mt-3 rounded-lg bg-muted/60 p-3 text-xs text-muted-foreground">
                All names and identifiers in this demo are synthetic. Aggregated reports exclude
                contact information entirely.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <OutcomeDialog trainee={t} open={outcomeOpen} onOpenChange={setOutcomeOpen} />
      <FollowUpDialog
        trainee={t}
        followUpId={followUpId}
        onClose={() => setFollowUpId(null)}
      />
    </div>
  );
}

function MiniStat({
  icon: Icon,
  label,
  value,
  sub,
}: {
  icon: typeof Award;
  label: string;
  value: string;
  sub: string;
}) {
  return (
    <Card>
      <CardContent className="flex items-start gap-3 p-4">
        <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
          <Icon className="size-5" aria-hidden />
        </span>
        <span className="min-w-0">
          <span className="block text-xs text-muted-foreground">{label}</span>
          <span className="block truncate text-sm font-semibold">{value}</span>
          <span className="block truncate text-xs text-muted-foreground">{sub}</span>
        </span>
      </CardContent>
    </Card>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-border/60 pb-1.5 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{value}</span>
    </div>
  );
}
