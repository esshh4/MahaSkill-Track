import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const AXIS = { fontSize: 12, fill: "var(--muted-foreground)" };

const TOOLTIP_STYLE = {
  contentStyle: {
    borderRadius: 12,
    border: "1px solid var(--border)",
    background: "var(--card)",
    fontSize: 12,
    color: "var(--foreground)",
  },
} as const;

export const OUTCOME_COLORS: Record<string, string> = {
  Employed: "var(--success)",
  "Self-employed": "var(--saffron)",
  Apprenticeship: "var(--info)",
  "Seeking Employment": "var(--warning)",
  "Further Education": "var(--chart-1)",
  Unreachable: "var(--destructive)",
};

export function OutcomeDonut({ data }: { data: { name: string; value: number }[] }) {
  const total = data.reduce((a, d) => a + d.value, 0);
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            innerRadius="55%"
            outerRadius="82%"
            paddingAngle={2}
            stroke="var(--card)"
          >
            {data.map((d) => (
              <Cell key={d.name} fill={OUTCOME_COLORS[d.name] ?? "var(--chart-1)"} />
            ))}
          </Pie>
          <Tooltip
            {...TOOLTIP_STYLE}
            formatter={(value: number, name) => [
              `${value} trainees (${total ? Math.round((value / total) * 100) : 0}%)`,
              name as string,
            ]}
          />
          <Legend wrapperStyle={{ fontSize: 12 }} iconType="circle" />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

export function DistrictBars({
  data,
}: {
  data: { district: string; employmentRate: number; avgSalary: number }[];
}) {
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ left: -18, right: 8, top: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
          <XAxis dataKey="district" tick={AXIS} interval={0} angle={-25} textAnchor="end" height={54} />
          <YAxis tick={AXIS} unit="%" />
          <Tooltip {...TOOLTIP_STYLE} formatter={(v: number) => [`${v}%`, "Employment rate"]} />
          <Bar dataKey="employmentRate" fill="var(--chart-1)" radius={[6, 6, 0, 0]} maxBarSize={44} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function RetentionLine({ data }: { data: { milestone: string; retention: number }[] }) {
  return (
    <div className="h-[280px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ left: -18, right: 12, top: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
          <XAxis dataKey="milestone" tick={AXIS} />
          <YAxis tick={AXIS} unit="%" domain={[0, 100]} />
          <Tooltip {...TOOLTIP_STYLE} formatter={(v: number) => [`${v}%`, "Retention"]} />
          <Line
            type="monotone"
            dataKey="retention"
            stroke="var(--success)"
            strokeWidth={2.5}
            dot={{ r: 4, fill: "var(--success)" }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function SalaryLine({
  data,
  height = 280,
}: {
  data: { point: string; salary: number }[];
  height?: number;
}) {
  return (
    <div style={{ height }} className="w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ left: 4, right: 12, top: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
          <XAxis dataKey="point" tick={AXIS} />
          <YAxis tick={AXIS} tickFormatter={(v: number) => `₹${Math.round(v / 1000)}k`} />
          <Tooltip
            {...TOOLTIP_STYLE}
            formatter={(v: number) => [`₹${v.toLocaleString("en-IN")}`, "Average salary"]}
          />
          <Line
            type="monotone"
            dataKey="salary"
            stroke="var(--saffron)"
            strokeWidth={2.5}
            dot={{ r: 4, fill: "var(--saffron)" }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function SkillGapBars({
  data,
}: {
  data: { skill: string; demand: number; coverage: number }[];
}) {
  return (
    <div className="h-[360px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ left: 30, right: 16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
          <XAxis type="number" tick={AXIS} unit="%" domain={[0, 100]} />
          <YAxis type="category" dataKey="skill" tick={AXIS} width={110} />
          <Tooltip {...TOOLTIP_STYLE} formatter={(v: number, n) => [`${v}%`, n as string]} />
          <Legend wrapperStyle={{ fontSize: 12 }} iconType="circle" />
          <Bar name="Employer demand" dataKey="demand" fill="var(--chart-1)" radius={[0, 5, 5, 0]} />
          <Bar name="Training coverage" dataKey="coverage" fill="var(--saffron)" radius={[0, 5, 5, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function CourseComparisonBars({
  data,
}: {
  data: { course: string; placementRate: number; retention12: number }[];
}) {
  return (
    <div className="h-[340px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ left: -18, right: 8, top: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
          <XAxis dataKey="course" tick={AXIS} interval={0} angle={-20} textAnchor="end" height={70} />
          <YAxis tick={AXIS} unit="%" />
          <Tooltip {...TOOLTIP_STYLE} formatter={(v: number, n) => [`${v}%`, n as string]} />
          <Legend wrapperStyle={{ fontSize: 12 }} iconType="circle" />
          <Bar name="Placement rate" dataKey="placementRate" fill="var(--chart-1)" radius={[5, 5, 0, 0]} />
          <Bar name="12-month retention" dataKey="retention12" fill="var(--success)" radius={[5, 5, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function ReasonBars({ data }: { data: { reason: string; count: number }[] }) {
  return (
    <div className="h-[320px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ left: 60, right: 16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
          <XAxis type="number" tick={AXIS} allowDecimals={false} />
          <YAxis type="category" dataKey="reason" tick={{ ...AXIS, fontSize: 11 }} width={150} />
          <Tooltip {...TOOLTIP_STYLE} formatter={(v: number) => [`${v} trainees`, "Reported"]} />
          <Bar dataKey="count" fill="var(--destructive)" radius={[0, 5, 5, 0]} maxBarSize={26} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
