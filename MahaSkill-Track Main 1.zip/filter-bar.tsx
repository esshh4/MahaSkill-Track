import { RotateCcw, SlidersHorizontal } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DISTRICTS } from "@/data/seed";
import { AGE_GROUPS, EMPTY_FILTERS } from "@/services/analytics";
import { useStore } from "@/services/store";
import type { Filters } from "@/types";

const STATUSES = [
  "Employed",
  "Self-employed",
  "Apprenticeship",
  "Seeking Employment",
  "Further Education",
  "Unreachable",
];

export function FilterBar({
  filters,
  onChange,
  hideProvider = false,
}: {
  filters: Filters;
  onChange: (f: Filters) => void;
  hideProvider?: boolean;
}) {
  const { courses, providers } = useStore();
  const set = (key: keyof Filters, value: string) => onChange({ ...filters, [key]: value });
  const active = Object.entries(filters).filter(([, v]) => v !== "all").length;

  const field = (
    id: keyof Filters,
    label: string,
    options: { value: string; label: string }[],
  ) => (
    <div className="space-y-1.5">
      <Label htmlFor={`filter-${id}`} className="text-xs text-muted-foreground">
        {label}
      </Label>
      <Select value={filters[id]} onValueChange={(v) => set(id, v)}>
        <SelectTrigger id={`filter-${id}`} className="w-full">
          <SelectValue placeholder={`All ${label}`} />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All {label}</SelectItem>
          {options.map((o) => (
            <SelectItem key={o.value} value={o.value}>
              {o.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );

  return (
    <Card>
      <CardContent className="space-y-4 p-4 sm:p-5">
        <div className="flex items-center justify-between gap-3">
          <p className="flex items-center gap-2 text-sm font-semibold text-foreground">
            <SlidersHorizontal className="size-4 text-muted-foreground" aria-hidden />
            Filters
            {active > 0 ? (
              <span className="rounded-full bg-accent/20 px-2 py-0.5 text-xs font-medium text-accent-foreground">
                {active} active
              </span>
            ) : null}
          </p>
          <Button variant="outline" size="sm" onClick={() => onChange({ ...EMPTY_FILTERS })}>
            <RotateCcw className="mr-1.5 size-3.5" aria-hidden />
            Reset Filters
          </Button>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {field(
            "district",
            "Districts",
            DISTRICTS.map((d) => ({ value: d, label: d })),
          )}
          {field(
            "courseId",
            "Courses",
            courses.map((c) => ({ value: c.id, label: c.name })),
          )}
          {!hideProvider
            ? field(
                "providerId",
                "Providers",
                providers.map((p) => ({ value: p.id, label: p.name })),
              )
            : null}
          {field("gender", "Genders", [
            { value: "Male", label: "Male" },
            { value: "Female", label: "Female" },
          ])}
          {field(
            "ageGroup",
            "Age groups",
            AGE_GROUPS.map((a) => ({ value: a, label: a })),
          )}
          {field("trainingYear", "Training years", [
            { value: "2025", label: "2025" },
            { value: "2024", label: "2024" },
          ])}
          {field(
            "employmentStatus",
            "Statuses",
            STATUSES.map((s) => ({ value: s, label: s })),
          )}
        </div>
      </CardContent>
    </Card>
  );
}
