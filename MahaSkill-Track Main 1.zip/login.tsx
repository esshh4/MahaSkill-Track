import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import { ArrowRight, KeyRound, ShieldCheck, TrendingUp, Users } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { useAuth } from "@/auth/auth-context";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DEMO_USERS } from "@/data/seed";
import { ROLE_LABEL } from "@/auth/auth-context";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Sign in — MahaSkillTrack" },
      {
        name: "description",
        content:
          "Sign in to MahaSkillTrack with a demo administrator, training provider, trainee or employer account.",
      },
      { property: "og:title", content: "Sign in — MahaSkillTrack" },
      {
        property: "og:description",
        content: "Role-based access to Maharashtra skill training outcome intelligence.",
      },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("admin@mahaskill.demo");
  const [password, setPassword] = useState("demo1234");
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!email.includes("@")) {
      setError("Enter a valid email address.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }
    setBusy(true);
    const result = signIn(email, password);
    setBusy(false);
    if (!result.ok) {
      setError(result.error ?? "Sign in failed.");
      return;
    }
    toast.success(`Signed in as ${ROLE_LABEL[result.role!]}`);
    void navigate({ to: "/app/dashboard" });
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="gov-gradient hidden flex-col justify-between p-10 text-primary-foreground lg:flex">
        <Link to="/" className="flex items-center gap-3">
          <span className="grid size-10 place-items-center rounded-lg bg-accent font-bold text-accent-foreground">
            M
          </span>
          <span>
            <span className="block font-semibold">MahaSkillTrack</span>
            <span className="block text-xs text-primary-foreground/70">
              Maharashtra Skill Development Outcome Intelligence
            </span>
          </span>
        </Link>
        <div>
          <h1 className="max-w-md text-3xl font-semibold tracking-tight">
            Turning training data into employment outcomes.
          </h1>
          <ul className="mt-8 space-y-4 text-sm text-primary-foreground/80">
            {[
              { icon: Users, text: "One record per trainee, from enrollment to 12-month follow-up." },
              { icon: TrendingUp, text: "Placement, retention and salary progression in real time." },
              { icon: ShieldCheck, text: "Consent-aware data sharing and aggregated analytics." },
            ].map((row) => (
              <li key={row.text} className="flex items-start gap-3">
                <row.icon className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden />
                {row.text}
              </li>
            ))}
          </ul>
        </div>
        <p className="text-xs text-primary-foreground/60">
          Prototype environment · synthetic data · Government of Maharashtra hackathon
        </p>
      </div>

      <div className="flex items-center justify-center bg-background px-4 py-12 sm:px-8">
        <div className="w-full max-w-md">
          <Link to="/" className="mb-8 flex items-center gap-2 text-sm text-muted-foreground lg:hidden">
            <span className="grid size-8 place-items-center rounded-lg bg-primary text-xs font-bold text-primary-foreground">
              M
            </span>
            MahaSkillTrack
          </Link>
          <h2 className="text-2xl font-semibold tracking-tight">Sign in</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Your role and permissions are determined by your account.
          </p>

          <form onSubmit={submit} className="mt-8 space-y-4" noValidate>
            <div className="space-y-1.5">
              <Label htmlFor="email">Email address</Label>
              <Input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                aria-invalid={Boolean(error)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                aria-invalid={Boolean(error)}
              />
            </div>
            {error ? (
              <p role="alert" className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {error}
              </p>
            ) : null}
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 text-sm text-muted-foreground">
                <Checkbox
                  checked={remember}
                  onCheckedChange={(v) => setRemember(Boolean(v))}
                  aria-label="Remember me"
                />
                Remember me
              </label>
              <button
                type="button"
                className="text-sm font-medium text-primary underline-offset-4 hover:underline"
                onClick={() =>
                  toast.info("Password reset is disabled in the demo environment.", {
                    description: "Use any listed demo account with the password demo1234.",
                  })
                }
              >
                Forgot password?
              </button>
            </div>
            <Button type="submit" className="w-full" size="lg" disabled={busy}>
              {busy ? "Signing in…" : "Sign in"}
              <ArrowRight className="ml-2 size-4" aria-hidden />
            </Button>
          </form>

          <Card className="mt-8 border-dashed bg-muted/40">
            <CardContent className="p-4">
              <p className="flex items-center gap-2 text-sm font-semibold">
                <KeyRound className="size-4 text-accent-foreground" aria-hidden />
                Demo login · password <code className="rounded bg-background px-1.5 py-0.5">demo1234</code>
              </p>
              <div className="mt-3 grid gap-2">
                {DEMO_USERS.map((u) => (
                  <button
                    key={u.email}
                    type="button"
                    onClick={() => {
                      setEmail(u.email);
                      setPassword(u.password);
                      setError(null);
                    }}
                    className="flex items-center justify-between rounded-lg border border-border bg-card px-3 py-2 text-left text-sm transition-colors hover:border-primary/40 hover:bg-accent/10"
                  >
                    <span className="min-w-0">
                      <span className="block truncate font-medium">{ROLE_LABEL[u.role]}</span>
                      <span className="block truncate text-xs text-muted-foreground">{u.email}</span>
                    </span>
                    <ArrowRight className="size-4 shrink-0 text-muted-foreground" aria-hidden />
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
