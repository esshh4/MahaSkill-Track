import { createFileRoute } from "@tanstack/react-router";
import { Download, GraduationCap } from "lucide-react";
import { useMemo, useState } from "react";

import { ChartCard } from "@/components/common/chart-card";
import { FilterBar } from "@/components/common/filter-bar";
import { PageHeader } from "@/components/common/page-header";
import { EmptyState } from "@/components/common/states";
import { CourseComparisonBars } from "@/components/charts/dashboard-charts";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useScope } from "@/hooks/use-scope";
import { EMPTY_FILTERS, applyFilters, courseStats, formatINR } from "@/services/analytics";
import { useStore } from "@/services/store";
import { downloadCsv } from "@/utils/export";
import type { Filters } from "@/types";

export const Route = createFileRoute("/app/programs")({
  head: () => ({
    meta: [
      { title: "Training programs — MahaSkillTrack" },
      {
        name: "description",
        content:
          "Compare skill-training programs on completion, certification, placement, retention and salary outcomes.",
      },
      { property: "og:title", content: "Program Effectiveness — MahaSkillTrack" },
      {
        property: "og:description",
        content: "Course-level outcome comparison for Maharashtra skill programs.",
      },
    ],
  }),
  component: ProgramsPage,
});

function ProgramsPage() {
  const scope = useScope();
  const { courses } = useStore();
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);
  const rows = useMemo(() => applyFilters(scope.trainees, filters), [scope.trainees, filters]);
  const stats = useMemo(() => courseStats(rows), [rows]);

  const best = [...stats].sort((a, b) => b.placementRate - a.placementRate)[0];
  const worst = [...stats].sort((a, b) => a.placementRate - b.placementRate)[0];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Training program effectiveness"
        description="Which courses actually lead to jobs, retention and income growth?"
        actions={
          <Button
            variant="outline"
            disabled={!stats.length}
            onClick={() =>
              downloadCsv(
                "program-effectiveness",
                stats.map((s) => ({
                  Course: s.course,
                  Sector: s.sector,
                  Trainees: s.trainees,
                  "Completion %": s.completionRate,
                  "Certification %": s.certificationRate,
                  "Placement %": s.placementRate,
                  "Retention 12m %": s.retention12,
                  "Avg salary": s.avgSalary,
                  Satisfaction: s.traineeSatisfaction,
                })),
              )
            }
          >
            <Download className="mr-2 size-4" aria-hidden />
            Export CSV
          </Button>
        }
      />

      <FilterBar filters={filters} onChange={setFilters} hideProvider={scope.role === "provider"} />

      {!stats.length ? (
        <EmptyState
          icon={GraduationCap}
          title="No program data in this scope"
          description="Reset the filters to see program comparisons."
          action={
            <Button variant="outline" onClick={() => setFilters(EMPTY_FILTERS)}>
              Reset filters
            </Button>
          }
        />
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2">
            <Card className="border-success/40 bg-success/5">
              <CardContent className="p-5">
                <p className="text-xs tracking-wide text-muted-foreground uppercase">
                  Best performing program
                </p>
                <p className="mt-1 text-lg font-semibold">{best?.course}</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  {best?.placementRate}% placement · {formatINR(best?.avgSalary ?? 0)} average salary
                </p>
              </CardContent>
            </Card>
            <Card className="border-destructive/40 bg-destructive/5">
              <CardContent className="p-5">
                <p className="text-xs tracking-wide text-muted-foreground uppercase">
                  Needs intervention
                </p>
                <p className="mt-1 text-lg font-semibold">{worst?.course}</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  {worst?.placementRate}% placement · review curriculum and employer linkages
                </p>
              </CardContent>
            </Card>
          </div>

          <ChartCard
            title="Placement vs 12-month retention by course"
            description="Programs where placements hold up over time"
          >
            <CourseComparisonBars
              data={stats.map((s) => ({
                course: s.course,
                placementRate: s.placementRate,
                retention12: s.retention12,
              }))}
            />
          </ChartCard>

          <Card>
            <CardContent className="overflow-x-auto p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Course</TableHead>
                    <TableHead>Trainees</TableHead>
                    <TableHead>Completion</TableHead>
                    <TableHead>Certification</TableHead>
                    <TableHead>Placement</TableHead>
                    <TableHead>Retention 3/6/12</TableHead>
                    <TableHead className="text-right">Avg salary</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stats.map((s) => (
                    <TableRow key={s.courseId}>
                      <TableCell>
                        <span className="block font-medium">{s.course}</span>
                        <span className="block text-xs text-muted-foreground">
                          {s.sector} ·{" "}
                          {courses.find((c) => c.id === s.courseId)?.durationWeeks ?? "—"} weeks
                        </span>
                      </TableCell>
                      <TableCell>{s.trainees}</TableCell>
                      <TableCell>{s.completionRate}%</TableCell>
                      <TableCell>{s.certificationRate}%</TableCell>
                      <TableCell>
                        <Badge variant={s.placementRate >= 70 ? "default" : "secondary"}>
                          {s.placementRate}%
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">
                        {s.retention3}% / {s.retention6}% / {s.retention12}%
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        {formatINR(s.avgSalary)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
