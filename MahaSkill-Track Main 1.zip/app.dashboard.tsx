import { Link, createFileRoute } from "@tanstack/react-router";
import {
  ArrowRight,
  Award,
  Briefcase,
  ClipboardList,
  Download,
  GraduationCap,
  IndianRupee,
  Lightbulb,
  ShieldCheck,
  TrendingUp,
  Users,
} from "lucide-react";
import { useMemo, useState } from "react";

import { ROLE_LABEL, useAuth } from "@/auth/auth-context";
import { ChartCard } from "@/components/common/chart-card";
import { FilterBar } from "@/components/common/filter-bar";
import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/states";
import { StatusBadge } from "@/components/common/status-badge";
import { Timeline } from "@/components/common/timeline";
import {
  DistrictBars,
  OutcomeDonut,
  RetentionLine,
  SalaryLine,
} from "@/components/charts/dashboard-charts";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { useScope } from "@/hooks/use-scope";
import {
  EMPTY_FILTERS,
  applyFilters,
  districtStats,
  formatINR,
  kpis,
  outcomeBreakdown,
  pendingFollowUps,
  retentionTrend,
  salaryProgressionAvg,
  skillInsights,
} from "@/services/analytics";
import { useStore } from "@/services/store";
import { downloadCsv } from "@/utils/export";
import type { Filters } from "@/types";

export const Route = createFileRoute("/app/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — MahaSkillTrack" },
      {
        name: "description",
        content:
          "Live outcome dashboard: placement, retention, salary growth and follow-up progress across Maharashtra skill programs.",
      },
      { property: "og:title", content: "Outcome Dashboard — MahaSkillTrack" },
      {
        property: "og:description",
        content: "Role-based KPIs and charts for Maharashtra skill training outcomes.",
      },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  const { user } = useAuth();
  const scope = useScope();
  const { courseName, providerName } = useStore();
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);

  const rows = useMemo(() => applyFilters(scope.trainees, filters), [scope.trainees, filters]);
  const k = useMemo(() => kpis(rows), [rows]);
  const outcomes = useMemo(() => outcomeBreakdown(rows).filter((o) => o.value > 0), [rows]);
  const districts = useMemo(() => districtStats(rows), [rows]);
  const retention = useMemo(() => retentionTrend(rows), [rows]);
  const salary = useMemo(() => salaryProgressionAvg(rows).filter((p) => p.salary > 0), [rows]);
  const insight = useMemo(() => skillInsights(), []);
  const followUps = useMemo(
    () => pendingFollowUps(rows).filter((f) => f.followUp.status !== "Completed").slice(0, 5),
    [rows],
  );

  if (scope.role === "trainee") return <TraineeDashboard />;

  return (
    <div className="space-y-6">
      <PageHeader
        title={`Welcome, ${user?.name?.split(" ")[0] ?? "Officer"}`}
        description={`${ROLE_LABEL[scope.role]} · ${scope.scopeLabel} · ${rows.length} trainee records in view.`}
        actions={
          <>
            <Button variant="outline" asChild>
              <Link to="/app/reports">
                <Download className="mr-2 size-4" aria-hidden />
                Reports
              </Link>
            </Button>
            <Button asChild>
              <Link to="/app/outcomes">
                Record outcome
                <ArrowRight className="ml-2 size-4" aria-hidden />
              </Link>
            </Button>
          </>
        }
      />

      <FilterBar filters={filters} onChange={setFilters} hideProvider={scope.role === "provider"} />

      {rows.length === 0 ? (
        <EmptyState
          title="No trainees match these filters"
          description="Try widening the district, course or outcome filters to see results."
          action={
            <Button variant="outline" onClick={() => setFilters(EMPTY_FILTERS)}>
              Reset filters
            </Button>
          }
        />

      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard
              label="Total trainees"
              value={k.total.toLocaleString("en-IN")}
              description="Enrolled in the selected scope"
              icon={Users}
              change={6}
            />
            <StatCard
              label="Training completion"
              value={`${k.completionRate}%`}
              description={`${k.completed} completed · ${k.certified} certified`}
              icon={GraduationCap}
              accent="info"
              change={4}
            />
            <StatCard
              label="Employment rate"
              value={`${k.employmentRate}%`}
              description={`Employed ${k.employedRate}% · self-employed ${k.selfRate}%`}
              icon={Briefcase}
              accent="success"
              change={9}
            />
            <StatCard
              label="Average salary"
              value={formatINR(k.avgSalary)}
              description={`12-month retention ${k.retention12}%`}
              icon={IndianRupee}
              accent="saffron"
              change={12}
            />
          </div>

          <div className="grid gap-5 lg:grid-cols-2">
            <ChartCard
              title="Employment outcome distribution"
              description="Where trainees are today across all outcome categories"
            >
              <OutcomeDonut data={outcomes} />
            </ChartCard>
            <ChartCard
              title="District-wise employment rate"
              description="Placement performance by district"
              action={
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() =>
                    downloadCsv(
                      "district-employment",
                      districts.map((d) => ({
                        District: d.district,
                        Trainees: d.trainees,
                        "Employment rate %": d.employmentRate,
                        "Average salary": d.avgSalary,
                      })),
                    )
                  }
                >
                  <Download className="mr-1.5 size-4" aria-hidden />
                  CSV
                </Button>
              }
            >
              <DistrictBars data={districts} />
            </ChartCard>
            <ChartCard
              title="Retention over time"
              description="Share still employed at each follow-up milestone"
            >
              <RetentionLine data={retention} />
            </ChartCard>
            <ChartCard
              title="Average salary progression"
              description="Monthly income growth from joining to 12 months"
            >
              {salary.length ? (
                <SalaryLine data={salary} />
              ) : (
                <EmptyState
                  title="No salary data yet"
                  description="Salary progression appears once placements and follow-ups are recorded."
                />
              )}
            </ChartCard>
          </div>

          <div className="grid gap-5 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader className="flex flex-row items-start justify-between gap-3">
                <div>
                  <CardTitle className="text-base">Follow-ups needing attention</CardTitle>
                  <CardDescription>Due and pending milestone check-ins</CardDescription>
                </div>
                <Button variant="ghost" size="sm" asChild>
                  <Link to="/app/followups">
                    View all
                    <ArrowRight className="ml-1.5 size-4" aria-hidden />
                  </Link>
                </Button>
              </CardHeader>
              <CardContent className="space-y-2">
                {followUps.length ? (
                  followUps.map((f) => (
                    <Link
                      key={`${f.traineeId}-${f.followUp.id}`}
                      to="/app/trainees/$traineeId"
                      params={{ traineeId: f.traineeId }}
                      className="flex items-center justify-between gap-3 rounded-lg border border-border px-3 py-2.5 transition-colors hover:border-primary/40 hover:bg-muted/50"
                    >
                      <span className="min-w-0">
                        <span className="block truncate text-sm font-medium">{f.traineeName}</span>
                        <span className="block truncate text-xs text-muted-foreground">
                          {courseName(f.courseId)} · {f.district} · {f.followUp.milestone} · due{" "}
                          {f.followUp.dueDate}
                        </span>
                      </span>
                      <StatusBadge status={f.followUp.status} />
                    </Link>
                  ))
                ) : (
                  <EmptyState
                    title="All follow-ups are complete"
                    description="No pending milestone check-ins in this scope."
                  />
                )}
              </CardContent>
            </Card>

            <Card className="border-accent/40 bg-accent/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Lightbulb className="size-4 text-accent-foreground" aria-hidden />
                  Insight of the day
                </CardTitle>
                <CardDescription>Rule-based recommendation engine</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <p>{insight.insight}</p>
                <Separator />
                <p className="font-medium">Recommended action</p>
                <p className="text-muted-foreground">{insight.action}</p>
                <Button variant="outline" size="sm" asChild className="w-full">
                  <Link to="/app/skill-gaps">
                    Open skill-gap analysis
                    <ArrowRight className="ml-1.5 size-4" aria-hidden />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>

          {scope.isAdmin ? (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Top districts by employment rate</CardTitle>
                <CardDescription>Ranked on placements within the current filters</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {[...districts]
                  .sort((a, b) => b.employmentRate - a.employmentRate)
                  .slice(0, 5)
                  .map((d) => (
                    <div key={d.district} className="space-y-1.5">
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-medium">{d.district}</span>
                        <span className="text-muted-foreground">
                          {d.employmentRate}% · {formatINR(d.avgSalary)} avg
                        </span>
                      </div>
                      <Progress value={d.employmentRate} />
                    </div>
                  ))}
              </CardContent>
            </Card>
          ) : null}

          <p className="flex items-center gap-2 text-xs text-muted-foreground">
            <ShieldCheck className="size-3.5" aria-hidden />
            Aggregated view · personal contact details are hidden from analytics screens.
          </p>
        </>
      )}
    </div>
  );
}

function TraineeDashboard() {
  const { self } = useScope();
  const { courseName, providerName } = useStore();

  if (!self) {
    return (
      <EmptyState
        title="No trainee record linked"
        description="This demo account is not linked to a trainee profile."
      />
    );
  }

  const nextFollowUp = self.followUps.find((f) => f.status !== "Completed");
  const latestSalary = self.salaryProgression.at(-1)?.salary ?? 0;
  const firstSalary = self.salaryProgression[0]?.salary ?? 0;
  const growth = firstSalary ? Math.round(((latestSalary - firstSalary) / firstSalary) * 100) : 0;

  return (
    <div className="space-y-6">
      <PageHeader
        title={`My journey · ${self.name}`}
        description={`${courseName(self.courseId)} at ${providerName(self.providerId)} · ${self.district} district`}
        actions={<StatusBadge status={self.employmentStatus} />}
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Training status"
          value={self.trainingStatus}
          description={`Attendance ${self.attendance}% · score ${self.assessmentScore}`}
          icon={GraduationCap}
        />
        <StatCard
          label="Certification"
          value={self.certified ? "Certified" : "Pending"}
          description={self.certified ? "Certificate issued by provider" : "Awaiting assessment"}
          icon={Award}
          accent="info"
        />
        <StatCard
          label="Current income"
          value={formatINR(latestSalary)}
          description={growth ? `${growth > 0 ? "+" : ""}${growth}% since joining` : "Not employed yet"}
          icon={IndianRupee}
          accent="saffron"
          {...(growth ? { change: growth } : {})}
        />
        <StatCard
          label="Next follow-up"
          value={nextFollowUp?.milestone ?? "Complete"}
          description={nextFollowUp ? `Due ${nextFollowUp.dueDate}` : "All milestones recorded"}
          icon={ClipboardList}
          accent="success"
        />
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">My career timeline</CardTitle>
            <CardDescription>Every recorded milestone in your journey</CardDescription>
          </CardHeader>
          <CardContent>
            <Timeline events={self.timeline} />
          </CardContent>
        </Card>
        <div className="space-y-5">
          <ChartCard title="My salary progression" description="Reported monthly income">
            {self.salaryProgression.length ? (
              <SalaryLine data={self.salaryProgression} height={240} />
            ) : (
              <EmptyState
                title="No income recorded"
                description="Your income appears here once employment is recorded."
              />
            )}
          </ChartCard>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Current employment</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <Row label="Employer" value={self.employment.employerName ?? "—"} />
              <Row label="Role" value={self.employment.jobTitle ?? "—"} />
              <Row label="Joined" value={self.employment.joiningDate ?? "—"} />
              <Row label="Location" value={self.employment.location ?? "—"} />
              <Row
                label="Verification"
                value={self.employment.verified ? "Verified by employer" : "Pending verification"}
              />
              <Button variant="outline" size="sm" asChild className="mt-2 w-full">
                <Link to="/app/consent">
                  <ShieldCheck className="mr-1.5 size-4" aria-hidden />
                  Manage my data consent
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <TrendingUp className="size-4 text-success" aria-hidden />
            My follow-up history
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {self.followUps.map((f) => (
            <div
              key={f.id}
              className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border px-3 py-2.5 text-sm"
            >
              <span>
                <span className="font-medium">{f.milestone}</span>
                <span className="ml-2 text-xs text-muted-foreground">
                  {f.status === "Completed" ? `Recorded ${f.completedDate}` : `Due ${f.dueDate}`}
                  {f.salary ? ` · ${formatINR(f.salary)}` : ""}
                </span>
              </span>
              <StatusBadge status={f.status} />
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-border/60 pb-1.5 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{value}</span>
    </div>
  );
}
