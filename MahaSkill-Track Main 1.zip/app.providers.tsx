import { createFileRoute } from "@tanstack/react-router";
import { Download } from "lucide-react";
import { useMemo } from "react";

import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useScope } from "@/hooks/use-scope";
import { formatINR, providerStats } from "@/services/analytics";
import { downloadCsv } from "@/utils/export";

export const Route = createFileRoute("/app/providers")({
  head: () => ({
    meta: [
      { title: "Training providers — MahaSkillTrack" },
      { name: "description", content: "Compare accredited training providers on completion, placement, retention and salary outcomes." },
      { property: "og:title", content: "Provider Performance — MahaSkillTrack" },
      { property: "og:description", content: "Accreditation-linked provider performance league table." },
    ],
  }),
  component: ProvidersPage,
});

function ProvidersPage() {
  const scope = useScope();
  const stats = useMemo(() => providerStats(scope.trainees), [scope.trainees]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Training provider performance"
        description="Accreditation grade against real employment outcomes for each empanelled provider."
        actions={
          <Button
            variant="outline"
            onClick={() =>
              downloadCsv(
                "provider-performance",
                stats.map((p) => ({
                  Provider: p.provider,
                  District: p.district,
                  Accreditation: p.accreditation,
                  Trainees: p.trainees,
                  "Completion %": p.completionRate,
                  "Employment %": p.employmentRate,
                  "Retention 6m %": p.retention,
                  "Avg salary": p.avgSalary,
                })),
              )
            }
          >
            <Download className="mr-2 size-4" aria-hidden />
            Export CSV
          </Button>
        }
      />
      <Card>
        <CardContent className="overflow-x-auto p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Provider</TableHead>
                <TableHead>Accreditation</TableHead>
                <TableHead>Trainees</TableHead>
                <TableHead>Completion</TableHead>
                <TableHead>Employment</TableHead>
                <TableHead>Retention 6m</TableHead>
                <TableHead className="text-right">Avg salary</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...stats]
                .sort((a, b) => b.employmentRate - a.employmentRate)
                .map((p) => (
                  <TableRow key={p.providerId}>
                    <TableCell>
                      <span className="block font-medium">{p.provider}</span>
                      <span className="block text-xs text-muted-foreground">
                        {p.district} · rating {p.rating}/5 · {p.programs} programs
                      </span>
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={p.accreditation === "C" ? "Needs Review" : "Verified"} showIcon={false} />
                    </TableCell>
                    <TableCell>{p.trainees}</TableCell>
                    <TableCell>{p.completionRate}%</TableCell>
                    <TableCell className="font-medium">{p.employmentRate}%</TableCell>
                    <TableCell>{p.retention}%</TableCell>
                    <TableCell className="text-right">{formatINR(p.avgSalary)}</TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
