import { Link, createFileRoute } from "@tanstack/react-router";
import { ClipboardList } from "lucide-react";
import { useMemo, useState } from "react";

import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { EmptyState } from "@/components/common/states";
import { StatusBadge } from "@/components/common/status-badge";
import { FollowUpDialog } from "@/components/forms/follow-up-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useScope } from "@/hooks/use-scope";
import { formatINR, pendingFollowUps } from "@/services/analytics";
import { useStore } from "@/services/store";

export const Route = createFileRoute("/app/followups")({
  head: () => ({
    meta: [
      { title: "Follow-ups — MahaSkillTrack" },
      { name: "description", content: "Manage 3, 6 and 12-month follow-up check-ins and record verified outcome updates." },
      { property: "og:title", content: "Follow-up Tracker — MahaSkillTrack" },
      { property: "og:description", content: "Milestone follow-up scheduling and recording." },
    ],
  }),
  component: FollowUpsPage,
});

function FollowUpsPage() {
  const scope = useScope();
  const { courseName, getTrainee } = useStore();
  const [tab, setTab] = useState("due");
  const [active, setActive] = useState<{ traineeId: string; followUpId: string } | null>(null);

  const all = useMemo(() => pendingFollowUps(scope.trainees), [scope.trainees]);
  const counts = {
    due: all.filter((f) => f.followUp.status === "Due").length,
    pending: all.filter((f) => f.followUp.status === "Pending").length,
    unreachable: all.filter((f) => f.followUp.status === "Unreachable").length,
    completed: all.filter((f) => f.followUp.status === "Completed").length,
  };
  const filtered = all.filter((f) =>
    tab === "due"
      ? f.followUp.status === "Due"
      : tab === "pending"
        ? f.followUp.status === "Pending"
        : tab === "unreachable"
          ? f.followUp.status === "Unreachable"
          : f.followUp.status === "Completed",
  );

  const trainee = active ? getTrainee(active.traineeId) : undefined;

  return (
    <div className="space-y-6">
      <PageHeader title="Follow-up tracker" description="Structured 3, 6 and 12-month check-ins keep outcome data honest." />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Due now" value={String(counts.due)} description="Milestones ready to record" icon={ClipboardList} accent="saffron" />
        <StatCard label="Upcoming" value={String(counts.pending)} description="Scheduled for later dates" icon={ClipboardList} accent="info" />
        <StatCard label="Unreachable" value={String(counts.unreachable)} description="Require alternate contact" icon={ClipboardList} />
        <StatCard label="Completed" value={String(counts.completed)} description="Verified check-ins on record" icon={ClipboardList} accent="success" />
      </div>
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex-wrap">
          <TabsTrigger value="due">Due ({counts.due})</TabsTrigger>
          <TabsTrigger value="pending">Upcoming ({counts.pending})</TabsTrigger>
          <TabsTrigger value="unreachable">Unreachable ({counts.unreachable})</TabsTrigger>
          <TabsTrigger value="completed">Completed ({counts.completed})</TabsTrigger>
        </TabsList>
      </Tabs>
      {filtered.length === 0 ? (
        <EmptyState icon={ClipboardList} title="Nothing in this queue" description="Switch tabs to review other follow-up states." />
      ) : (
        <Card>
          <CardContent className="space-y-2 p-4 sm:p-5">
            {filtered.slice(0, 30).map((f) => (
              <div key={`${f.traineeId}-${f.followUp.id}`} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-3">
                <div className="min-w-0">
                  <Link to="/app/trainees/$traineeId" params={{ traineeId: f.traineeId }} className="text-sm font-medium hover:underline">
                    {f.traineeName}
                  </Link>
                  <p className="text-xs text-muted-foreground">
                    {courseName(f.courseId)} · {f.district} · {f.followUp.milestone} · due {f.followUp.dueDate}
                    {f.followUp.salary ? ` · ${formatINR(f.followUp.salary)}` : ""}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status={f.followUp.status} />
                  {scope.canEdit ? (
                    <Button size="sm" variant="outline" onClick={() => setActive({ traineeId: f.traineeId, followUpId: f.followUp.id })}>
                      Record
                    </Button>
                  ) : null}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
      {trainee && active ? (
        <FollowUpDialog trainee={trainee} followUpId={active.followUpId} onClose={() => setActive(null)} />
      ) : null}
    </div>
  );
}
