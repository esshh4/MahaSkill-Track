import { Link, createFileRoute } from "@tanstack/react-router";
import {
  ArrowRight,
  BadgeCheck,
  BarChart3,
  Briefcase,
  ChartLine,
  GraduationCap,
  LineChart,
  Radar,
  ShieldCheck,
  Target,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MahaSkillTrack — Skill Training Outcome Intelligence" },
      {
        name: "description",
        content:
          "Track Maharashtra skill-development outcomes from training to employment: placement, retention, salary growth and skill gaps in one platform.",
      },
      { property: "og:title", content: "MahaSkillTrack — From Training to Employment" },
      {
        property: "og:description",
        content:
          "Turn skill-training data into actionable employment intelligence across Maharashtra districts, courses and providers.",
      },
    ],
  }),
  component: Landing,
});

const FEATURES = [
  {
    icon: Target,
    title: "Track",
    body: "Follow every trainee from enrollment and certification through to employment, self-employment or apprenticeship.",
  },
  {
    icon: LineChart,
    title: "Measure",
    body: "Measure placement, 3/6/12-month retention, salary growth and satisfaction with verified follow-up data.",
  },
  {
    icon: Radar,
    title: "Improve",
    body: "Compare districts, courses and providers, expose skill gaps and act on rule-based recommendations.",
  },
];

const PROCESS = ["Training", "Certification", "Employment", "Follow-up", "Impact"];

const STATS = [
  { label: "Trainees tracked", value: "50,240" },
  { label: "Employment rate", value: "72.4%" },
  { label: "12-month retention", value: "81.3%" },
  { label: "Districts covered", value: "8" },
];

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-20 border-b border-border/70 bg-background/85 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <span className="grid size-9 place-items-center rounded-lg bg-primary font-bold text-primary-foreground">
              M
            </span>
            <div className="leading-tight">
              <p className="text-sm font-semibold">MahaSkillTrack</p>
              <p className="hidden text-[11px] text-muted-foreground sm:block">
                Maharashtra Skill Development Outcome Intelligence
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button asChild variant="ghost" size="sm">
              <Link to="/login">Sign in</Link>
            </Button>
            <Button asChild size="sm">
              <Link to="/app/dashboard">
                Explore Dashboard
                <ArrowRight className="ml-1.5 size-4" aria-hidden />
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <section className="gov-gradient relative overflow-hidden text-primary-foreground">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
            <p className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-medium">
              <ShieldCheck className="size-3.5" aria-hidden />
              Government of Maharashtra · Skill Development Mission
            </p>
            <h1 className="mt-5 text-4xl font-semibold tracking-tight sm:text-5xl">
              From Training to Employment.
            </h1>
            <p className="mt-4 max-w-xl text-base/relaxed text-primary-foreground/80">
              Track skill-development outcomes across Maharashtra and turn training data into
              actionable employment intelligence.
            </p>
            <p className="mt-3 text-sm font-medium text-accent">
              Measuring what really matters — placement, retention and income growth.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
                <Link to="/app/dashboard">
                  Explore Dashboard
                  <ArrowRight className="ml-2 size-4" aria-hidden />
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-white/30 bg-transparent text-primary-foreground hover:bg-white/10 hover:text-primary-foreground"
              >
                <Link to="/login">View Demo</Link>
              </Button>
            </div>
            <dl className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-4">
              {STATS.map((s) => (
                <div key={s.label}>
                  <dt className="text-[11px] tracking-wide text-primary-foreground/60 uppercase">
                    {s.label}
                  </dt>
                  <dd className="mt-1 text-xl font-semibold">{s.value}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="animate-in fade-in slide-in-from-bottom-8 relative duration-1000">
            <div className="rounded-2xl border border-white/15 bg-white/10 p-5 shadow-2xl backdrop-blur">
              <p className="text-xs tracking-wide text-primary-foreground/70 uppercase">
                Outcome snapshot · September 2026
              </p>
              <div className="mt-4 space-y-3">
                {[
                  { icon: GraduationCap, label: "Training completed", value: "42,850", tone: "bg-white/15" },
                  { icon: Briefcase, label: "Placed in jobs", value: "36,180", tone: "bg-success/25" },
                  { icon: ChartLine, label: "Average salary growth", value: "+48% in 12 months", tone: "bg-accent/25" },
                  { icon: BarChart3, label: "Largest skill gap", value: "SQL — 29 pt gap", tone: "bg-destructive/25" },
                ].map((row) => (
                  <div
                    key={row.label}
                    className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 p-3"
                  >
                    <span className={`grid size-9 place-items-center rounded-lg ${row.tone}`}>
                      <row.icon className="size-4" aria-hidden />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-xs text-primary-foreground/70">{row.label}</span>
                      <span className="block truncate text-sm font-semibold">{row.value}</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <h2 className="text-2xl font-semibold tracking-tight">
          Did the training actually improve the outcome?
        </h2>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Completion certificates alone do not answer that question. MahaSkillTrack follows the full
          journey and reports what changed in each trainee's livelihood.
        </p>
        <div className="mt-8 grid gap-5 md:grid-cols-3">
          {FEATURES.map((f) => (
            <Card key={f.title} className="transition-shadow hover:shadow-lg">
              <CardContent className="p-6">
                <span className="grid size-11 place-items-center rounded-xl bg-primary/10 text-primary">
                  <f.icon className="size-5" aria-hidden />
                </span>
                <h3 className="mt-4 text-lg font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{f.body}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="border-y border-border bg-muted/40 py-14">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <h2 className="text-xl font-semibold tracking-tight">The outcome pipeline</h2>
          <ol className="mt-6 flex flex-col gap-3 md:flex-row md:items-center">
            {PROCESS.map((step, i) => (
              <li key={step} className="flex flex-1 items-center gap-3">
                <div className="flex flex-1 items-center gap-3 rounded-xl border border-border bg-card px-4 py-3 shadow-sm">
                  <span className="grid size-7 shrink-0 place-items-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">
                    {i + 1}
                  </span>
                  <span className="text-sm font-medium">{step}</span>
                </div>
                {i < PROCESS.length - 1 ? (
                  <ArrowRight className="hidden size-4 shrink-0 text-muted-foreground md:block" aria-hidden />
                ) : null}
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <div className="rounded-2xl border border-border bg-card p-8 shadow-sm sm:p-10">
          <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="text-xl font-semibold tracking-tight">Try the demo environment</h2>
              <p className="mt-2 max-w-xl text-sm text-muted-foreground">
                Four seeded roles — administrator, training provider, trainee and employer — with
                synthetic Maharashtra data. No real personal information is used.
              </p>
              <p className="mt-3 inline-flex items-center gap-2 text-xs text-muted-foreground">
                <BadgeCheck className="size-4 text-success" aria-hidden />
                Privacy-first: analytics screens show aggregated data only.
              </p>
            </div>
            <Button asChild size="lg">
              <Link to="/login">
                Open demo login
                <ArrowRight className="ml-2 size-4" aria-hidden />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <footer className="border-t border-border py-8">
        <div className="mx-auto max-w-6xl px-4 text-xs text-muted-foreground sm:px-6">
          MahaSkillTrack · Hackathon prototype for the Government of Maharashtra · Synthetic
          demonstration data only.
        </div>
      </footer>
    </div>
  );
}
