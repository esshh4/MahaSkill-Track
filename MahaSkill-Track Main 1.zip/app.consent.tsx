import { createFileRoute } from "@tanstack/react-router";
import { ShieldCheck } from "lucide-react";

import { PageHeader } from "@/components/common/page-header";
import { StatCard } from "@/components/common/stat-card";
import { StatusBadge } from "@/components/common/status-badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useScope } from "@/hooks/use-scope";
import { pct } from "@/services/analytics";

export const Route = createFileRoute("/app/consent")({
  head: () => ({
    meta: [
      { title: "Consent & privacy — MahaSkillTrack" },
      { name: "description", content: "Consent status, data-sharing preferences and the privacy safeguards applied to outcome tracking." },
      { property: "og:title", content: "Consent & Privacy — MahaSkillTrack" },
      { property: "og:description", content: "How trainee consent governs data sharing and analytics." },
    ],
  }),
  component: ConsentPage,
});

function ConsentPage() {
  const { trainees, self, role } = useScope();
  const granted = trainees.filter((t) => t.consent === "Granted").length;
  const partial = trainees.filter((t) => t.consent === "Partial").length;
  const withdrawn = trainees.filter((t) => t.consent === "Withdrawn").length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Consent and privacy"
        description="Outcome tracking runs only on the data trainees have agreed to share."
      />
      {role === "trainee" && self ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">My consent preferences</CardTitle>
            <CardDescription>Recorded {self.consentDate}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Overall consent</span>
              <StatusBadge status={self.consent} />
            </div>
            {[
              ["Share anonymised data for analytics", self.dataSharing.analytics],
              ["Share profile with verified employers", self.dataSharing.employers],
              ["Share anonymised data for research", self.dataSharing.research],
            ].map(([label, value]) => (
              <div key={String(label)} className="flex items-center justify-between border-t border-border/60 pt-2">
                <span className="text-muted-foreground">{label}</span>
                <StatusBadge status={value ? "Granted" : "Withdrawn"} />
              </div>
            ))}
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-3">
          <StatCard label="Full consent" value={`${pct(granted, trainees.length)}%`} description={`${granted} trainees`} icon={ShieldCheck} accent="success" />
          <StatCard label="Partial consent" value={`${pct(partial, trainees.length)}%`} description={`${partial} trainees limit sharing`} icon={ShieldCheck} accent="saffron" />
          <StatCard label="Withdrawn" value={`${pct(withdrawn, trainees.length)}%`} description={`${withdrawn} excluded from sharing`} icon={ShieldCheck} />
        </div>
      )}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Privacy safeguards in this platform</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>· All trainee names, IDs and employers in this demo are synthetic — no real personal data is used.</p>
          <p>· Analytics and report screens show aggregated figures only; contact details are never exported.</p>
          <p>· Employers see only trainees they employ; providers see only their own cohorts.</p>
          <p>· Consent status is stored with each record and can be withdrawn at any time.</p>
        </CardContent>
      </Card>
    </div>
  );
}
