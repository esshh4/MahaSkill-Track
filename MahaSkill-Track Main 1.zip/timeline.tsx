import { Check, Circle, Dot } from "lucide-react";

import { cn } from "@/lib/utils";
import type { TimelineEvent } from "@/types";

export function Timeline({ events }: { events: TimelineEvent[] }) {
  return (
    <ol className="relative space-y-0">
      {events.map((event, i) => {
        const last = i === events.length - 1;
        return (
          <li key={event.id} className="relative flex gap-4 pb-6 last:pb-0">
            {!last ? (
              <span
                aria-hidden
                className={cn(
                  "absolute top-8 left-[15px] h-full w-0.5",
                  event.status === "done" ? "bg-success/40" : "bg-border",
                )}
              />
            ) : null}
            <span
              className={cn(
                "relative z-10 grid size-8 shrink-0 place-items-center rounded-full border-2 bg-card",
                event.status === "done" && "border-success text-success",
                event.status === "current" && "border-accent text-accent-foreground",
                event.status === "upcoming" && "border-border text-muted-foreground",
              )}
            >
              {event.status === "done" ? (
                <Check className="size-4" aria-hidden />
              ) : event.status === "current" ? (
                <Circle className="size-3.5 fill-current" aria-hidden />
              ) : (
                <Dot className="size-4" aria-hidden />
              )}
            </span>
            <div className="min-w-0 flex-1 rounded-lg border border-border/70 bg-muted/30 px-4 py-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-medium text-foreground">{event.label}</p>
                <p className="text-xs font-medium text-muted-foreground tabular-nums">{event.date}</p>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">{event.detail}</p>
              <span className="sr-only">Status: {event.status}</span>
            </div>
          </li>
        );
      })}
    </ol>
  );
}
