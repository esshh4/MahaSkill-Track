import { useMemo } from "react";

import { useAuth } from "@/auth/auth-context";
import { useStore } from "@/services/store";
import type { Trainee } from "@/types";

/**
 * Role-based data scoping. Administrators see everything; providers see their own
 * cohorts; employers see trainees they employ; trainees see only their own record.
 */
export function useScope() {
  const { user } = useAuth();
  const { trainees } = useStore();

  return useMemo(() => {
    const role = user?.role ?? "admin";
    let scoped: Trainee[] = trainees;
    if (role === "provider" && user?.providerId) {
      scoped = trainees.filter((t) => t.providerId === user.providerId);
    } else if (role === "employer" && user?.employerId) {
      scoped = trainees.filter((t) => t.employment.employerId === user.employerId);
    } else if (role === "trainee" && user?.traineeId) {
      scoped = trainees.filter((t) => t.id === user.traineeId);
    }
    const self = user?.traineeId ? trainees.find((t) => t.id === user.traineeId) : undefined;
    return {
      role,
      trainees: scoped,
      self,
      isAdmin: role === "admin",
      canEdit: role === "admin" || role === "provider",
      scopeLabel:
        role === "admin"
          ? "State-wide data"
          : role === "provider"
            ? "Your training centre cohorts"
            : role === "employer"
              ? "Trainees employed by your organisation"
              : "Your personal record",
    };
  }, [trainees, user]);
}
