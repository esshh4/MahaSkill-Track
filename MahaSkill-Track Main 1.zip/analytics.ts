import { COURSES, DISTRICTS, PROVIDERS, SKILL_DEMAND } from "@/data/seed";
import type { EmploymentStatus, Filters, Trainee } from "@/types";

export const EMPTY_FILTERS: Filters = {
  district: "all",
  courseId: "all",
  providerId: "all",
  gender: "all",
  ageGroup: "all",
  trainingYear: "all",
  employmentStatus: "all",
};

export const AGE_GROUPS = ["18-21", "22-25", "26-30", "31+"];

function inAgeGroup(age: number, group: string) {
  if (group === "18-21") return age <= 21;
  if (group === "22-25") return age >= 22 && age <= 25;
  if (group === "26-30") return age >= 26 && age <= 30;
  return age >= 31;
}

export function applyFilters(trainees: Trainee[], f: Filters): Trainee[] {
  return trainees.filter(
    (t) =>
      (f.district === "all" || t.district === f.district) &&
      (f.courseId === "all" || t.courseId === f.courseId) &&
      (f.providerId === "all" || t.providerId === f.providerId) &&
      (f.gender === "all" || t.gender === f.gender) &&
      (f.ageGroup === "all" || inAgeGroup(t.age, f.ageGroup)) &&
      (f.trainingYear === "all" || String(t.trainingYear) === f.trainingYear) &&
      (f.employmentStatus === "all" || t.employmentStatus === f.employmentStatus),
  );
}

const PLACED: EmploymentStatus[] = ["Employed", "Self-employed", "Apprenticeship"];

export function pct(part: number, total: number) {
  if (!total) return 0;
  return Math.round((part / total) * 1000) / 10;
}

export function avg(values: number[]) {
  if (!values.length) return 0;
  return Math.round(values.reduce((a, b) => a + b, 0) / values.length);
}

export function salaryOf(t: Trainee) {
  return t.employment.salary ?? t.employment.monthlyIncome ?? 0;
}

export function isPlaced(t: Trainee) {
  return PLACED.includes(t.employmentStatus);
}

export function retentionAt(trainees: Trainee[], milestone: "3 months" | "6 months" | "12 months") {
  const relevant = trainees.flatMap((t) =>
    t.followUps.filter((f) => f.milestone === milestone && f.status === "Completed"),
  );
  if (!relevant.length) return 0;
  const retained = relevant.filter(
    (f) => f.employmentStatus && PLACED.includes(f.employmentStatus),
  ).length;
  return pct(retained, relevant.length);
}

export function kpis(trainees: Trainee[]) {
  const total = trainees.length;
  const completed = trainees.filter((t) => t.trainingStatus === "Completed").length;
  const employed = trainees.filter((t) => t.employmentStatus === "Employed").length;
  const self = trainees.filter((t) => t.employmentStatus === "Self-employed").length;
  const appr = trainees.filter((t) => t.employmentStatus === "Apprenticeship").length;
  return {
    total,
    completed,
    completionRate: pct(completed, total),
    employmentRate: pct(employed + self + appr, total),
    employedRate: pct(employed, total),
    selfRate: pct(self, total),
    apprRate: pct(appr, total),
    retention12: retentionAt(trainees, "12 months"),
    avgSalary: avg(trainees.filter(isPlaced).map(salaryOf).filter(Boolean)),
    certified: trainees.filter((t) => t.certified).length,
  };
}

export function outcomeBreakdown(trainees: Trainee[]) {
  const statuses: EmploymentStatus[] = [
    "Employed",
    "Self-employed",
    "Apprenticeship",
    "Seeking Employment",
    "Further Education",
    "Unreachable",
  ];
  return statuses.map((s) => ({
    name: s,
    value: trainees.filter((t) => t.employmentStatus === s).length,
  }));
}

export function districtStats(trainees: Trainee[]) {
  return DISTRICTS.map((d) => {
    const list = trainees.filter((t) => t.district === d);
    return {
      district: d,
      trainees: list.length,
      employmentRate: pct(list.filter(isPlaced).length, list.length),
      retention: retentionAt(list, "6 months"),
      avgSalary: avg(list.filter(isPlaced).map(salaryOf).filter(Boolean)),
    };
  }).filter((d) => d.trainees > 0);
}

export function courseStats(trainees: Trainee[]) {
  return COURSES.map((c) => {
    const list = trainees.filter((t) => t.courseId === c.id);
    const completed = list.filter((t) => t.trainingStatus === "Completed");
    return {
      courseId: c.id,
      course: c.name,
      sector: c.sector,
      trainees: list.length,
      completionRate: pct(completed.length, list.length),
      certificationRate: pct(list.filter((t) => t.certified).length, list.length),
      placementRate: pct(list.filter(isPlaced).length, list.length),
      selfRate: pct(list.filter((t) => t.employmentStatus === "Self-employed").length, list.length),
      apprRate: pct(list.filter((t) => t.employmentStatus === "Apprenticeship").length, list.length),
      avgSalary: avg(list.filter(isPlaced).map(salaryOf).filter(Boolean)),
      retention3: retentionAt(list, "3 months"),
      retention6: retentionAt(list, "6 months"),
      retention12: retentionAt(list, "12 months"),
      traineeSatisfaction: list.length
        ? Math.round((list.reduce((a, t) => a + t.satisfaction, 0) / list.length) * 10) / 10
        : 0,
    };
  }).filter((c) => c.trainees > 0);
}

export function providerStats(trainees: Trainee[]) {
  return PROVIDERS.map((p) => {
    const list = trainees.filter((t) => t.providerId === p.id);
    return {
      providerId: p.id,
      provider: p.name,
      district: p.district,
      accreditation: p.accreditation,
      rating: p.rating,
      programs: p.courses.length,
      trainees: list.length,
      completionRate: pct(list.filter((t) => t.trainingStatus === "Completed").length, list.length),
      employmentRate: pct(list.filter(isPlaced).length, list.length),
      avgSalary: avg(list.filter(isPlaced).map(salaryOf).filter(Boolean)),
      retention: retentionAt(list, "6 months"),
    };
  }).filter((p) => p.trainees > 0);
}

export function salaryProgressionAvg(trainees: Trainee[]) {
  const points = ["Joining", "3 months", "6 months", "12 months"];
  return points.map((point) => ({
    point,
    salary: avg(
      trainees
        .flatMap((t) => t.salaryProgression.filter((p) => p.point === point))
        .map((p) => p.salary),
    ),
  }));
}

export function retentionTrend(trainees: Trainee[]) {
  return (["3 months", "6 months", "12 months"] as const).map((m) => ({
    milestone: m,
    retention: retentionAt(trainees, m),
  }));
}

export function nonPlacementReasons(trainees: Trainee[]) {
  const map = new Map<string, number>();
  trainees
    .filter((t) => !isPlaced(t) && t.nonPlacementReason)
    .forEach((t) => map.set(t.nonPlacementReason!, (map.get(t.nonPlacementReason!) ?? 0) + 1));
  return [...map.entries()]
    .map(([reason, count]) => ({ reason, count }))
    .sort((a, b) => b.count - a.count);
}

export function skillGaps() {
  return SKILL_DEMAND.map((s) => {
    const gap = s.demand - s.coverage;
    return {
      ...s,
      gap,
      severity: gap >= 20 ? "High" : gap >= 8 ? "Medium" : "Low",
    };
  }).sort((a, b) => b.gap - a.gap);
}

export function skillInsights() {
  const gaps = skillGaps();
  const top = gaps[0]!;
  return {
    insight: `${top.skill} is currently one of the largest skill gaps, with ${top.demand}% employer demand against ${top.coverage}% training coverage.`,
    action: `Increase ${top.skill} modules and practical assessments in relevant training programs.`,
    highCount: gaps.filter((g) => g.severity === "High").length,
  };
}

export function pendingFollowUps(trainees: Trainee[]) {
  return trainees
    .flatMap((t) =>
      t.followUps.map((f) => ({
        traineeId: t.id,
        traineeName: t.name,
        district: t.district,
        courseId: t.courseId,
        followUp: f,
      })),
    )
    .sort((a, b) => a.followUp.dueDate.localeCompare(b.followUp.dueDate));
}

export function formatINR(value: number) {
  if (!value) return "—";
  return `₹${value.toLocaleString("en-IN")}`;
}
