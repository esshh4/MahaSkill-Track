import { createFileRoute } from "@tanstack/react-router";
import { Download, Search } from "lucide-react";
import { useMemo, useState } from "react";

import { ChartCard } from "@/components/common/chart-card";
import { FilterBar } from "@/components/common/filter-bar";
import { PageHeader } from "@/components/common/page-header";
import { EmptyState } from "@/components/common/states";
import { StatusBadge } from "@/components/common/status-badge";
import { OutcomeDonut, ReasonBars } from "@/components/charts/dashboard-charts";
import { OutcomeDialog } from "@/components/forms/outcome-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useScope } from "@/hooks/use-scope";
import { EMPTY_FILTERS, applyFilters, formatINR, nonPlacementReasons, outcomeBreakdown, salaryOf } from "@/services/analytics";
import { useStore } from "@/services/store";
import { downloadCsv } from "@/utils/export";
import type { Filters, Trainee } from "@/types";

export const Route = createFileRoute("/app/outcomes")({
  head: () => ({
    meta: [
      { title: "Employment outcomes — MahaSkillTrack" },
      { name: "description", content: "Record and review employment outcomes, self-employment and reasons for non-placement." },
      { property: "og:title", content: "Employment Outcomes — MahaSkillTrack" },
      { property: "og:description", content: "Outcome registry with reason-code analysis for unplaced trainees." },
    ],
  }),
  component: OutcomesPage,
});

function OutcomesPage() {
  const scope = useScope();
  const { courseName } = useStore();
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<Trainee | null>(null);

  const rows = useMemo(() => {
    const list = applyFilters(scope.trainees, filters);
    const q = query.trim().toLowerCase();
    return q ? list.filter((t) => t.name.toLowerCase().includes(q) || t.id.toLowerCase().includes(q)) : list;
  }, [scope.trainees, filters, query]);

  const donut = useMemo(() => outcomeBreakdown(rows).filter((o) => o.value > 0), [rows]);
  const reasons = useMemo(() => nonPlacementReasons(rows), [rows]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Employment outcome registry"
        description="Update outcomes, capture self-employment and record why trainees remain unplaced."
        actions={
          <Button
            variant="outline"
            onClick={() =>
              downloadCsv(
                "employment-outcomes",
                rows.map((t) => ({
                  "Trainee ID": t.id,
                  Name: t.name,
                  District: t.district,
                  Course: courseName(t.courseId),
                  Outcome: t.employmentStatus,
                  Employer: t.employment.employerName ?? "",
                  Income: salaryOf(t) || "",
                  "Reason not placed": t.nonPlacementReason ?? "",
                })),
              )
            }
          >
            <Download className="mr-2 size-4" aria-hidden />
            Export CSV
          </Button>
        }
      />
      <FilterBar filters={filters} onChange={setFilters} hideProvider={scope.role === "provider"} />
      <div className="grid gap-5 lg:grid-cols-2">
        <ChartCard title="Outcome mix" description="Distribution across all outcome categories">
          {donut.length ? <OutcomeDonut data={donut} /> : <EmptyState title="No outcomes" description="No records match these filters." />}
        </ChartCard>
        <ChartCard title="Why trainees are not placed" description="Reason codes captured during follow-ups">
          {reasons.length ? <ReasonBars data={reasons} /> : <EmptyState title="No reason codes" description="Every trainee in this scope is placed." />}
        </ChartCard>
      </div>
      <Card>
        <CardContent className="space-y-4 p-4 sm:p-5">
          <div className="relative max-w-sm">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
            <Input className="pl-9" aria-label="Search outcomes" placeholder="Search trainee name or ID" value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Trainee</TableHead>
                  <TableHead>Outcome</TableHead>
                  <TableHead className="hidden md:table-cell">Employer</TableHead>
                  <TableHead>Income</TableHead>
                  {scope.canEdit ? <TableHead className="text-right">Action</TableHead> : null}
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.slice(0, 25).map((t) => (
                  <TableRow key={t.id}>
                    <TableCell>
                      <span className="block font-medium">{t.name}</span>
                      <span className="block text-xs text-muted-foreground">
                        {t.id} · {courseName(t.courseId)} · {t.district}
                      </span>
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={t.employmentStatus} />
                    </TableCell>
                    <TableCell className="hidden text-sm md:table-cell">{t.employment.employerName ?? "—"}</TableCell>
                    <TableCell className="text-sm font-medium">{formatINR(salaryOf(t))}</TableCell>
                    {scope.canEdit ? (
                      <TableCell className="text-right">
                        <Button variant="outline" size="sm" onClick={() => setEditing(t)}>
                          Update
                        </Button>
                      </TableCell>
                    ) : null}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <p className="text-xs text-muted-foreground">Showing up to 25 records · refine filters to narrow the list.</p>
        </CardContent>
      </Card>
      {editing ? (
        <OutcomeDialog trainee={editing} open onOpenChange={(o) => (!o ? setEditing(null) : undefined)} />
      ) : null}
    </div>
  );
}
