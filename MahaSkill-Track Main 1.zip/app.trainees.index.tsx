import { Link, createFileRoute } from "@tanstack/react-router";
import { Download, Search, Users } from "lucide-react";
import { useMemo, useState } from "react";

import { FilterBar } from "@/components/common/filter-bar";
import { PageHeader } from "@/components/common/page-header";
import { EmptyState } from "@/components/common/states";
import { StatusBadge } from "@/components/common/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useScope } from "@/hooks/use-scope";
import { EMPTY_FILTERS, applyFilters, formatINR, salaryOf } from "@/services/analytics";
import { useStore } from "@/services/store";
import { downloadCsv } from "@/utils/export";
import type { Filters } from "@/types";

export const Route = createFileRoute("/app/trainees/")({
  head: () => ({
    meta: [
      { title: "Trainees — MahaSkillTrack" },
      {
        name: "description",
        content:
          "Search, filter and export trainee records with training status, outcomes and salary details.",
      },
      { property: "og:title", content: "Trainee Registry — MahaSkillTrack" },
      {
        property: "og:description",
        content: "Consent-aware trainee registry with outcome and follow-up status.",
      },
    ],
  }),
  component: TraineesPage,
});

const PAGE_SIZE = 12;

function TraineesPage() {
  const scope = useScope();
  const { courseName, providerName } = useStore();
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);

  const rows = useMemo(() => {
    const filtered = applyFilters(scope.trainees, filters);
    const q = query.trim().toLowerCase();
    if (!q) return filtered;
    return filtered.filter(
      (t) =>
        t.name.toLowerCase().includes(q) ||
        t.id.toLowerCase().includes(q) ||
        t.district.toLowerCase().includes(q),
    );
  }, [scope.trainees, filters, query]);

  const pageCount = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const current = Math.min(page, pageCount);
  const visible = rows.slice((current - 1) * PAGE_SIZE, current * PAGE_SIZE);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Trainee registry"
        description={`${scope.scopeLabel} · ${rows.length} records match your search and filters.`}
        actions={
          <Button
            variant="outline"
            onClick={() =>
              downloadCsv(
                "trainees",
                rows.map((t) => ({
                  "Trainee ID": t.id,
                  Name: t.name,
                  District: t.district,
                  Course: courseName(t.courseId),
                  Provider: providerName(t.providerId),
                  "Training status": t.trainingStatus,
                  Certified: t.certified ? "Yes" : "No",
                  Outcome: t.employmentStatus,
                  Salary: salaryOf(t) || "",
                })),
              )
            }
          >
            <Download className="mr-2 size-4" aria-hidden />
            Export CSV
          </Button>
        }
      />

      <FilterBar filters={filters} onChange={setFilters} hideProvider={scope.role === "provider"} />

      <Card>
        <CardContent className="p-4 sm:p-5">
          <div className="relative max-w-sm">
            <Search
              className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden
            />
            <Input
              className="pl-9"
              placeholder="Search name, trainee ID or district"
              aria-label="Search trainees"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setPage(1);
              }}
            />
          </div>

          {visible.length === 0 ? (
            <div className="pt-6">
              <EmptyState
                icon={Users}
                title="No trainee records found"
                description="Adjust your search text or reset the filters above."
                action={
                  <Button
                    variant="outline"
                    onClick={() => {
                      setFilters(EMPTY_FILTERS);
                      setQuery("");
                    }}
                  >
                    Clear search and filters
                  </Button>
                }
              />
            </div>
          ) : (
            <>
              <div className="mt-4 overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Trainee</TableHead>
                      <TableHead>Course</TableHead>
                      <TableHead className="hidden md:table-cell">Provider</TableHead>
                      <TableHead>Training</TableHead>
                      <TableHead>Outcome</TableHead>
                      <TableHead className="text-right">Income</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {visible.map((t) => (
                      <TableRow key={t.id} className="cursor-pointer">
                        <TableCell>
                          <Link
                            to="/app/trainees/$traineeId"
                            params={{ traineeId: t.id }}
                            className="block"
                          >
                            <span className="block font-medium">{t.name}</span>
                            <span className="block text-xs text-muted-foreground">
                              {t.id} · {t.district} · {t.age}y {t.gender}
                            </span>
                          </Link>
                        </TableCell>
                        <TableCell className="text-sm">{courseName(t.courseId)}</TableCell>
                        <TableCell className="hidden text-sm md:table-cell">
                          {providerName(t.providerId)}
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={t.trainingStatus} />
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={t.employmentStatus} />
                        </TableCell>
                        <TableCell className="text-right text-sm font-medium">
                          {formatINR(salaryOf(t))}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-sm">
                <p className="text-muted-foreground">
                  Page {current} of {pageCount} · {rows.length} records
                </p>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={current === 1}
                    onClick={() => setPage(current - 1)}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={current === pageCount}
                    onClick={() => setPage(current + 1)}
                  >
                    Next
                  </Button>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
