export type Role = "admin" | "provider" | "trainee" | "employer";

export type TrainingStatus = "In Training" | "Completed" | "Dropped Out";

export type EmploymentStatus =
  | "Employed"
  | "Self-employed"
  | "Apprenticeship"
  | "Seeking Employment"
  | "Further Education"
  | "Unreachable";

export type NonPlacementReason =
  | "Lack of required skills"
  | "Lack of suitable jobs"
  | "Salary too low"
  | "Location constraints"
  | "Personal reasons"
  | "Further education"
  | "Health/family reasons"
  | "Not interested"
  | "Other";

export type ConsentStatus = "Granted" | "Partial" | "Withdrawn";

export type FollowUpMilestone = "3 months" | "6 months" | "12 months";

export type FollowUpStatus = "Completed" | "Due" | "Pending" | "Unreachable";

export interface TimelineEvent {
  id: string;
  label: string;
  date: string;
  status: "done" | "current" | "upcoming";
  detail: string;
}

export interface FollowUp {
  id: string;
  milestone: FollowUpMilestone;
  dueDate: string;
  completedDate?: string | undefined;
  status: FollowUpStatus;
  employmentStatus?: EmploymentStatus | undefined;
  salary?: number | undefined;
  skillsUsed?: string[] | undefined;
  satisfaction?: number | undefined;
  notes?: string | undefined;
}

export interface Employment {
  employerId?: string | undefined;
  employerName?: string | undefined;
  jobTitle?: string | undefined;
  joiningDate?: string | undefined;
  salary?: number | undefined;
  employmentType?: "Full-time" | "Part-time" | "Contract" | "Apprenticeship" | "Self-employed" | undefined;
  location?: string | undefined;
  verified?: boolean | undefined;
  businessType?: string | undefined;
  businessStartDate?: string | undefined;
  monthlyIncome?: number | undefined;
  businessStatus?: "Active" | "Growing" | "Struggling" | undefined;
}

export interface Trainee {
  id: string;
  name: string;
  age: number;
  gender: "Male" | "Female" | "Other";
  district: string;
  education: string;
  contactReachable: boolean;
  consent: ConsentStatus;
  consentDate: string;
  dataSharing: { analytics: boolean; employers: boolean; research: boolean };
  courseId: string;
  providerId: string;
  trainingCenter: string;
  startDate: string;
  endDate: string;
  attendance: number;
  assessmentScore: number;
  certified: boolean;
  trainingStatus: TrainingStatus;
  employmentStatus: EmploymentStatus;
  nonPlacementReason?: NonPlacementReason | undefined;
  employment: Employment;
  salaryProgression: { point: string; salary: number }[];
  followUps: FollowUp[];
  timeline: TimelineEvent[];
  trainingYear: number;
  satisfaction: number;
  email?: string | undefined;
}

export interface Course {
  id: string;
  name: string;
  sector: string;
  durationWeeks: number;
  skills: string[];
}

export interface Provider {
  id: string;
  name: string;
  district: string;
  courses: string[];
  rating: number;
  accreditation: "A+" | "A" | "B" | "C";
}

export interface Employer {
  id: string;
  name: string;
  sector: string;
  district: string;
  status: "Verified" | "Pending Verification" | "Needs Review";
  skillRequirements: string[];
  feedback: string;
  rating: number;
}

export interface DemoUser {
  email: string;
  name: string;
  role: Role;
  password: string;
  providerId?: string | undefined;
  traineeId?: string | undefined;
  employerId?: string | undefined;
}

export interface Filters {
  district: string;
  courseId: string;
  providerId: string;
  gender: string;
  ageGroup: string;
  trainingYear: string;
  employmentStatus: string;
}
