import type {
  Course,
  DemoUser,
  Employer,
  EmploymentStatus,
  FollowUp,
  FollowUpMilestone,
  NonPlacementReason,
  Provider,
  TimelineEvent,
  Trainee,
} from "@/types";

export const DISTRICTS = [
  "Pune",
  "Mumbai",
  "Nagpur",
  "Nashik",
  "Aurangabad",
  "Kolhapur",
  "Thane",
  "Satara",
] as const;

export const COURSES: Course[] = [
  {
    id: "C-WEB",
    name: "Web Development",
    sector: "IT & ITeS",
    durationWeeks: 24,
    skills: ["JavaScript", "HTML", "CSS", "React", "SQL", "Communication"],
  },
  {
    id: "C-ELE",
    name: "Electrician",
    sector: "Electrical",
    durationWeeks: 16,
    skills: ["Wiring", "Safety Standards", "Motor Repair", "Blueprint Reading"],
  },
  {
    id: "C-HCA",
    name: "Healthcare Assistant",
    sector: "Healthcare",
    durationWeeks: 20,
    skills: ["Patient Care", "First Aid", "Record Keeping", "Communication"],
  },
  {
    id: "C-DEO",
    name: "Data Entry Operator",
    sector: "IT & ITeS",
    durationWeeks: 12,
    skills: ["Excel", "Typing Speed", "Data Accuracy", "SQL"],
  },
  {
    id: "C-TAI",
    name: "Tailoring & Garment Making",
    sector: "Apparel",
    durationWeeks: 14,
    skills: ["Pattern Making", "Machine Stitching", "Quality Check"],
  },
  {
    id: "C-AUT",
    name: "Automotive Technician",
    sector: "Automotive",
    durationWeeks: 22,
    skills: ["Engine Diagnostics", "Safety Standards", "Electrical Systems"],
  },
];

export const PROVIDERS: Provider[] = [
  {
    id: "P-01",
    name: "Sahyadri Skill Academy",
    district: "Pune",
    courses: ["C-WEB", "C-DEO", "C-ELE"],
    rating: 4.6,
    accreditation: "A+",
  },
  {
    id: "P-02",
    name: "Konkan Vocational Institute",
    district: "Mumbai",
    courses: ["C-WEB", "C-HCA"],
    rating: 4.3,
    accreditation: "A",
  },
  {
    id: "P-03",
    name: "Vidarbha Technical Centre",
    district: "Nagpur",
    courses: ["C-ELE", "C-AUT"],
    rating: 3.9,
    accreditation: "B",
  },
  {
    id: "P-04",
    name: "Godavari Livelihood Mission",
    district: "Nashik",
    courses: ["C-TAI", "C-HCA", "C-DEO"],
    rating: 4.1,
    accreditation: "A",
  },
  {
    id: "P-05",
    name: "Marathwada Kaushalya Kendra",
    district: "Aurangabad",
    courses: ["C-AUT", "C-TAI"],
    rating: 3.6,
    accreditation: "C",
  },
  {
    id: "P-06",
    name: "Panchganga Industrial Training",
    district: "Kolhapur",
    courses: ["C-ELE", "C-DEO"],
    rating: 4.0,
    accreditation: "B",
  },
];

export const EMPLOYERS: Employer[] = [
  {
    id: "E-01",
    name: "Trimurti Softworks Pvt Ltd",
    sector: "IT & ITeS",
    district: "Pune",
    status: "Verified",
    skillRequirements: ["JavaScript", "React", "SQL", "Communication"],
    feedback: "Trainees are strong on frontend basics but need deeper database knowledge.",
    rating: 4.2,
  },
  {
    id: "E-02",
    name: "Sagar Health Services",
    sector: "Healthcare",
    district: "Mumbai",
    status: "Verified",
    skillRequirements: ["Patient Care", "First Aid", "Record Keeping"],
    feedback: "Well prepared for ward duties; documentation skills improving.",
    rating: 4.5,
  },
  {
    id: "E-03",
    name: "Deccan Motors Works",
    sector: "Automotive",
    district: "Nagpur",
    status: "Pending Verification",
    skillRequirements: ["Engine Diagnostics", "Electrical Systems", "Safety Standards"],
    feedback: "Need more hands-on diagnostics practice before deployment.",
    rating: 3.8,
  },
  {
    id: "E-04",
    name: "Ajanta Apparels",
    sector: "Apparel",
    district: "Aurangabad",
    status: "Verified",
    skillRequirements: ["Machine Stitching", "Quality Check", "Pattern Making"],
    feedback: "Good productivity; quality inspection training could improve.",
    rating: 4.0,
  },
  {
    id: "E-05",
    name: "Panchganga Electricals",
    sector: "Electrical",
    district: "Kolhapur",
    status: "Needs Review",
    skillRequirements: ["Wiring", "Safety Standards", "Motor Repair"],
    feedback: "Safety compliance awareness is excellent.",
    rating: 3.9,
  },
  {
    id: "E-06",
    name: "Nashik BPO Solutions",
    sector: "IT & ITeS",
    district: "Nashik",
    status: "Verified",
    skillRequirements: ["Excel", "Data Accuracy", "SQL", "Communication"],
    feedback: "Excel proficiency is good, SQL exposure is limited.",
    rating: 4.1,
  },
];

export const DEMO_USERS: DemoUser[] = [
  { email: "admin@mahaskill.demo", name: "Anjali Deshmukh", role: "admin", password: "demo1234" },
  {
    email: "provider@mahaskill.demo",
    name: "Sahyadri Skill Academy",
    role: "provider",
    password: "demo1234",
    providerId: "P-01",
  },
  {
    email: "trainee@mahaskill.demo",
    name: "Rahul Pawar",
    role: "trainee",
    password: "demo1234",
    traineeId: "MST-1001",
  },
  {
    email: "employer@mahaskill.demo",
    name: "Trimurti Softworks Pvt Ltd",
    role: "employer",
    password: "demo1234",
    employerId: "E-01",
  },
];

const FIRST_NAMES = [
  "Rahul","Priya","Amit","Sneha","Vikram","Kavita","Nilesh","Pooja","Sagar","Meera",
  "Rohit","Aarti","Ganesh","Shraddha","Prashant","Manisha","Akash","Rupali","Sandeep","Vaishali",
  "Kiran","Deepak","Swapnil","Ashwini","Tushar","Mansi","Yogesh","Rutuja","Nikhil","Sushma",
  "Omkar","Pallavi","Harshad","Trupti","Balaji","Shital","Chetan","Namrata","Dattatray","Jyoti",
  "Suraj","Anita","Mahesh","Komal","Vishal","Snehal","Abhijit","Bhagyashree",
];
const LAST_NAMES = [
  "Pawar","Jadhav","Kulkarni","Shinde","Patil","Deshmukh","More","Gaikwad","Chavan","Kadam",
  "Sawant","Bhosale","Salunkhe","Waghmare","Thorat","Mane","Rane","Kamble",
];
const EDUCATION = ["10th Pass", "12th Pass", "ITI Diploma", "Graduate", "Undergraduate"];

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const NON_PLACEMENT: NonPlacementReason[] = [
  "Lack of required skills",
  "Lack of suitable jobs",
  "Salary too low",
  "Location constraints",
  "Personal reasons",
  "Further education",
  "Health/family reasons",
  "Not interested",
];

function fmt(date: Date) {
  return date.toISOString().slice(0, 10);
}
function addMonths(date: Date, months: number) {
  const d = new Date(date);
  d.setMonth(d.getMonth() + months);
  return d;
}

const REFERENCE_DATE = new Date("2026-09-01T00:00:00Z");

function buildTimeline(t: {
  startDate: string;
  endDate: string;
  certified: boolean;
  employmentStatus: EmploymentStatus;
  employmentDate?: string;
  followUps: FollowUp[];
}): TimelineEvent[] {
  const events: TimelineEvent[] = [
    {
      id: "enroll",
      label: "Enrollment",
      date: fmt(addMonths(new Date(t.startDate), -1)),
      status: "done",
      detail: "Registered under Maharashtra State Skill Development Mission.",
    },
    {
      id: "start",
      label: "Training Started",
      date: t.startDate,
      status: "done",
      detail: "Batch commenced at the assigned training centre.",
    },
    {
      id: "complete",
      label: "Training Completed",
      date: t.endDate,
      status: "done",
      detail: "Course curriculum completed and assessed.",
    },
  ];
  events.push({
    id: "cert",
    label: "Certification",
    date: t.certified ? fmt(addMonths(new Date(t.endDate), 1)) : "—",
    status: t.certified ? "done" : "upcoming",
    detail: t.certified ? "NSQF-aligned certificate issued." : "Certification pending re-assessment.",
  });
  events.push({
    id: "search",
    label: "Job Search",
    date: fmt(addMonths(new Date(t.endDate), 1)),
    status: "done",
    detail: "Placement counselling and employer connect drive.",
  });
  const placed = ["Employed", "Self-employed", "Apprenticeship"].includes(t.employmentStatus);
  events.push({
    id: "employment",
    label: placed ? t.employmentStatus : "Awaiting Placement",
    date: placed && t.employmentDate ? t.employmentDate : "—",
    status: placed ? "done" : "current",
    detail: placed
      ? "Outcome recorded and verified in the outcome registry."
      : `Current status: ${t.employmentStatus}.`,
  });
  for (const f of t.followUps) {
    events.push({
      id: `fu-${f.milestone}`,
      label: `${f.milestone} Follow-up`,
      date: f.completedDate ?? f.dueDate,
      status: f.status === "Completed" ? "done" : f.status === "Due" ? "current" : "upcoming",
      detail:
        f.status === "Completed"
          ? `${f.employmentStatus}${f.salary ? ` · ₹${f.salary.toLocaleString("en-IN")}/month` : ""}`
          : `${f.status} — due ${f.dueDate}`,
    });
  }
  return events;
}

export function generateTrainees(): Trainee[] {
  const rand = mulberry32(20260830);
  const pick = <T,>(arr: readonly T[]) => arr[Math.floor(rand() * arr.length)]!;
  const trainees: Trainee[] = [];

  const outcomeWeights: EmploymentStatus[] = [
    ...Array(14).fill("Employed"),
    ...Array(3).fill("Self-employed"),
    ...Array(2).fill("Apprenticeship"),
    ...Array(3).fill("Seeking Employment"),
    "Further Education",
    "Unreachable",
  ];

  for (let i = 0; i < 46; i++) {
    const id = `MST-${1001 + i}`;
    const first = i === 0 ? "Rahul" : FIRST_NAMES[i % FIRST_NAMES.length]!;
    const last = i === 0 ? "Pawar" : LAST_NAMES[(i * 3) % LAST_NAMES.length]!;
    const name = `${first} ${last}`;
    const provider = PROVIDERS[i % PROVIDERS.length]!;
    const courseId = provider.courses[Math.floor(rand() * provider.courses.length)]!;
    const course = COURSES.find((c) => c.id === courseId)!;
    const district = rand() < 0.7 ? provider.district : pick(DISTRICTS);
    const trainingYear = rand() < 0.65 ? 2025 : 2024;
    const startMonth = Math.floor(rand() * 6) + 1;
    const startDate = new Date(Date.UTC(trainingYear, startMonth, 5));
    const endDate = addMonths(startDate, Math.round(course.durationWeeks / 4));
    const inTraining = i % 11 === 5;
    const trainingStatus = inTraining ? "In Training" : i % 17 === 3 ? "Dropped Out" : "Completed";
    let employmentStatus: EmploymentStatus =
      trainingStatus === "Completed" ? pick(outcomeWeights) : "Seeking Employment";
    if (i === 0) employmentStatus = "Employed";

    const certified = trainingStatus === "Completed" && rand() < 0.92;
    const attendance = Math.round(70 + rand() * 29);
    const assessmentScore = Math.round(52 + rand() * 46);
    const employmentDate = fmt(addMonths(endDate, 1 + Math.floor(rand() * 2)));
    const baseSalary =
      course.sector === "IT & ITeS"
        ? 18000 + Math.round(rand() * 9000)
        : course.sector === "Healthcare"
          ? 15000 + Math.round(rand() * 7000)
          : 13000 + Math.round(rand() * 8000);

    const monthsSinceJoin = Math.max(
      0,
      Math.round(
        (REFERENCE_DATE.getTime() - new Date(employmentDate).getTime()) / (1000 * 60 * 60 * 24 * 30),
      ),
    );

    const milestones: FollowUpMilestone[] = ["3 months", "6 months", "12 months"];
    const followUps: FollowUp[] = [];
    const isPlaced = ["Employed", "Self-employed", "Apprenticeship"].includes(employmentStatus);
    const salaryProgression: { point: string; salary: number }[] = isPlaced
      ? [{ point: "Joining", salary: baseSalary }]
      : [];

    milestones.forEach((m, mi) => {
      const monthOffset = [3, 6, 12][mi]!;
      const dueDate = fmt(addMonths(new Date(employmentDate), monthOffset));
      const isDue = monthsSinceJoin >= monthOffset;
      const growth = 1 + monthOffset * (0.012 + rand() * 0.012);
      const salary = Math.round((baseSalary * growth) / 500) * 500;
      if (isDue && employmentStatus !== "Unreachable" && rand() < 0.85) {
        followUps.push({
          id: `${id}-F${monthOffset}`,
          milestone: m,
          dueDate,
          completedDate: fmt(addMonths(new Date(dueDate), 0)),
          status: "Completed",
          employmentStatus,
          salary: isPlaced ? salary : undefined,
          skillsUsed: course.skills.slice(0, 3),
          satisfaction: Math.round(3 + rand() * 2),
          notes: isPlaced
            ? "Trainee confirmed continued employment during telephonic follow-up."
            : "Trainee still exploring opportunities; counselling offered.",
        });
        if (isPlaced) salaryProgression.push({ point: m, salary });
      } else if (isDue) {
        followUps.push({
          id: `${id}-F${monthOffset}`,
          milestone: m,
          dueDate,
          status: employmentStatus === "Unreachable" ? "Unreachable" : rand() < 0.5 ? "Due" : "Pending",
        });
      }
    });

    const employer = EMPLOYERS.find((e) => e.sector === course.sector) ?? EMPLOYERS[0]!;
    const trainee: Trainee = {
      id,
      name,
      age: 19 + Math.floor(rand() * 14),
      gender: rand() < 0.46 ? "Female" : "Male",
      district,
      education: pick(EDUCATION),
      contactReachable: employmentStatus !== "Unreachable",
      consent: rand() < 0.8 ? "Granted" : rand() < 0.6 ? "Partial" : "Withdrawn",
      consentDate: fmt(startDate),
      dataSharing: { analytics: true, employers: rand() < 0.75, research: rand() < 0.55 },
      courseId,
      providerId: provider.id,
      trainingCenter: `${provider.name} — ${district} Centre`,
      startDate: fmt(startDate),
      endDate: fmt(endDate),
      attendance,
      assessmentScore,
      certified,
      trainingStatus,
      employmentStatus,
      nonPlacementReason: isPlaced ? undefined : pick(NON_PLACEMENT),
      employment:
        employmentStatus === "Employed" || employmentStatus === "Apprenticeship"
          ? {
              employerId: employer.id,
              employerName: employer.name,
              jobTitle:
                course.id === "C-WEB"
                  ? "Junior Web Developer"
                  : course.id === "C-HCA"
                    ? "Healthcare Assistant"
                    : course.id === "C-DEO"
                      ? "Data Entry Executive"
                      : course.id === "C-ELE"
                        ? "Electrician (Grade II)"
                        : course.id === "C-AUT"
                          ? "Service Technician"
                          : "Machine Operator",
              joiningDate: employmentDate,
              salary: baseSalary,
              employmentType:
                employmentStatus === "Apprenticeship" ? "Apprenticeship" : "Full-time",
              location: `${employer.district}, Maharashtra`,
              verified: rand() < 0.75,
            }
          : employmentStatus === "Self-employed"
            ? {
                businessType:
                  course.id === "C-TAI"
                    ? "Tailoring unit"
                    : course.id === "C-ELE"
                      ? "Electrical repair shop"
                      : "Freelance services",
                businessStartDate: employmentDate,
                monthlyIncome: baseSalary,
                businessStatus: rand() < 0.6 ? "Active" : "Growing",
                verified: rand() < 0.5,
              }
            : {},
      salaryProgression,
      followUps,
      timeline: [],
      trainingYear,
      satisfaction: Math.round(3 + rand() * 2),
      email: i === 0 ? "trainee@mahaskill.demo" : undefined,
    };
    trainee.timeline = buildTimeline({
      startDate: trainee.startDate,
      endDate: trainee.endDate,
      certified: trainee.certified,
      employmentStatus: trainee.employmentStatus,
      employmentDate,
      followUps: trainee.followUps,
    });
    trainees.push(trainee);
  }

  // Ensure the demo trainee has the showcase journey from the brief.
  const demo = trainees[0]!;
  demo.employment = {
    employerId: "E-01",
    employerName: "Trimurti Softworks Pvt Ltd",
    jobTitle: "Junior Web Developer",
    joiningDate: "2025-09-15",
    salary: 20000,
    employmentType: "Full-time",
    location: "Pune, Maharashtra",
    verified: true,
  };
  demo.courseId = "C-WEB";
  demo.providerId = "P-01";
  demo.district = "Pune";
  demo.trainingStatus = "Completed";
  demo.certified = true;
  demo.attendance = 94;
  demo.assessmentScore = 88;
  demo.consent = "Granted";
  demo.salaryProgression = [
    { point: "Joining", salary: 20000 },
    { point: "3 months", salary: 22000 },
    { point: "6 months", salary: 25000 },
    { point: "12 months", salary: 30000 },
  ];
  demo.followUps = [
    {
      id: "MST-1001-F3",
      milestone: "3 months",
      dueDate: "2025-12-15",
      completedDate: "2025-12-18",
      status: "Completed",
      employmentStatus: "Employed",
      salary: 22000,
      skillsUsed: ["JavaScript", "HTML", "CSS"],
      satisfaction: 4,
      notes: "Confirmed employment; using core frontend skills daily.",
    },
    {
      id: "MST-1001-F6",
      milestone: "6 months",
      dueDate: "2026-03-15",
      completedDate: "2026-03-16",
      status: "Completed",
      employmentStatus: "Employed",
      salary: 25000,
      skillsUsed: ["JavaScript", "React", "SQL"],
      satisfaction: 4,
      notes: "Promoted to a project team; requested advanced SQL support.",
    },
    {
      id: "MST-1001-F12",
      milestone: "12 months",
      dueDate: "2026-09-15",
      status: "Due",
    },
  ];
  demo.timeline = buildTimeline({
    startDate: demo.startDate,
    endDate: demo.endDate,
    certified: true,
    employmentStatus: "Employed",
    employmentDate: "2025-09-15",
    followUps: demo.followUps,
  });

  return trainees;
}

export const SKILL_DEMAND: { skill: string; demand: number; coverage: number }[] = [
  { skill: "JavaScript", demand: 82, coverage: 61 },
  { skill: "SQL", demand: 74, coverage: 45 },
  { skill: "Communication", demand: 68, coverage: 52 },
  { skill: "Excel", demand: 61, coverage: 70 },
  { skill: "Engine Diagnostics", demand: 57, coverage: 49 },
  { skill: "Patient Care", demand: 64, coverage: 66 },
  { skill: "Safety Standards", demand: 59, coverage: 72 },
  { skill: "Quality Check", demand: 48, coverage: 38 },
];

export const NOTIFICATIONS = [
  {
    id: "n1",
    title: "128 trainees require 6-month follow-up",
    detail: "Follow-up window closes in 7 days across 6 districts.",
    tone: "warning" as const,
    time: "2h ago",
  },
  {
    id: "n2",
    title: "Godavari Livelihood Mission submitted new outcome data",
    detail: "42 outcome records awaiting validation.",
    tone: "info" as const,
    time: "5h ago",
  },
  {
    id: "n3",
    title: "15 employer records require verification",
    detail: "Employer verification backlog is above threshold.",
    tone: "warning" as const,
    time: "Yesterday",
  },
  {
    id: "n4",
    title: "Automotive Technician placement rate declining",
    detail: "Down 6.4 pts against the previous cohort.",
    tone: "danger" as const,
    time: "2 days ago",
  },
];
