import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

import { DEMO_USERS } from "@/data/seed";
import type { DemoUser, Role } from "@/types";

const SESSION_KEY = "mahaskilltrack:session:v1";

export interface SessionUser {
  email: string;
  name: string;
  role: Role;
  providerId?: string | undefined;
  traineeId?: string | undefined;
  employerId?: string | undefined;
}

interface AuthValue {
  user: SessionUser | null;
  hydrated: boolean;
  signIn: (email: string, password: string) => { ok: boolean; error?: string; role?: Role };
  signOut: () => void;
}

const AuthContext = createContext<AuthValue | null>(null);

function toSession(u: DemoUser): SessionUser {
  return {
    email: u.email,
    name: u.name,
    role: u.role,
    providerId: u.providerId,
    traineeId: u.traineeId,
    employerId: u.employerId,
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(SESSION_KEY);
      if (raw) setUser(JSON.parse(raw) as SessionUser);
    } catch {
      /* ignore */
    }
    setHydrated(true);
  }, []);

  const signIn = useCallback((email: string, password: string) => {
    const match = DEMO_USERS.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
    if (!match) return { ok: false, error: "No demo account found for this email address." };
    if (match.password !== password) return { ok: false, error: "Incorrect password." };
    const session = toSession(match);
    setUser(session);
    try {
      window.localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    } catch {
      /* ignore */
    }
    return { ok: true, role: match.role };
  }, []);

  const signOut = useCallback(() => {
    setUser(null);
    try {
      window.localStorage.removeItem(SESSION_KEY);
    } catch {
      /* ignore */
    }
  }, []);

  const value = useMemo<AuthValue>(() => ({ user, hydrated, signIn, signOut }), [user, hydrated, signIn, signOut]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}

export const ROLE_LABEL: Record<Role, string> = {
  admin: "Government Administrator",
  provider: "Training Provider",
  trainee: "Trainee",
  employer: "Employer",
};
