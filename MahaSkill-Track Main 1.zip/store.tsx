import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

import { COURSES, EMPLOYERS, PROVIDERS, generateTrainees } from "@/data/seed";
import type {
  Course,
  Employer,
  Employment,
  EmploymentStatus,
  FollowUp,
  NonPlacementReason,
  Provider,
  Trainee,
} from "@/types";

const STORAGE_KEY = "mahaskilltrack:data:v1";

export interface OutcomeUpdate {
  employmentStatus: EmploymentStatus;
  employment?: Employment;
  nonPlacementReason?: NonPlacementReason | undefined;
}

interface StoreValue {
  ready: boolean;
  trainees: Trainee[];
  courses: Course[];
  providers: Provider[];
  employers: Employer[];
  getTrainee: (id: string) => Trainee | undefined;
  courseName: (id: string) => string;
  providerName: (id: string) => string;
  updateOutcome: (traineeId: string, update: OutcomeUpdate) => void;
  recordFollowUp: (traineeId: string, followUpId: string, data: Partial<FollowUp>) => void;
  verifyEmployment: (traineeId: string) => void;
  resetData: () => void;
}

const StoreContext = createContext<StoreValue | null>(null);

function withTimeline(t: Trainee): Trainee {
  const placed = ["Employed", "Self-employed", "Apprenticeship"].includes(t.employmentStatus);
  const timeline = t.timeline.map((e) =>
    e.id === "employment"
      ? {
          ...e,
          label: placed ? t.employmentStatus : "Awaiting Placement",
          date: placed ? (t.employment.joiningDate ?? t.employment.businessStartDate ?? "—") : "—",
          status: placed ? ("done" as const) : ("current" as const),
          detail: placed
            ? `${t.employment.jobTitle ?? t.employment.businessType ?? "Outcome"} — recorded in the outcome registry.`
            : `Current status: ${t.employmentStatus}.`,
        }
      : e,
  );
  return { ...t, timeline };
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [trainees, setTrainees] = useState<Trainee[]>(() => generateTrainees());
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setTrainees(JSON.parse(raw) as Trainee[]);
    } catch {
      /* ignore corrupt cache and keep seeded data */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(trainees));
    } catch {
      /* storage may be unavailable */
    }
  }, [trainees, ready]);

  const updateOutcome = useCallback((traineeId: string, update: OutcomeUpdate) => {
    setTrainees((prev) =>
      prev.map((t) => {
        if (t.id !== traineeId) return t;
        const employment: Employment = { ...t.employment, ...(update.employment ?? {}) };
        const salary = employment.salary ?? employment.monthlyIncome;
        const salaryProgression =
          salary && t.salaryProgression.length === 0
            ? [{ point: "Joining", salary }]
            : salary
              ? t.salaryProgression.map((p, i) =>
                  i === t.salaryProgression.length - 1 ? { ...p, salary } : p,
                )
              : t.salaryProgression;
        return withTimeline({
          ...t,
          employmentStatus: update.employmentStatus,
          nonPlacementReason: update.nonPlacementReason,
          employment,
          salaryProgression,
          contactReachable: update.employmentStatus !== "Unreachable",
        });
      }),
    );
  }, []);

  const recordFollowUp = useCallback(
    (traineeId: string, followUpId: string, data: Partial<FollowUp>) => {
      setTrainees((prev) =>
        prev.map((t) => {
          if (t.id !== traineeId) return t;
          const followUps = t.followUps.map((f) => (f.id === followUpId ? { ...f, ...data } : f));
          const updated = followUps.find((f) => f.id === followUpId);
          const salaryProgression =
            updated?.status === "Completed" && updated.salary
              ? [
                  ...t.salaryProgression.filter((p) => p.point !== updated.milestone),
                  { point: updated.milestone, salary: updated.salary },
                ]
              : t.salaryProgression;
          return withTimeline({
            ...t,
            followUps,
            salaryProgression,
            timeline: t.timeline.map((e) =>
              e.id === `fu-${updated?.milestone}`
                ? {
                    ...e,
                    date: updated?.completedDate ?? e.date,
                    status: updated?.status === "Completed" ? "done" : e.status,
                    detail:
                      updated?.status === "Completed"
                        ? `${updated.employmentStatus ?? t.employmentStatus}${updated.salary ? ` · ₹${updated.salary.toLocaleString("en-IN")}/month` : ""}`
                        : `${updated?.status ?? e.status} — due ${updated?.dueDate ?? ""}`,
                  }
                : e,
            ),
          });
        }),
      );
    },
    [],
  );

  const verifyEmployment = useCallback((traineeId: string) => {
    setTrainees((prev) =>
      prev.map((t) =>
        t.id === traineeId ? { ...t, employment: { ...t.employment, verified: true } } : t,
      ),
    );
  }, []);

  const resetData = useCallback(() => {
    setTrainees(generateTrainees());
  }, []);

  const value = useMemo<StoreValue>(
    () => ({
      ready,
      trainees,
      courses: COURSES,
      providers: PROVIDERS,
      employers: EMPLOYERS,
      getTrainee: (id) => trainees.find((t) => t.id === id),
      courseName: (id) => COURSES.find((c) => c.id === id)?.name ?? id,
      providerName: (id) => PROVIDERS.find((p) => p.id === id)?.name ?? id,
      updateOutcome,
      recordFollowUp,
      verifyEmployment,
      resetData,
    }),
    [ready, trainees, updateOutcome, recordFollowUp, verifyEmployment, resetData],
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used inside StoreProvider");
  return ctx;
}
