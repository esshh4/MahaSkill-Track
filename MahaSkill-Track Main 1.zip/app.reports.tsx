import { createFileRoute } from "@tanstack/react-router";
import { Download, FileText, Printer } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

import { FilterBar } from "@/components/common/filter-bar";
import { PageHeader } from "@/components/common/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useScope } from "@/hooks/use-scope";
import { EMPTY_FILTERS, applyFilters, courseStats, districtStats, kpis, providerStats, salaryOf } from "@/services/analytics";
import { useStore } from "@/services/store";
import { downloadCsv, downloadPrintableReport } from "@/utils/export";
import type { Filters } from "@/types";

export const Route = createFileRoute("/app/reports")({
  head: () => ({
    meta: [
      { title: "Reports — MahaSkillTrack" },
      { name: "description", content: "Generate district, program, provider and trainee outcome reports as CSV or printable documents." },
      { property: "og:title", content: "Reports & Exports — MahaSkillTrack" },
      { property: "og:description", content: "Export-ready outcome reporting for review meetings." },
    ],
  }),
  component: ReportsPage,
});

function ReportsPage() {
  const scope = useScope();
  const { courseName, providerName } = useStore();
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);
  const rows = useMemo(() => applyFilters(scope.trainees, filters), [scope.trainees, filters]);
  const k = kpis(rows);
  const subtitle = `${rows.length} trainee records · generated ${new Date().toLocaleDateString("en-IN")}`;

  const reports = [
    {
      title: "Outcome summary",
      description: "Headline KPIs: completion, employment, retention and average salary.",
      rows: [
        { Metric: "Total trainees", Value: k.total },
        { Metric: "Completion rate %", Value: k.completionRate },
        { Metric: "Employment rate %", Value: k.employmentRate },
        { Metric: "Self-employed %", Value: k.selfRate },
        { Metric: "12-month retention %", Value: k.retention12 },
        { Metric: "Average salary", Value: k.avgSalary },
      ] as Record<string, string | number>[],
    },
    {
      title: "District performance",
      description: "Employment rate, retention and salary by district.",
      rows: districtStats(rows).map((d) => ({
        District: d.district,
        Trainees: d.trainees,
        "Employment %": d.employmentRate,
        "Retention 6m %": d.retention,
        "Avg salary": d.avgSalary,
      })) as Record<string, string | number>[],
    },
    {
      title: "Program effectiveness",
      description: "Completion, certification, placement and retention per course.",
      rows: courseStats(rows).map((c) => ({
        Course: c.course,
        Trainees: c.trainees,
        "Completion %": c.completionRate,
        "Placement %": c.placementRate,
        "Retention 12m %": c.retention12,
        "Avg salary": c.avgSalary,
      })) as Record<string, string | number>[],
    },
    {
      title: "Provider performance",
      description: "Provider-wise outcome league table.",
      rows: providerStats(rows).map((p) => ({
        Provider: p.provider,
        District: p.district,
        Accreditation: p.accreditation,
        Trainees: p.trainees,
        "Employment %": p.employmentRate,
        "Avg salary": p.avgSalary,
      })) as Record<string, string | number>[],
    },
    {
      title: "Trainee outcome list",
      description: "Record-level outcomes without personal contact details.",
      rows: rows.map((t) => ({
        "Trainee ID": t.id,
        District: t.district,
        Course: courseName(t.courseId),
        Provider: providerName(t.providerId),
        Outcome: t.employmentStatus,
        Income: salaryOf(t) || "",
      })) as Record<string, string | number>[],
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader title="Reports and exports" description="Filter the data, then export review-ready reports for departmental meetings." />
      <FilterBar filters={filters} onChange={setFilters} hideProvider={scope.role === "provider"} />
      <div className="grid gap-5 md:grid-cols-2">
        {reports.map((r) => (
          <Card key={r.title}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <FileText className="size-4 text-primary" aria-hidden />
                {r.title}
              </CardTitle>
              <CardDescription>{r.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={!r.rows.length}
                onClick={() => {
                  downloadCsv(r.title.toLowerCase().replace(/\s+/g, "-"), r.rows);
                  toast.success(`${r.title} exported as CSV`);
                }}
              >
                <Download className="mr-1.5 size-4" aria-hidden />
                CSV
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={!r.rows.length}
                onClick={() => {
                  downloadPrintableReport(r.title, subtitle, r.rows);
                  toast.success(`${r.title} generated as a printable report`);
                }}
              >
                <Printer className="mr-1.5 size-4" aria-hidden />
                Printable
              </Button>
              <span className="self-center text-xs text-muted-foreground">{r.rows.length} rows</span>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
