import { createFileRoute } from "@tanstack/react-router";
import { RotateCcw } from "lucide-react";
import { toast } from "sonner";

import { ROLE_LABEL, useAuth } from "@/auth/auth-context";
import { PageHeader } from "@/components/common/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useStore } from "@/services/store";

export const Route = createFileRoute("/app/settings")({
  head: () => ({
    meta: [
      { title: "Settings — MahaSkillTrack" },
      { name: "description", content: "Manage your MahaSkillTrack demo account and reset the seeded demonstration dataset." },
      { property: "og:title", content: "Settings — MahaSkillTrack" },
      { property: "og:description", content: "Account details and demo data controls." },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { user } = useAuth();
  const { resetData, trainees } = useStore();

  return (
    <div className="space-y-6">
      <PageHeader title="Settings" description="Account details and demo environment controls." />
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Account</CardTitle>
          <CardDescription>Signed in with a seeded demonstration account</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <Row label="Name" value={user?.name ?? "—"} />
          <Row label="Email" value={user?.email ?? "—"} />
          <Row label="Role" value={user ? ROLE_LABEL[user.role] : "—"} />
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Demo data</CardTitle>
          <CardDescription>{trainees.length} synthetic trainee records currently loaded</CardDescription>
        </CardHeader>
        <CardContent>
          <Button
            variant="outline"
            onClick={() => {
              resetData();
              toast.success("Demo data reset", { description: "All outcomes and follow-ups are back to their seeded values." });
            }}
          >
            <RotateCcw className="mr-2 size-4" aria-hidden />
            Reset demo data
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-border/60 pb-1.5 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
