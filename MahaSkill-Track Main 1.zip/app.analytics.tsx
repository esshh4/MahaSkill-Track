import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";

import { ChartCard } from "@/components/common/chart-card";
import { FilterBar } from "@/components/common/filter-bar";
import { PageHeader } from "@/components/common/page-header";
import { EmptyState } from "@/components/common/states";
import { CourseComparisonBars, DistrictBars, ReasonBars, RetentionLine, SalaryLine } from "@/components/charts/dashboard-charts";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useScope } from "@/hooks/use-scope";
import { EMPTY_FILTERS, applyFilters, courseStats, districtStats, formatINR, nonPlacementReasons, retentionTrend, salaryProgressionAvg } from "@/services/analytics";
import type { Filters } from "@/types";

export const Route = createFileRoute("/app/analytics")({
  head: () => ({
    meta: [
      { title: "Analytics — MahaSkillTrack" },
      { name: "description", content: "Cross-cutting analytics on districts, courses, retention, salary growth and non-placement reasons." },
      { property: "og:title", content: "Outcome Analytics — MahaSkillTrack" },
      { property: "og:description", content: "Aggregated analytics for Maharashtra skill training outcomes." },
    ],
  }),
  component: AnalyticsPage,
});

function AnalyticsPage() {
  const scope = useScope();
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);
  const rows = useMemo(() => applyFilters(scope.trainees, filters), [scope.trainees, filters]);
  const districts = useMemo(() => districtStats(rows), [rows]);
  const courses = useMemo(() => courseStats(rows), [rows]);
  const salary = useMemo(() => salaryProgressionAvg(rows).filter((p) => p.salary > 0), [rows]);
  const reasons = useMemo(() => nonPlacementReasons(rows), [rows]);

  return (
    <div className="space-y-6">
      <PageHeader title="Analytics" description={`Aggregated, privacy-safe analysis across ${rows.length} trainee records.`} />
      <FilterBar filters={filters} onChange={setFilters} hideProvider={scope.role === "provider"} />
      {rows.length === 0 ? (
        <EmptyState title="No data for these filters" description="Widen the filters to run the analysis." />
      ) : (
        <>
          <div className="grid gap-5 lg:grid-cols-2">
            <ChartCard title="District employment rate" description="Placement performance by district">
              <DistrictBars data={districts} />
            </ChartCard>
            <ChartCard title="Retention by milestone" description="Share still employed at 3, 6 and 12 months">
              <RetentionLine data={retentionTrend(rows)} />
            </ChartCard>
            <ChartCard title="Course placement vs retention" description="Sustained outcomes by program">
              <CourseComparisonBars data={courses.map((c) => ({ course: c.course, placementRate: c.placementRate, retention12: c.retention12 }))} />
            </ChartCard>
            <ChartCard title="Average salary progression" description="Income growth from joining to 12 months">
              {salary.length ? <SalaryLine data={salary} /> : <EmptyState title="No salary data" description="No placements recorded in this scope." />}
            </ChartCard>
          </div>
          <ChartCard title="Non-placement reasons" description="Where the pipeline breaks down">
            {reasons.length ? <ReasonBars data={reasons} /> : <EmptyState title="No reason codes" description="All trainees in this scope are placed." />}
          </ChartCard>
          <Card>
            <CardContent className="overflow-x-auto p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>District</TableHead>
                    <TableHead>Trainees</TableHead>
                    <TableHead>Employment</TableHead>
                    <TableHead>Retention 6m</TableHead>
                    <TableHead className="text-right">Avg salary</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {districts.map((d) => (
                    <TableRow key={d.district}>
                      <TableCell className="font-medium">{d.district}</TableCell>
                      <TableCell>{d.trainees}</TableCell>
                      <TableCell>{d.employmentRate}%</TableCell>
                      <TableCell>{d.retention}%</TableCell>
                      <TableCell className="text-right">{formatINR(d.avgSalary)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
