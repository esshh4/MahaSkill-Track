import { createFileRoute } from "@tanstack/react-router";
import { Lightbulb } from "lucide-react";

import { ChartCard } from "@/components/common/chart-card";
import { PageHeader } from "@/components/common/page-header";
import { StatusBadge } from "@/components/common/status-badge";
import { SkillGapBars } from "@/components/charts/dashboard-charts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { skillGaps, skillInsights } from "@/services/analytics";

export const Route = createFileRoute("/app/skill-gaps")({
  head: () => ({
    meta: [
      { title: "Skill gaps — MahaSkillTrack" },
      { name: "description", content: "Compare employer skill demand with training coverage and act on gap-closing recommendations." },
      { property: "og:title", content: "Skill Gap Intelligence — MahaSkillTrack" },
      { property: "og:description", content: "Demand versus coverage analysis for Maharashtra skill programs." },
    ],
  }),
  component: SkillGapsPage,
});

function SkillGapsPage() {
  const gaps = skillGaps();
  const insight = skillInsights();

  return (
    <div className="space-y-6">
      <PageHeader title="Skill gap intelligence" description="Where employer demand outpaces what training programs currently teach." />
      <Card className="border-accent/40 bg-accent/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Lightbulb className="size-4 text-accent-foreground" aria-hidden />
            Recommendation
          </CardTitle>
          <CardDescription>{insight.highCount} skills currently show a high-severity gap</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p>{insight.insight}</p>
          <p className="text-muted-foreground">{insight.action}</p>
        </CardContent>
      </Card>
      <ChartCard title="Employer demand vs training coverage" description="Percentage of employers requiring the skill against percentage of programs teaching it">
        <SkillGapBars data={gaps.map((g) => ({ skill: g.skill, demand: g.demand, coverage: g.coverage }))} />
      </ChartCard>
      <Card>
        <CardContent className="overflow-x-auto p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Skill</TableHead>
                <TableHead>Employer demand</TableHead>
                <TableHead>Training coverage</TableHead>
                <TableHead>Gap</TableHead>
                <TableHead>Severity</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {gaps.map((g) => (
                <TableRow key={g.skill}>
                  <TableCell className="font-medium">{g.skill}</TableCell>
                  <TableCell>{g.demand}%</TableCell>
                  <TableCell>{g.coverage}%</TableCell>
                  <TableCell className="font-medium">{g.gap} pts</TableCell>
                  <TableCell>
                    <StatusBadge status={g.severity} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
