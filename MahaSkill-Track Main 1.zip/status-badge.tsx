import {
  Award,
  BadgeCheck,
  Briefcase,
  BookOpen,
  Clock,
  GraduationCap,
  PhoneOff,
  Search,
  Store,
  XCircle,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

import { cn } from "@/lib/utils";

type Tone = "success" | "info" | "warning" | "danger" | "neutral" | "accent";

const TONES: Record<Tone, string> = {
  success: "bg-success/10 text-success border-success/30",
  info: "bg-info/10 text-info border-info/30",
  warning: "bg-warning/15 text-warning-foreground border-warning/40",
  danger: "bg-destructive/10 text-destructive border-destructive/30",
  neutral: "bg-muted text-muted-foreground border-border",
  accent: "bg-accent/15 text-accent-foreground border-accent/40",
};

const MAP: Record<string, { tone: Tone; icon: LucideIcon }> = {
  Employed: { tone: "success", icon: Briefcase },
  "Self-employed": { tone: "accent", icon: Store },
  Apprenticeship: { tone: "info", icon: Award },
  "Seeking Employment": { tone: "warning", icon: Search },
  "Further Education": { tone: "info", icon: GraduationCap },
  Unreachable: { tone: "danger", icon: PhoneOff },
  Completed: { tone: "success", icon: BadgeCheck },
  "In Training": { tone: "info", icon: BookOpen },
  "Dropped Out": { tone: "danger", icon: XCircle },
  Due: { tone: "warning", icon: Clock },
  Pending: { tone: "neutral", icon: Clock },
  Verified: { tone: "success", icon: BadgeCheck },
  "Pending Verification": { tone: "warning", icon: Clock },
  "Needs Review": { tone: "danger", icon: XCircle },
  Granted: { tone: "success", icon: BadgeCheck },
  Partial: { tone: "warning", icon: Clock },
  Withdrawn: { tone: "danger", icon: XCircle },
  High: { tone: "danger", icon: XCircle },
  Medium: { tone: "warning", icon: Clock },
  Low: { tone: "success", icon: BadgeCheck },
};

export function StatusBadge({
  status,
  className,
  showIcon = true,
}: {
  status: string;
  className?: string;
  showIcon?: boolean;
}) {
  const config = MAP[status] ?? { tone: "neutral" as Tone, icon: Clock };
  const Icon = config.icon;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium whitespace-nowrap",
        TONES[config.tone],
        className,
      )}
    >
      {showIcon ? <Icon className="size-3.5 shrink-0" aria-hidden /> : null}
      {status}
    </span>
  );
}
